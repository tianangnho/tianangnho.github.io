#!/usr/bin/env python3
"""
image_to_pdf.py
Convert images to PDF and merge image/PDF files into a single PDF.
Supports optional OCR to produce searchable/selectable text in the output PDF.
"""

import sys
import os
import re
import argparse
import io
from pathlib import Path

IMAGE_EXTS = frozenset({'.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tiff', '.tif', '.webp'})
SUPPORTED_EXTS = IMAGE_EXTS | {'.pdf'}


# ---------------------------------------------------------------------------
# Sorting helpers
# ---------------------------------------------------------------------------

def natural_key(text):
    """Sort key for natural (human-friendly) order: img2.jpg < img10.jpg."""
    return [int(c) if c.isdigit() else c.lower() for c in re.split(r'(\d+)', str(text))]


# ---------------------------------------------------------------------------
# File collection
# ---------------------------------------------------------------------------

def collect_files(inputs, recursive=False):
    """Expand paths: files pass through, folders expand to supported files."""
    result = []
    for inp in inputs:
        p = Path(inp)
        if p.is_dir():
            pattern = '**/*' if recursive else '*'
            for child in sorted(p.glob(pattern)):
                if child.is_file() and child.suffix.lower() in SUPPORTED_EXTS:
                    result.append(child)
        elif p.is_file():
            if p.suffix.lower() in SUPPORTED_EXTS:
                result.append(p)
            else:
                print(f"[warn] Skipping unsupported file: {p}", file=sys.stderr)
        else:
            matches = sorted(Path('.').glob(inp))
            for m in matches:
                if m.is_file() and m.suffix.lower() in SUPPORTED_EXTS:
                    result.append(m)
            if not matches:
                print(f"[warn] No match for: {inp}", file=sys.stderr)
    return result


def sort_files(files, method):
    if method == 'natural':
        return sorted(files, key=lambda p: natural_key(p.name))
    elif method == 'name':
        return sorted(files, key=lambda p: p.name.lower())
    elif method == 'mtime':
        return sorted(files, key=lambda p: p.stat().st_mtime)
    else:  # 'none' — keep insertion order
        return list(files)


def deduplicate(files):
    seen = set()
    unique = []
    for f in files:
        key = f.resolve()
        if key not in seen:
            seen.add(key)
            unique.append(f)
    return unique


def collect_files_from_order(order_file, base_dirs=None):
    """
    Read an ordered file list from a plain-text file.
    Each non-blank, non-comment line is a filename or relative/absolute path.
    Lines starting with # are treated as comments.
    Relative paths are resolved against base_dirs (or cwd if none given).
    """
    order_path = Path(order_file)
    if not order_path.exists():
        print(f"[error] Order file not found: {order_file}", file=sys.stderr)
        sys.exit(1)

    bases = [Path(d) for d in base_dirs] if base_dirs else [Path('.')]

    result = []
    with open(order_path, encoding='utf-8') as fh:
        for lineno, raw in enumerate(fh, 1):
            line = raw.strip()
            if not line or line.startswith('#'):
                continue

            p = Path(line)
            if p.is_absolute():
                if p.is_file():
                    result.append(p)
                else:
                    print(f"[warn] line {lineno}: file not found: {line}", file=sys.stderr)
                continue

            # Try relative to each base dir
            found = None
            for base in bases:
                candidate = base / p
                if candidate.is_file():
                    found = candidate
                    break

            if found:
                result.append(found)
            else:
                print(f"[warn] line {lineno}: file not found: {line}", file=sys.stderr)

    return result


# ---------------------------------------------------------------------------
# Image → PIL
# ---------------------------------------------------------------------------

def open_image_rgb(image_path):
    """Open an image and normalise to RGB or L (greyscale)."""
    from PIL import Image
    img = Image.open(image_path)
    if img.mode in ('RGBA', 'LA'):
        bg = Image.new('RGB', img.size, (255, 255, 255))
        mask = img.split()[-1]
        bg.paste(img.convert('RGB'), mask=mask)
        img = bg
    elif img.mode == 'P':
        img = img.convert('RGB')
    elif img.mode not in ('RGB', 'L'):
        img = img.convert('RGB')
    return img


# ---------------------------------------------------------------------------
# Plain (non-OCR) path: image → PDF bytes
# ---------------------------------------------------------------------------

def image_to_pdf_bytes(image_path):
    """Convert one image file to a single-page PDF in memory (no OCR)."""
    img = open_image_rgb(image_path)
    buf = io.BytesIO()
    img.save(buf, format='PDF')
    buf.seek(0)
    return buf


# ---------------------------------------------------------------------------
# OCR path: image → searchable PDF bytes
# ---------------------------------------------------------------------------

def _check_tesseract():
    """Raise a friendly error if Tesseract is not available."""
    try:
        import pytesseract
        pytesseract.get_tesseract_version()
    except Exception:
        print(
            "\n[error] OCR requested but Tesseract is not available.\n"
            "  1. Install Tesseract: https://github.com/UB-Mannheim/tesseract/wiki\n"
            "  2. pip install pytesseract\n"
            "  3. Make sure tesseract.exe is in your PATH  (or set pytesseract.pytesseract.tesseract_cmd)\n",
            file=sys.stderr,
        )
        sys.exit(1)


def image_to_searchable_pdf_bytes(image_path, lang='eng'):
    """
    Run Tesseract OCR on the image and return a searchable PDF in memory.
    The returned bytes contain both the visible image and an invisible text layer.
    """
    import pytesseract
    img = open_image_rgb(image_path)
    # pytesseract.image_to_pdf_or_hocr returns raw bytes of a 1-page searchable PDF
    pdf_bytes = pytesseract.image_to_pdf_or_hocr(img, lang=lang, extension='pdf')
    return io.BytesIO(pdf_bytes)


# ---------------------------------------------------------------------------
# Core merge routine
# ---------------------------------------------------------------------------

def merge_to_pdf(files, output_path, verbose=False, ocr=False, lang='eng'):
    """Merge all image/PDF files into one PDF."""
    try:
        from pypdf import PdfWriter, PdfReader
    except ImportError:
        print("Error: pypdf not installed. Run: pip install pypdf", file=sys.stderr)
        sys.exit(1)

    if ocr:
        _check_tesseract()

    writer = PdfWriter()
    total = len(files)
    merged_pages = 0
    errors = 0
    pad = len(str(total))

    for i, f in enumerate(files, 1):
        ext = f.suffix.lower()
        try:
            if ext == '.pdf':
                reader = PdfReader(str(f))
                n = len(reader.pages)
                for page in reader.pages:
                    writer.add_page(page)
                merged_pages += n
                if verbose:
                    print(f"  [{i:>{pad}}/{total}] {f.name}  ({n} page{'s' if n != 1 else ''})")
            else:
                if ocr:
                    pdf_buf = image_to_searchable_pdf_bytes(f, lang=lang)
                    tag = 'OCR'
                else:
                    pdf_buf = image_to_pdf_bytes(f)
                    tag = 'image'
                reader = PdfReader(pdf_buf)
                for page in reader.pages:
                    writer.add_page(page)
                merged_pages += 1
                if verbose:
                    print(f"  [{i:>{pad}}/{total}] {f.name}  ({tag} → 1 page)")
        except Exception as e:
            print(f"  [error] {f.name}: {e}", file=sys.stderr)
            errors += 1

    with open(output_path, 'wb') as out:
        writer.write(out)

    return merged_pages, errors


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        prog='image_to_pdf',
        description='Convert images to PDF and merge image/PDF files into one PDF.\n'
                    'Use --ocr to produce searchable/selectable text via Tesseract.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python image_to_pdf.py                                Merge all images in current folder
  python image_to_pdf.py photos\\ -o album.pdf           Merge a folder of images
  python image_to_pdf.py img1.jpg img2.png              Merge specific files in given order
  python image_to_pdf.py a.pdf b.pdf -o merged.pdf      Merge PDFs
  python image_to_pdf.py photos\\ docs\\ -o out.pdf       Merge multiple folders
  python image_to_pdf.py *.jpg -s name -o out.pdf       Sort alphabetically
  python image_to_pdf.py -f order.txt -o out.pdf        Use custom order from txt file
  python image_to_pdf.py photos\\ -f order.txt -o out.pdf  Folder + custom order
  python image_to_pdf.py photos\\ --ocr -o searchable.pdf  OCR (English)
  python image_to_pdf.py scan\\ --ocr --lang vie -o vi.pdf OCR Vietnamese
  python image_to_pdf.py photos\\ --list                 Preview file order (dry run)

Order file format (one filename per line, # = comment):
  # This is a comment
  cover.jpg
  chapter1.png
  chapter2.jpg
  appendix.pdf

Supported OCR languages (Tesseract pack names):
  eng  English     vie  Vietnamese    jpn  Japanese
  chi_sim/chi_tra  Chinese           kor  Korean
  fra  French      deu  German        tha  Thai
        """,
    )

    parser.add_argument(
        'inputs', nargs='*',
        help='Input files, folders, or glob patterns (default: current directory)',
    )
    parser.add_argument(
        '-o', '--output', default='output.pdf', metavar='FILE',
        help='Output PDF path (default: output.pdf)',
    )
    parser.add_argument(
        '-s', '--sort',
        choices=['natural', 'name', 'mtime', 'none'],
        default='natural',
        help='Sort order: natural (1,2,10…), name (a-z), mtime (oldest first), none (keep given order) [default: natural]',
    )
    parser.add_argument(
        '-f', '--order-file', metavar='FILE',
        help='Text file listing filenames in the desired order (one per line, # = comment). Overrides --sort.',
    )
    parser.add_argument(
        '-r', '--recursive', action='store_true',
        help='Scan folders recursively',
    )
    parser.add_argument(
        '--ocr', action='store_true',
        help='Run Tesseract OCR on images → searchable/selectable text in PDF (requires Tesseract installed)',
    )
    parser.add_argument(
        '--lang', default='eng', metavar='LANG',
        help='Tesseract language code(s), e.g. eng, vie, eng+vie (default: eng)',
    )
    parser.add_argument(
        '-v', '--verbose', action='store_true',
        help='Show each file as it is processed',
    )
    parser.add_argument(
        '-l', '--list', action='store_true',
        help='List files that would be processed, then exit (dry run)',
    )

    args = parser.parse_args()

    inputs = args.inputs if args.inputs else ['.']

    if args.order_file:
        # Custom order from txt file; inputs serve as base dirs for relative paths
        base_dirs = [p for p in inputs if Path(p).is_dir()] or inputs
        files = collect_files_from_order(args.order_file, base_dirs=base_dirs)
        order_label = f"file:{Path(args.order_file).name}"
    else:
        files = collect_files(inputs, recursive=args.recursive)
        files = sort_files(files, args.sort)
        order_label = args.sort

    files = deduplicate(files)

    if not files:
        print("No supported files found.", file=sys.stderr)
        print("Supported formats: " + ', '.join(sorted(SUPPORTED_EXTS)), file=sys.stderr)
        sys.exit(1)

    if args.list:
        print(f"Would process {len(files)} file(s) (order: {order_label}):")
        for f in files:
            print(f"  {f}")
        return

    mode = f"OCR [{args.lang}]" if args.ocr else "image embed"
    print(f"Merging {len(files)} file(s) -> {args.output}  (order: {order_label}, mode: {mode})")

    pages, errors = merge_to_pdf(
        files, args.output,
        verbose=args.verbose,
        ocr=args.ocr,
        lang=args.lang,
    )

    size_kb = Path(args.output).stat().st_size / 1024
    size_str = f"{size_kb / 1024:.2f} MB" if size_kb >= 1024 else f"{size_kb:.1f} KB"

    if errors:
        print(f"Done with {errors} error(s). Output: {args.output} | {pages} pages | {size_str}")
    else:
        print(f"Done! Output: {args.output} | {pages} pages | {size_str}")


if __name__ == '__main__':
    main()
