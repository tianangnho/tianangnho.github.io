# Image to PDF

Chuyển đổi ảnh sang PDF và nối nhiều file ảnh/PDF thành một file PDF duy nhất.  
Hỗ trợ **OCR** để nhận dạng chữ trong ảnh thành text có thể tìm kiếm/copy (dùng Tesseract).

---

## Tính năng

- Chuyển đổi các định dạng ảnh phổ biến sang PDF: JPG, PNG, BMP, GIF, TIFF, WebP
- Nối nhiều ảnh và/hoặc PDF thành một file PDF theo thứ tự tuỳ chỉnh
- **Sắp xếp tự nhiên** theo mặc định (img2.jpg < img10.jpg, không phải img10 < img2)
- Chế độ OCR: nhúng lớp text vào PDF — chữ có thể select, copy, tìm kiếm
- Hỗ trợ nhiều ngôn ngữ OCR (Tiếng Việt, Tiếng Anh, Tiếng Nhật, Tiếng Trung, …)
- Dry-run (`--list`) để xem trước thứ tự file trước khi convert

---

## Yêu cầu

- Python 3.8 trở lên
- [Pillow](https://pypi.org/project/Pillow/) — xử lý ảnh
- [pypdf](https://pypi.org/project/pypdf/) — xử lý PDF
- *(Tuỳ chọn)* [Tesseract OCR](https://github.com/UB-Mannheim/tesseract/wiki) + [pytesseract](https://pypi.org/project/pytesseract/) — dùng khi cần OCR

---

## Cách dùng nhanh — `run.bat` / `runAdvance.bat`

Dành cho người dùng không quen dòng lệnh:

**`run.bat`** — đơn giản nhất:
1. Double-click `run.bat`
2. Chọn thư mục chứa ảnh
3. Tự tạo file `<tên_thư_mục>.pdf` **bên trong** thư mục đó (sắp xếp tự nhiên, không OCR)
4. Explorer tự mở và highlight file PDF kết quả

**`runAdvance.bat`** — có thêm tuỳ chọn:
1. Chọn thư mục chứa ảnh
2. Hỏi có dùng file `.txt` để chỉ định thứ tự không
3. Hỏi có bật OCR không, và chọn ngôn ngữ
4. Tạo PDF và mở Explorer như `run.bat`

> **Ví dụ:** Chọn thư mục `C:\scan\HoaDon2024` → tạo ra `C:\scan\HoaDon2024\HoaDon2024.pdf`

---

## Cài đặt

### Cài nhanh trên Windows

```
setup.cmd
```

Script sẽ tự kiểm tra Python, cài Pillow và pypdf, và hỏi có muốn cài pytesseract không.

### Cài thủ công

```bash
pip install Pillow pypdf
pip install pytesseract   # tuỳ chọn, chỉ cần khi dùng OCR
```

### Tesseract OCR engine (bắt buộc nếu dùng `--ocr`)

1. Tải về tại: https://github.com/UB-Mannheim/tesseract/wiki  
   Khuyến nghị: `tesseract-ocr-w64-setup-5.x.x.exe`
2. Trong lúc cài, **tick chọn gói ngôn ngữ** cần thiết (ví dụ: Vietnamese, Japanese).
3. Thêm Tesseract vào PATH hệ thống:  
   `C:\Program Files\Tesseract-OCR`
4. Kiểm tra: `tesseract --version`

---

## Cách dùng

```
python image_to_pdf.py [đầu_vào...] [tuỳ_chọn]
```

### Các tham số

| Tham số | Mô tả |
|---------|-------|
| `đầu_vào` | File, thư mục, hoặc glob pattern. Mặc định: thư mục hiện tại |
| `-o FILE` | Đường dẫn file PDF đầu ra (mặc định: `output.pdf`) |
| `-s SORT` | Thứ tự sắp xếp: `natural` / `name` / `mtime` / `none` (mặc định: `natural`) |
| `-f FILE` | File .txt chứa danh sách tên file theo thứ tự tuỳ chỉnh. Ghi đè `-s`. |
| `-r` | Quét thư mục con đệ quy |
| `--ocr` | Chế độ OCR — nhúng text có thể tìm kiếm vào PDF |
| `--lang LANG` | Mã ngôn ngữ Tesseract (mặc định: `eng`) |
| `-v` | Verbose — hiển thị từng file đang xử lý |
| `-l` | Chỉ liệt kê file (dry run), không convert |

---

## Ví dụ

```bash
# Nối tất cả ảnh trong thư mục hiện tại
python image_to_pdf.py

# Nối toàn bộ ảnh trong thư mục photos, lưu thành album.pdf
python image_to_pdf.py photos\ -o album.pdf

# Nối các file chỉ định theo thứ tự đã liệt kê
python image_to_pdf.py bia.png trang1.jpg trang2.jpg -o sach.pdf

# Nối hai file PDF lại
python image_to_pdf.py phan1.pdf phan2.pdf -o full.pdf

# Trộn ảnh và PDF
python image_to_pdf.py bia.jpg noidung.pdf phuluc.png -o baocao.pdf

# Nối hai thư mục, sắp xếp theo tên A–Z
python image_to_pdf.py chuong1\ chuong2\ -s name -o out.pdf

# Xem trước thứ tự file, không convert
python image_to_pdf.py photos\ --list

# OCR — PDF có thể tìm kiếm (tiếng Anh)
python image_to_pdf.py scans\ --ocr -o searchable.pdf

# OCR — Tiếng Việt
python image_to_pdf.py scans\ --ocr --lang vie -o tiengviet.pdf

# OCR — kết hợp nhiều ngôn ngữ
python image_to_pdf.py scans\ --ocr --lang eng+vie -o hocsinh.pdf

# OCR — Tiếng Nhật
python image_to_pdf.py scans\ --ocr --lang jpn -o japanese.pdf

# Quét đệ quy toàn bộ cây thư mục
python image_to_pdf.py archive\ -r -o archive.pdf

# Thứ tự tuỳ chỉnh từ file txt
python image_to_pdf.py photos\ -f order.txt -o out.pdf

# Thứ tự từ file txt, lấy file từ nhiều thư mục
python image_to_pdf.py chuong1\ chuong2\ -f order.txt -o sach.pdf
```

---

## Các chế độ sắp xếp

| Chế độ | Mô tả | Ví dụ |
|--------|-------|-------|
| `natural` *(mặc định)* | Nhận biết số: 1, 2, 10, 20 | img1 < img2 < img10 |
| `name` | A–Z thông thường | img1 < img10 < img2 |
| `mtime` | Thời gian sửa đổi, cũ nhất trước | — |
| `none` | Giữ nguyên thứ tự bạn nhập trên dòng lệnh | — |
| `-f order.txt` | Thứ tự tuỳ chỉnh từ file txt — ghi đè `-s` | — |

### Định dạng file order.txt

Mỗi dòng là một tên file. Dòng bắt đầu bằng `#` là comment, dòng trống bị bỏ qua.
Tên file có thể là tên đơn (tìm trong thư mục đầu vào), đường dẫn tương đối, hoặc tuyệt đối.

```
# order.txt — thứ tự trang tuỳ chỉnh
bia.jpg
loi_mo_dau.png
chuong1/trang1.jpg
chuong1/trang2.jpg
phu_luc.pdf
```

Dùng `--list` để kiểm tra thứ tự trước khi convert:

```bash
python image_to_pdf.py photos\ -f order.txt --list
```

---

## Mã ngôn ngữ OCR (Tesseract)

| Mã | Ngôn ngữ | Mã | Ngôn ngữ |
|----|----------|----|----------|
| `eng` | Tiếng Anh | `vie` | Tiếng Việt |
| `jpn` | Tiếng Nhật | `kor` | Tiếng Hàn |
| `chi_sim` | Tiếng Trung (Giản thể) | `chi_tra` | Tiếng Trung (Phồn thể) |
| `fra` | Tiếng Pháp | `deu` | Tiếng Đức |
| `tha` | Tiếng Thái | `ara` | Tiếng Ả Rập |

Kết hợp nhiều ngôn ngữ: `--lang eng+vie`

Xem danh sách gói đã cài: `tesseract --list-langs`

---

## Lưu ý

- Ảnh PNG/WEBP có nền trong suốt sẽ được ghép lên nền trắng trước khi convert.
- OCR thêm lớp text ẩn vào PDF — không làm thay đổi hình ảnh hiển thị.
- File PDF hiện có được nối trực tiếp (copy từng trang, không render lại).
- Nếu OCR lỗi trên một file, trang đó bị bỏ qua, các file còn lại vẫn được xử lý.

---

## Cấu trúc thư mục

```
imageToPdf/
├── image_to_pdf.py   Script chính
├── run.bat           Chạy nhanh: chọn thư mục, tạo PDF mặc định
├── runAdvance.bat    Chạy có tuỳ chọn: thứ tự từ file txt, OCR
├── pick.ps1          Hộp thoại chọn thư mục/file (hỗ trợ DPI), các file .bat sẽ gọi
├── setup.cmd         Script cài đặt trên Windows
├── README.md         Tài liệu tiếng Anh
└── README_VI.md      Tài liệu tiếng Việt (file này)
```
