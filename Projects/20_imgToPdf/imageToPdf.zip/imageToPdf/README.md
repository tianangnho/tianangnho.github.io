# Image to PDF

Convert images to PDF and merge image/PDF files into one PDF.
Supports **OCR** to produce searchable/selectable text (powered by Tesseract).

---

## Features

- Convert common image formats to PDF: JPG, PNG, BMP, GIF, TIFF, WebP
- Merge multiple images and/or PDFs into a single PDF in any order
- **Natural sort** by default (img2.jpg < img10.jpg, not img10 < img2)
- OCR mode: embed searchable text layer into the PDF
- Multi-language OCR (English, Vietnamese, Japanese, Chinese, …)
- Dry-run (`--list`) to preview file order before converting

---

## Requirements

- Python 3.8+
- [Pillow](https://pypi.org/project/Pillow/) — image processing
- [pypdf](https://pypi.org/project/pypdf/) — PDF manipulation
- *(Optional)* [Tesseract OCR](https://github.com/UB-Mannheim/tesseract/wiki) + [pytesseract](https://pypi.org/project/pytesseract/) — for OCR

---

## Quick start (Windows, no command line)

- **`run.bat`**: double-click it and pick a folder. It creates `<folder_name>.pdf` inside that folder, using natural sort and no OCR.
- **`runAdvance.bat`**: same, but it also asks whether to use an order `.txt` file and whether to turn on OCR (and which language).

---

## Installation

### Quick setup (Windows)

```
setup.cmd
```

The script will check Python, install Pillow and pypdf, and optionally install pytesseract.

### Manual install

```bash
pip install Pillow pypdf
pip install pytesseract   # optional, for OCR
```

### Tesseract OCR engine (required for `--ocr`)

1. Download from: https://github.com/UB-Mannheim/tesseract/wiki  
   Recommended build: `tesseract-ocr-w64-setup-5.x.x.exe`
2. During installation, check extra language packs you need (e.g. Vietnamese, Japanese).
3. Add Tesseract to your system PATH:  
   `C:\Program Files\Tesseract-OCR`
4. Verify: `tesseract --version`

---

## Usage

```
python image_to_pdf.py [inputs...] [options]
```

### Arguments

| Argument | Description |
|----------|-------------|
| `inputs` | Files, folders, or glob patterns. Default: current directory |
| `-o FILE` | Output PDF path (default: `output.pdf`) |
| `-s SORT` | Sort order: `natural` / `name` / `mtime` / `none` (default: `natural`) |
| `-f FILE` | Text file listing filenames in custom order. Overrides `-s`. |
| `-r` | Scan folders recursively |
| `--ocr` | OCR mode — embed searchable text in the PDF |
| `--lang LANG` | Tesseract language code (default: `eng`) |
| `-v` | Verbose — show each file as it is processed |
| `-l` | List files only (dry run), do not convert |

---

## Examples

```bash
# Merge all images in current folder
python image_to_pdf.py

# Merge a folder, save as album.pdf
python image_to_pdf.py photos\ -o album.pdf

# Merge specific files in the given order
python image_to_pdf.py cover.png page1.jpg page2.jpg -o book.pdf

# Merge two PDFs
python image_to_pdf.py part1.pdf part2.pdf -o full.pdf

# Mix images and PDFs
python image_to_pdf.py cover.jpg content.pdf appendix.png -o report.pdf

# Merge two folders, sort alphabetically
python image_to_pdf.py chapter1\ chapter2\ -s name -o out.pdf

# Preview file order without converting
python image_to_pdf.py photos\ --list

# OCR — produce searchable PDF (English)
python image_to_pdf.py scans\ --ocr -o searchable.pdf

# OCR — Vietnamese
python image_to_pdf.py scans\ --ocr --lang vie -o tiengviet.pdf

# OCR — multiple languages at once
python image_to_pdf.py scans\ --ocr --lang eng+vie -o mixed.pdf

# OCR — Japanese
python image_to_pdf.py scans\ --ocr --lang jpn -o japanese.pdf

# Recursive scan of a folder tree
python image_to_pdf.py archive\ -r -o archive.pdf

# Custom order from a txt file
python image_to_pdf.py photos\ -f order.txt -o out.pdf

# Custom order — files from multiple folders
python image_to_pdf.py chapter1\ chapter2\ -f order.txt -o book.pdf
```

---

## Sort modes

| Mode | Description | Example |
|------|-------------|---------|
| `natural` *(default)* | Numeric-aware: 1, 2, 10, 20 | img1 < img2 < img10 |
| `name` | Plain A–Z | img1 < img10 < img2 |
| `mtime` | File modification time, oldest first | — |
| `none` | Keep the order you specified on the command line | — |
| `-f order.txt` | Custom order from a text file — overrides `-s` | — |

### Order file format

One filename per line. Lines starting with `#` are comments and blank lines are ignored.
Filenames can be bare names (resolved against the input folder), relative paths, or absolute paths.

```
# order.txt — custom page order
cover.jpg
intro.png
chapter1/page1.jpg
chapter1/page2.jpg
appendix.pdf
```

Use `--list` to verify the final order before converting:

```bash
python image_to_pdf.py photos\ -f order.txt --list
```

---

## OCR language codes (Tesseract)

| Code | Language | Code | Language |
|------|----------|------|----------|
| `eng` | English | `vie` | Vietnamese |
| `jpn` | Japanese | `kor` | Korean |
| `chi_sim` | Chinese (Simplified) | `chi_tra` | Chinese (Traditional) |
| `fra` | French | `deu` | German |
| `tha` | Thai | `ara` | Arabic |

Combine languages: `--lang eng+vie`

List installed packs: `tesseract --list-langs`

---

## Notes

- Transparent PNG/WEBP images are composited on a white background before conversion.
- OCR adds a searchable invisible text layer without altering the visual appearance.
- Existing PDF files are merged as-is (pages copied without re-rendering).
- If OCR errors on a file, that page is skipped and the rest are still merged.

---

## Project structure

```
imageToPdf/
├── image_to_pdf.py   Main script
├── run.bat           Quick launcher: pick folder, default output
├── runAdvance.bat    Launcher with options: order file, OCR
├── pick.ps1          DPI-aware folder/file dialog used by the .bat launchers
├── setup.cmd         Windows setup script
├── README.md         This file
└── README_VI.md      Vietnamese documentation
```
