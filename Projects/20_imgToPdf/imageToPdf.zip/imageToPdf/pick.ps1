param(
    [Parameter(Mandatory = $true)][ValidateSet('folder', 'file')][string]$Mode,
    [Parameter(Mandatory = $true)][string]$OutFile,
    [string]$InitialDir = ''
)

# Must run before any window is created, otherwise dialogs are bitmap-scaled (blurry) at 125%+.
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class DpiHelper {
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
}
'@
[DpiHelper]::SetProcessDPIAware() | Out-Null

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

# Invisible topmost owner so the dialog appears in front of other windows.
$owner = New-Object System.Windows.Forms.Form
$owner.TopMost = $true

$result = $null
if ($Mode -eq 'folder') {
    $d = New-Object System.Windows.Forms.FolderBrowserDialog
    $d.Description = 'Chon thu muc chua anh can chuyen doi sang PDF'
    $d.ShowNewFolderButton = $false
    if ($d.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) { $result = $d.SelectedPath }
} else {
    $d = New-Object System.Windows.Forms.OpenFileDialog
    $d.Title = 'Chon file .txt chua danh sach thu tu'
    $d.Filter = 'Text files (*.txt)|*.txt|All files (*.*)|*.*'
    if ($InitialDir) { $d.InitialDirectory = $InitialDir }
    if ($d.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) { $result = $d.FileName }
}
$owner.Dispose()

# UTF-8 without BOM so Vietnamese folder names survive; run.bat reads it under chcp 65001.
if ($result) { [System.IO.File]::WriteAllText($OutFile, $result) }
