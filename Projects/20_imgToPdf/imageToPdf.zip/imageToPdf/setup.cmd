@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1

echo ============================================================
echo   Image to PDF - Setup
echo ============================================================
echo.

:: ── 1. Check Python ──────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found in PATH.
    echo.
    echo   Please install Python 3.8+ from: https://www.python.org/downloads/
    echo   IMPORTANT: Check "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('python --version 2^>^&1') do set PYVER=%%i
echo [OK] %PYVER%

:: ── 2. Check pip ─────────────────────────────────────────────
pip --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] pip not available. Trying to install...
    python -m ensurepip --upgrade
    if errorlevel 1 (
        echo [ERROR] Could not install pip. Please install it manually.
        pause
        exit /b 1
    )
)
echo [OK] pip found.
echo.

:: ── 3. Upgrade pip silently ───────────────────────────────────
echo Upgrading pip...
python -m pip install --upgrade pip --quiet

:: ── 4. Install core packages ──────────────────────────────────
echo Installing required packages: Pillow, pypdf ...
pip install Pillow pypdf

if errorlevel 1 (
    echo.
    echo [ERROR] Package installation failed.
    echo   Try running this script as Administrator, or run manually:
    echo     pip install --user Pillow pypdf
    echo.
    pause
    exit /b 1
)
echo.

:: ── 5. Optional: Tesseract OCR ───────────────────────────────
echo ============================================================
echo   OCR Support (optional - for searchable text in PDF)
echo ============================================================
echo.
echo   To enable OCR (--ocr flag), two steps are needed:
echo.
echo   STEP A: Install Tesseract OCR engine
echo     Download: https://github.com/UB-Mannheim/tesseract/wiki
echo     Recommended: tesseract-ocr-w64-setup-5.x.x.exe
echo     During install, select extra language packs (e.g. Vietnamese, Japanese).
echo     After install, add Tesseract to PATH, e.g.:
echo       C:\Program Files\Tesseract-OCR
echo.
echo   STEP B: Install Python binding
echo     pip install pytesseract
echo.

set /p INSTALL_OCR=Install pytesseract Python package now? [Y/N]:
if /i "!INSTALL_OCR!"=="Y" (
    pip install pytesseract
    echo.
    echo [NOTE] pytesseract installed. Still need Tesseract engine from the link above.
) else (
    echo [skip] pytesseract skipped. You can install it later with: pip install pytesseract
)

:: ── 6. Verify Tesseract presence ─────────────────────────────
echo.
tesseract --version >nul 2>&1
if errorlevel 1 (
    echo [INFO] Tesseract engine: not found in PATH  (OCR will not work until installed)
) else (
    for /f "tokens=*" %%i in ('tesseract --version 2^>^&1') do (
        echo [OK] %%i
        goto :tess_done
    )
    :tess_done
)

:: ── 7. Done ───────────────────────────────────────────────────
echo.
echo ============================================================
echo   Setup complete!
echo ============================================================
echo.
echo Quick start:
echo   python image_to_pdf.py                          Convert all images in current folder
echo   python image_to_pdf.py photos\ -o album.pdf     Convert a folder
echo   python image_to_pdf.py a.pdf b.pdf -o out.pdf   Merge PDFs
echo   python image_to_pdf.py scan\ --ocr -o text.pdf  OCR (English)
echo   python image_to_pdf.py scan\ --ocr --lang vie    OCR Vietnamese
echo   python image_to_pdf.py -h                       Show full help
echo.
pause
