@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Image to PDF Converter

echo.
echo  ====================================================
echo    Image to PDF Converter
echo  ====================================================
echo.

:: ==========================================================
:: 1. Kiem tra script va Python
:: ==========================================================
set "SCRIPT=%~dp0image_to_pdf.py"
set "PICKER=%~dp0pick.ps1"
set "PICK_OUT=%TEMP%\imgtopdf_pick_%RANDOM%.txt"

if not exist "%SCRIPT%" (
    echo  [LOI] Khong tim thay image_to_pdf.py
    echo        Hay dat run.bat cung thu muc voi image_to_pdf.py
    echo.
    pause
    exit /b 1
)
if not exist "%PICKER%" (
    echo  [LOI] Khong tim thay pick.ps1
    echo        Hay dat run.bat cung thu muc voi pick.ps1
    echo.
    pause
    exit /b 1
)

python --version >nul 2>&1
if errorlevel 1 (
    echo  [LOI] Khong tim thay Python.
    echo        Hay chay setup.cmd truoc de cai dat.
    echo.
    pause
    exit /b 1
)

:: ==========================================================
:: 2. Chon thu muc chua anh
:: ==========================================================
echo  [1/3] Chon thu muc chua anh...
echo.

:: Dialog runs in a separate hidden console so this window's font/DPI is not touched.
del "%PICK_OUT%" >nul 2>&1
start "" /wait /min powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%PICKER%" -Mode folder -OutFile "%PICK_OUT%"

set "SELECTED_FOLDER="
if exist "%PICK_OUT%" (
    set /p SELECTED_FOLDER=<"%PICK_OUT%"
    del "%PICK_OUT%" >nul 2>&1
)

if not defined SELECTED_FOLDER (
    echo  Da huy.
    pause
    exit /b 0
)

for %%I in ("!SELECTED_FOLDER!") do set "FOLDER_NAME=%%~nxI"
set "OUTPUT_PDF=!SELECTED_FOLDER!\!FOLDER_NAME!.pdf"

echo  Thu muc : !SELECTED_FOLDER!
echo  Dau ra  : !OUTPUT_PDF!
echo.

:: ==========================================================
:: 3. Chon thu tu (order file - tuy chon)
:: ==========================================================
echo  [2/3] Thu tu file
echo  ----------------------------------------------------
echo   Mac dinh: sap xep tu nhien (vd: 1, 2, 10, 11...)
echo   Tuy chon: dung file .txt - moi dong ghi 1 ten file
echo  ----------------------------------------------------
echo.
choice /C YN /M "  Dung file .txt de chi dinh thu tu?" /T 10 /D N

set "ORDER_ARGS="
if !ERRORLEVEL!==1 (
    del "%PICK_OUT%" >nul 2>&1
    start "" /wait /min powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%PICKER%" -Mode file -OutFile "%PICK_OUT%" -InitialDir "!SELECTED_FOLDER!"

    set "ORDER_FILE="
    if exist "%PICK_OUT%" (
        set /p ORDER_FILE=<"%PICK_OUT%"
        del "%PICK_OUT%" >nul 2>&1
    )
    if defined ORDER_FILE (
        set "ORDER_ARGS=--order-file "!ORDER_FILE!""
        echo   - Thu tu tu file: !ORDER_FILE!
    ) else (
        echo   - Khong chon file, dung sap xep tu nhien
    )
) else (
    echo   - Sap xep tu nhien
)

:: ==========================================================
:: 4. Che do OCR (tuy chon)
:: ==========================================================
echo.
echo  [3/3] Che do OCR
echo  ----------------------------------------------------
echo   OCR nhan dang chu trong anh thanh text co the
echo   select / copy / tim kiem trong PDF.
echo   Yeu cau: Tesseract da cai dat (xem README_VI.md)
echo  ----------------------------------------------------
echo.
choice /C YN /M "  Bat OCR?" /T 15 /D N

set "OCR_ARGS="
if !ERRORLEVEL!==1 (
    echo.
    echo   Ngon ngu: vie=Viet  eng=Anh  vie+eng=ca hai  jpn=Nhat
    set /p "USER_LANG=  Nhap ngon ngu [Enter = vie+eng]: "
    if "!USER_LANG!"=="" set "USER_LANG=vie+eng"
    set "OCR_ARGS=--ocr --lang !USER_LANG!"
    echo   - OCR bat: !USER_LANG!
) else (
    echo   - OCR tat
)

:: ==========================================================
:: 5. Chay chuyen doi
:: ==========================================================
echo.
echo  ====================================================
echo    Dang xu ly...
echo  ====================================================
echo.

python "%SCRIPT%" "!SELECTED_FOLDER!" -o "!OUTPUT_PDF!" -v !ORDER_ARGS! !OCR_ARGS!
set "EXIT_CODE=!ERRORLEVEL!"

echo.
echo  ====================================================

if !EXIT_CODE! neq 0 (
    echo    [LOI] Chuyen doi that bai. Xem thong bao o tren.
    echo  ====================================================
    echo.
    pause
    exit /b !EXIT_CODE!
)

echo    [OK] Hoan thanh!
echo  ====================================================
echo.
echo  Dang mo thu muc ket qua...
explorer /select,"!OUTPUT_PDF!"

pause
