@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Image to PDF Converter

echo.
echo  ====================================================
echo    Image to PDF Converter
echo  ====================================================
echo.

set "SCRIPT=%~dp0image_to_pdf.py"
set "PICKER=%~dp0pick.ps1"
set "PICK_OUT=%TEMP%\imgtopdf_pick_%RANDOM%.txt"

if not exist "%SCRIPT%" (
    echo  [LOI] Khong tim thay image_to_pdf.py
    pause
    exit /b 1
)
if not exist "%PICKER%" (
    echo  [LOI] Khong tim thay pick.ps1
    pause
    exit /b 1
)
python --version >nul 2>&1
if errorlevel 1 (
    echo  [LOI] Khong tim thay Python. Hay chay setup.cmd truoc.
    pause
    exit /b 1
)

echo  Chon thu muc chua anh...
echo.

:: Dialog runs in a separate hidden console so this window's font/DPI is not touched.
start "" /wait /min powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%PICKER%" -Mode folder -OutFile "%PICK_OUT%"

set "SELECTED_FOLDER="
if exist "%PICK_OUT%" (
    set /p SELECTED_FOLDER=<"%PICK_OUT%"
    del "%PICK_OUT%" >nul 2>&1
)
if not defined SELECTED_FOLDER (
    echo  Da huy.
    pause
    exit /b 0
)

for %%I in ("!SELECTED_FOLDER!") do set "FOLDER_NAME=%%~nxI"
set "OUTPUT_PDF=!SELECTED_FOLDER!\!FOLDER_NAME!.pdf"

echo  Thu muc : !SELECTED_FOLDER!
echo  Dau ra  : !OUTPUT_PDF!
echo.

python "%SCRIPT%" "!SELECTED_FOLDER!" -o "!OUTPUT_PDF!" -v
set "EXIT_CODE=!ERRORLEVEL!"

echo.
echo  ====================================================
if !EXIT_CODE! neq 0 (
    echo    [LOI] Chuyen doi that bai. Xem thong bao o tren.
    echo  ====================================================
    echo.
    pause
    exit /b !EXIT_CODE!
)
echo    [OK] Hoan thanh!
echo  ====================================================
echo.
explorer /select,"!OUTPUT_PDF!"

pause
