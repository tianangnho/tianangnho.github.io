"""Read the subtitles of a video aloud into an .mp3, then put that voice and the subtitles into the video.

    python dub_video.py demo.mp4 demo.srt                      # writes demo.mp3 and demo_final.mp4
    python dub_video.py demo.mp4 demo.srt --voice Zira --rate 2
    python dub_video.py demo.mp4 demo.srt --subs burn --codec h264
    python dub_video.py demo.mp4 demo.srt --copy-video --mix
    python dub_video.py demo.mp4 demo.srt --out-dir Output

The two steps are those of read_subtitles.py (--save demo.mp3 --timed: each
entry is said at its time, so the voice fits the video) and of
merge_video_audio.py (the voice replaces the sound of the video, unless --mix;
the subtitles are a track, or drawn into the picture with --subs burn).
Without --voice, the voices are listed to choose one.
"""
import argparse
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    summary, _, details = __doc__.partition("\n")
    ap = argparse.ArgumentParser(description=summary, epilog="examples:" + details,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video", help="the video, .mp4")
    ap.add_argument("srt", help="its subtitles, .srt")
    ap.add_argument("--out-dir", help="folder of the .mp3 and the video; default: that of the video")
    ap.add_argument("--mp3", help="name of the .mp3; default <video>.mp3")
    ap.add_argument("-o", "--output", help="name of the video; default <video>_final.mp4")
    ap.add_argument("--voice", help="number or part of the name of the voice (see read_subtitles.py --list-voices)")
    ap.add_argument("--rate", type=int, default=0, help="speed of the voice, -10 to 10; default 0")
    ap.add_argument("--bitrate", default="64k", help="bitrate of the .mp3; default 64k")
    ap.add_argument("--subs", choices=["soft", "burn", "none"], default="soft",
                    help="soft: a subtitle track (default); burn: drawn into the picture; none: no subtitles")
    ap.add_argument("--codec", choices=["h265", "h264"], default="h265", help="default h265 (smallest)")
    ap.add_argument("--copy-video", action="store_true", help="keep the picture as it is (fast; not with --subs burn)")
    ap.add_argument("--mix", action="store_true", help="mix the voice with the sound of the video")
    ap.add_argument("--keep-cues", action="store_true", help="keep the [ACTION] and (...) lines in the subtitles")
    args = ap.parse_args()

    for path in (args.video, args.srt):
        if not os.path.isfile(path):
            sys.exit(f"{path} does not exist")
    if args.copy_video and args.subs == "burn":
        sys.exit("--subs burn draws into the picture, which --copy-video keeps as it is: use one or the other")

    out_dir = args.out_dir or os.path.dirname(os.path.abspath(args.video))
    os.makedirs(out_dir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(args.video))[0]
    mp3 = args.mp3 or os.path.join(out_dir, stem + ".mp3")
    output = args.output or os.path.join(out_dir, stem + "_final.mp4")

    print(f"1/2  voice -> {mp3}", flush=True)
    read = [sys.executable, os.path.join(HERE, "read_subtitles.py"), args.srt, "--save", mp3, "--timed",
            f"--rate={args.rate}", "--bitrate", args.bitrate]
    if args.voice:
        read += ["--voice", args.voice]
    if subprocess.run(read).returncode != 0 or not os.path.isfile(mp3):
        sys.exit("the voice could not be made")

    print(f"\n2/2  video -> {output}", flush=True)
    merge = [sys.executable, os.path.join(HERE, "merge_video_audio.py"), args.video, mp3, args.srt,
             "--subs", args.subs, "-o", output]
    merge += ["--copy-video"] if args.copy_video else ["--codec", args.codec]
    if args.mix:
        merge += ["--mix"]
    if args.keep_cues:
        merge += ["--keep-cues"]
    if subprocess.run(merge).returncode != 0:
        sys.exit("the video could not be made")
    print(f"\ndone:\n  {mp3}\n  {output}")


if __name__ == "__main__":
    main()
