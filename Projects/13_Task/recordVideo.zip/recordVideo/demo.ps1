<#
.SYNOPSIS
    Demo of the Renesas MBS to CMake Converter (mbs2cmake).

.DESCRIPTION
    Copies an e2 studio project to a demo folder, then, step by step:
    converts it, shows the generated files, configures and builds it with
    CMake, compares the binary with the e2 studio build, explains a compiler
    option with inspect-command, lists the files each configuration builds
    with inspect-sources, writes compile_commands.json with compile-commands,
    and opens the project in VS Code.
    The original project is never changed.

.EXAMPLE
    .\demo.ps1                       # the demo, with a pause before each step
    .\demo.ps1 -NoPause              # rehearsal, without pauses
    .\demo.ps1 -FspVersion 6.6.0     # configure the copy with FSP 6.6.0
    .\demo.ps1 -Reset                # delete the demo folder
    .\demo.ps1 -Project D:\ws\RA_App -Work C:\demo\RA_App
#>
param(
    # The e2 studio project to show; it is copied, never changed.
    [string]$Project = "C:\00_myfolders\00_Todo\2026\RA_MBS\RA_GNU_CPP_EXE",
    # The demo folder the project is copied to.
    [string]$Work = "C:\demo\RA_Project",
    # The converter; default: mbs2cmake-windows-amd64.exe on PATH, or built from this repository.
    [string]$Converter = "",
    # The build configuration to build.
    [string]$Config = "Debug",
    # The source file whose optimization option inspect-command explains; default: src/hal_entry.c or .cpp.
    [string]$InspectFile = "",
    # The FSP version to configure the copy with. Default: that of the project
    # when RASC has it, else the highest one RASC has, such as 6.6.0.
    [string]$FspVersion = "",
    [switch]$NoPause,
    # Do not open VS Code at the end.
    [switch]$NoVSCode,
    [switch]$Reset
)

$ErrorActionPreference = "Stop"

function Step([string]$title) {
    Write-Host ""
    Write-Host ("=" * 78) -ForegroundColor DarkCyan
    Write-Host "  $title" -ForegroundColor Cyan
    Write-Host ("=" * 78) -ForegroundColor DarkCyan
}

function Pause-Demo([string]$next) {
    if ($NoPause) { return }
    Write-Host ""
    Read-Host "Press Enter to $next" | Out-Null
}

function Show([string]$text) { Write-Host $text -ForegroundColor Gray }

# Runs a command in the demo folder, after printing it as the audience sees it.
function Run([string]$command, [switch]$AllowFailure) {
    Write-Host ""
    Write-Host "PS $Work> " -ForegroundColor Green -NoNewline
    Write-Host $command -ForegroundColor Yellow
    Push-Location $Work
    try {
        $global:LASTEXITCODE = 0
        Invoke-Expression $command | Out-Host
        $code = $LASTEXITCODE
    } finally {
        Pop-Location
    }
    if ($code -ne 0 -and -not $AllowFailure) {
        throw "'$command' failed with exit code $code"
    }
    return $code
}

function Fail([string]$message) {
    Write-Host "  [X] $message" -ForegroundColor Red
    $script:problems++
}

function Ok([string]$message) { Write-Host "  [OK] $message" -ForegroundColor Green }

if ($Reset) {
    if (Test-Path $Work) {
        Remove-Item -Recurse -Force $Work
        Write-Host "Deleted $Work"
    } else {
        Write-Host "$Work does not exist"
    }
    return
}

# ---------------------------------------------------------------- step 0
Step "0. Check the environment"
$script:problems = 0

if (-not (Test-Path (Join-Path $Project ".cproject"))) { Fail "$Project is not an e2 studio project (no .cproject)" } else { Ok "project: $Project" }
foreach ($tool in "cmake", "ninja") {
    if (Get-Command $tool -ErrorAction SilentlyContinue) { Ok "$tool found" } else { Fail "$tool is not on PATH" }
}

$llvm = (Get-Content (Join-Path $Project ".cproject") -Raw) -match "managedbuild\.llvm"
$toolchainVar = if ($llvm) { "ARM_LLVM_TOOLCHAIN_PATH" } else { "ARM_GCC_TOOLCHAIN_PATH" }
$toolchainDir = [Environment]::GetEnvironmentVariable($toolchainVar)
if ($toolchainDir -and (Test-Path $toolchainDir)) { Ok "$toolchainVar = $toolchainDir" } else { Fail "set $toolchainVar to the bin folder of the toolchain" }

$rasc = $env:RASC_EXE_PATH
$xml = Join-Path $Project "configuration.xml"
$fsp = ""
if (Test-Path $xml) {
    $m = Select-String -Path $xml -Pattern 'key="#FSPVersion#" value="([^"]+)"' | Select-Object -First 1
    if ($m) { $fsp = $m.Matches[0].Groups[1].Value }
}
if (-not $rasc -or -not (Test-Path $rasc)) {
    Fail "set RASC_EXE_PATH to rasc.exe of the FSP Smart Configurator"
} else {
    Ok "RASC_EXE_PATH = $rasc"
    if ($fsp) {
        # The FSP versions RASC has, from its packs: Renesas.RA_mcu_ra0e1.6.6.0.pack
        $root = Split-Path (Split-Path $rasc)
        $have = Get-ChildItem $root -Recurse -Depth 6 -Filter "Renesas.RA_*.pack" -ErrorAction SilentlyContinue |
            ForEach-Object { if ($_.Name -match '\.(\d+\.\d+\.\d+)\.pack$') { $Matches[1] } } |
            Sort-Object -Unique { [version]$_ }
        if (-not $FspVersion) {
            $FspVersion = if ($have -contains $fsp) { $fsp } else { $have | Select-Object -Last 1 }
        }
        if (-not $FspVersion) {
            Fail "RASC has no FSP pack"
        } elseif ($have -notcontains $FspVersion) {
            Fail "RASC has no pack of FSP $FspVersion; it has: $($have -join ', ')"
        } elseif ($FspVersion -ne $fsp) {
            Write-Host "  [!] the project uses FSP $fsp, which RASC does not have: the copy is configured with FSP $FspVersion" -ForegroundColor Yellow
        } else {
            Ok "RASC has the packs of FSP $fsp, the version of the project"
        }
    }
}

if (-not $Converter) {
    $onPath = Get-Command "mbs2cmake-windows-amd64.exe" -ErrorAction SilentlyContinue
    if ($onPath) {
        $Converter = $onPath.Source
    } else {
        $Converter = Join-Path $env:TEMP "mbs2cmake-demo\mbs2cmake-windows-amd64.exe"
        Show "  building the converter from $PSScriptRoot ..."
        Push-Location $PSScriptRoot
        try { go build -o $Converter ./cmd/mbs2cmake } finally { Pop-Location }
        if ($LASTEXITCODE -ne 0) { throw "go build failed" }
    }
}
Ok "converter: $Converter"
$env:PATH = (Split-Path $Converter) + ";" + $env:PATH

if ($script:problems -gt 0) {
    Write-Host ""
    Write-Host "Fix the $($script:problems) problem(s) above before the demo." -ForegroundColor Red
    exit 1
}

if (Test-Path $Work) { Remove-Item -Recurse -Force $Work }
New-Item -ItemType Directory -Force (Split-Path $Work) | Out-Null
Copy-Item -Recurse $Project $Work
Ok "project copied to $Work"
$fspChanged = $fsp -and $FspVersion -and $FspVersion -ne $fsp
if ($fspChanged) {
    $copy = Join-Path $Work "configuration.xml"
    (Get-Content $copy -Raw).Replace($fsp, $FspVersion) | Set-Content -NoNewline -Encoding utf8 $copy
    Write-Host "  [!] configuration.xml of the copy: FSP $fsp replaced by FSP $FspVersion" -ForegroundColor Yellow
}
$name = Split-Path $Project -Leaf
$e2Elf = Join-Path $Work "$Config\$name.elf"
Pause-Demo "start the demo"

# ---------------------------------------------------------------- step 1
Step "1. The e2 studio project: settings in .cproject, built by e2 studio"
Show "  The build depends on e2 studio: .cproject holds the settings, e2 studio writes the makefiles."
Run "Get-ChildItem -Name -Force | Select-String -NotMatch '^\.(api_xml|secure_)'" | Out-Null
Pause-Demo "convert the project"

# ---------------------------------------------------------------- step 2
Step "2. Convert the project with one command"
Run "mbs2cmake-windows-amd64.exe convert ." | Out-Null
Show ""
Show "  Every configuration is converted; warnings tell where the CMake build differs from e2 studio."
Pause-Demo "look at the generated files"

# ---------------------------------------------------------------- step 3
Step "3. The generated files"
Show "  One CMake preset per build configuration:"
Run "Select-String -Path CMakePresets.json -Pattern '`"name`"' | ForEach-Object { `$_.Line.Trim() }" | Out-Null
Show ""
Show "  The compiler options of e2 studio, as they are:"
Run "Get-Content cmake\$Config\ConvertedMbsOptions.cmake | Select-Object -Skip 20 -First 14" | Out-Null
$lib = Get-ChildItem $Work -Recurse -Filter CMakeLists.txt | Select-String "add_library\(" | Select-Object -First 1
if ($lib) {
    Show ""
    Show "  A file with settings of its own keeps its options, in an object library:"
    $rel = $lib.Path.Substring($Work.Length + 1)
    Run "Select-String -Path '$rel' -Pattern 'add_library\(' -Context 0,2 | ForEach-Object { `$_.Line; `$_.Context.PostContext }" | Out-Null
}
Pause-Demo "build with CMake"

# ---------------------------------------------------------------- step 4
Step "4. Build with CMake, without e2 studio"
Show "  Configuring runs RASC to generate the FSP code (about 20 seconds)."
Run "cmake --preset $Config" | Out-Null
Run "cmake --build build/$Config" | Out-Null
Run "Get-ChildItem build\$Config\$name.* -Name" | Out-Null
Pause-Demo "compare with the e2 studio build"

# ---------------------------------------------------------------- step 5
Step "5. Compare with the e2 studio build"
$size = if ($llvm) { Join-Path $toolchainDir "llvm-size.exe" } else { Join-Path $toolchainDir "arm-none-eabi-size.exe" }
$cmakeElf = Join-Path $Work "build\$Config\$name.elf"
if ((Test-Path $e2Elf) -and (Test-Path $size)) {
    Run "& '$size' '$Config\$name.elf' 'build\$Config\$name.elf'" | Out-Null
    $rows = & $size $e2Elf $cmakeElf | Select-Object -Skip 1 | ForEach-Object { ($_ -split "\s+" | Where-Object { $_ })[0..2] -join "/" }
    if ($rows[0] -eq $rows[1]) {
        Write-Host ""
        Write-Host "  text, data and bss are the same as in e2 studio." -ForegroundColor Green
    } elseif ($fspChanged) {
        Write-Host ""
        Write-Host "  The sizes differ: e2 studio built the project with FSP $fsp, CMake with FSP $FspVersion." -ForegroundColor Yellow
    } else {
        Write-Host ""
        Write-Host "  The sizes differ: see 'Absolute source paths' in the manual (__FILE__ strings)." -ForegroundColor Yellow
    }
} else {
    Show "  No e2 studio build ($e2Elf) to compare with: build the project in e2 studio before the demo."
}
Pause-Demo "explain a compiler option"

# ---------------------------------------------------------------- step 6
Step "6. Where does an option come from?"
if (-not $InspectFile) {
    $InspectFile = @("src/hal_entry.c", "src/hal_entry.cpp") | Where-Object { Test-Path (Join-Path $Work $_) } | Select-Object -First 1
}
if ($InspectFile) {
    Run "mbs2cmake-windows-amd64.exe inspect-command . --config $Config --path $InspectFile --flag -O" | Out-Null
} else {
    Show "  No src/hal_entry.c or .cpp: pass -InspectFile <file>."
}
Pause-Demo "list the files each configuration builds"

# ---------------------------------------------------------------- step 7
Step "7. Which files does each configuration build?"
Show "  inspect-sources lists the files a configuration builds, with which tool,"
Show "  the files with settings of their own, and the files excluded from the build."
Run "mbs2cmake-windows-amd64.exe inspect-sources . --config $Config" | Out-Null
$presets = Get-Content (Join-Path $Work "CMakePresets.json") -Raw | ConvertFrom-Json
$other = $presets.configurePresets | Where-Object { -not $_.hidden -and $_.name -ne $Config } | Select-Object -First 1 -ExpandProperty name
if ($other) {
    Show ""
    Show "  Another configuration can build other files. The summary of $other :"
    Run "mbs2cmake-windows-amd64.exe inspect-sources . --config $other | Select-String -Pattern 'configuration builds|\(\d+ files?\)|Excluded'" | Out-Null
}
Pause-Demo "write compile_commands.json"

# ---------------------------------------------------------------- step 8
Step "8. Code completion for an e2 studio project: compile_commands.json"
Show "  compile-commands writes the command e2 studio runs to compile each file,"
Show "  for clangd and other editors, without converting the project."
Run "mbs2cmake-windows-amd64.exe compile-commands . --config $Config -o compile_commands.json --toolchain-dir '$toolchainDir'" | Out-Null
Show ""
Show "  The first entry:"
Run "`$cc = Get-Content compile_commands.json -Raw | ConvertFrom-Json; `"`$(`$cc.Count) entries`"; `$cc[0].file; (`$cc[0].arguments | Select-Object -First 6) -join ' '" | Out-Null
Show ""
Show "  The converted CMake project writes its own compile_commands.json when it is configured;"
Show "  compile-commands is for the projects you keep building in e2 studio."
Pause-Demo "open the project in VS Code"

# ---------------------------------------------------------------- step 9
Step "9. VS Code"
Show "  In VS Code: select the preset on the status bar, press F7 to build,"
Show "  Terminal > Run Task... for the tasks, F5 to debug (with a board)."
if ($NoVSCode) {
    Show "  (-NoVSCode: VS Code is not opened)"
} elseif (Get-Command code -ErrorAction SilentlyContinue) {
    Run "code ." | Out-Null
} else {
    Show "  VS Code (code) is not on PATH: open $Work in VS Code by hand."
}

Step "Done"
Show "  Demo folder: $Work"
Show "  Delete it with: .\demo.ps1 -Reset -Work '$Work'"
