"""Turn a Word file (.docx, .doc, .rtf...) or a PDF into Full HD images (1920x1080) and
a video, in the style of make_title.py / make_image.py: dark background, the pages on it.

Two ways to show the pages (--mode):
    page    (default) one image per page, the whole page; the video shows each page
            --seconds (default 4) with a cross-fade to the next one
    scroll  the pages one under the other, as wide as the frame (easy to read); the
            images are the screens of it from top to bottom, and the video scrolls
            through it, --seconds (default 8) for each page

Text lines are optional and use the styles of make_title.py; they go on the left
of the pages. --page-numbers adds "page / pages" on the right of the footer (--mode page).

    python make_word.py                                     (dialogs ask for the file)
    python make_word.py guide.docx --video
    python make_word.py guide.docx --video --mode scroll --pages 2-4
    python make_word.py guide.docx -f caption.txt --video --page-numbers
    python make_word.py manual.pdf --video --seconds 3

The images and the video go into -o (default: Output\\<YYYY-MM-DD_hh>\\<file name>).
Word itself makes the PDF, so Word must be installed (not needed for a .pdf);
needs PyMuPDF (pip install pymupdf), Pillow and ffmpeg.
"""
import argparse
import datetime
import os
import shutil
import tempfile

from PIL import Image

from make_image import FPS, FRAME_FILL, Slide, choose_file, encode, unused
from make_title import parse_sizes, read_lines

HERE = os.path.dirname(os.path.abspath(__file__))
PAGE_WIDTH = 1700            # pixels a page is rendered at (the widest frame)
PAGE_GAP = 36                # between the pages with --mode scroll
CROSS_FADE = 0.5             # seconds, between two pages with --mode page
WORD_FILES = ("Word", "*.docx *.doc *.docm *.rtf *.odt *.pdf")


def word_to_pdf(src, pdf):
    """Makes pdf from the Word file src with a hidden Word of its own (an open Word is not touched)."""
    try:
        import win32com.client
    except ImportError:
        raise SystemExit("make_word: pywin32 is needed to drive Word (pip install pywin32); "
                         "or save the file as PDF in Word and give the .pdf")
    try:
        word = win32com.client.DispatchEx("Word.Application")
    except Exception as e:
        raise SystemExit(f"make_word: cannot start Word ({e}); save the file as PDF and give the .pdf")
    try:
        word.Visible = False
        word.DisplayAlerts = 0
        doc = word.Documents.Open(os.path.abspath(src), ConfirmConversions=False, ReadOnly=True,
                                  AddToRecentFiles=False, Visible=False)
        try:
            doc.ExportAsFixedFormat(OutputFileName=os.path.abspath(pdf), ExportFormat=17,  # PDF
                                    OpenAfterExport=False, OptimizeFor=0)               # for print
        finally:
            doc.Close(False)
    except Exception as e:
        raise SystemExit(f"make_word: Word could not make a PDF of {src}: {e}")
    finally:
        word.Quit()


def parse_pages(text, count):
    """'1-3,5' -> [0, 1, 2, 4] (0-based); None or '' -> every page."""
    if not text:
        return list(range(count))
    pages = []
    for part in text.replace(" ", "").split(","):
        first, _, last = part.partition("-")
        try:
            a, b = int(first), int(last or first)
        except ValueError:
            raise SystemExit(f"make_word: '{part}' in --pages is not a page or a range like 2-5")
        if not (1 <= a <= b <= count):
            raise SystemExit(f"make_word: pages {part} are not in 1..{count}")
        pages += [p - 1 for p in range(a, b + 1) if p - 1 not in pages]
    return pages


def render_pages(pdf, pages):
    """The pages as RGB images PAGE_WIDTH pixels wide."""
    import pymupdf
    images = []
    with pymupdf.open(pdf) as doc:
        for n in pages:
            page = doc[n]
            pix = page.get_pixmap(matrix=pymupdf.Matrix(PAGE_WIDTH / page.rect.width,
                                                         PAGE_WIDTH / page.rect.width), alpha=False)
            images.append(Image.frombytes("RGB", (pix.width, pix.height), pix.samples))
    return images


def page_count(pdf):
    import pymupdf
    with pymupdf.open(pdf) as doc:
        return doc.page_count


def with_page_number(lines, name, number, total):
    """lines with a footer whose right part ends with 'number / total'."""
    body = [line for line in lines if not line.startswith("---")]
    footers = [line[3:] for line in lines if line.startswith("---")]
    left, _, right = (footers[-1] if footers else name).partition("|")
    right = right.strip()
    right = f"{right}  ·  {number} / {total}" if right else f"{number} / {total}"
    return body + [f"--- {left.strip()} | {right}"]


# ---------------------------------------------------------------- --mode page

def page_slides(images, numbers, total, lines, args, name):
    """A Slide for each page, made when it is needed."""
    for img, number in zip(images, numbers):
        page_lines = with_page_number(lines, name, number, total) if args.page_numbers else lines
        yield Slide(img, page_lines, args.sizes, "left", args.bar, "none").frame_at(0)


def page_frames(slides, seconds):
    """Each slide for seconds, with a cross-fade into the next one."""
    per, xf = max(2, round(seconds * FPS)), round(CROSS_FADE * FPS)
    current = next(slides)
    for following in slides:
        for _ in range(per - xf):
            yield current
        for k in range(xf):
            yield Image.blend(current, following, (k + 1) / (xf + 1))
        current = following
    for _ in range(per):
        yield current


def run_page_mode(images, numbers, total, lines, args, out_dir, name):
    pngs = []

    def saved():
        for img, number in zip(page_slides(images, numbers, total, lines, args, name), numbers):
            png = os.path.join(out_dir, f"{name}_page{number:02d}.png")
            img.save(png)
            print("wrote", png)
            pngs.append(png)
            yield img

    if not args.video:
        for _ in saved():
            pass
        return pngs
    mp4 = os.path.join(out_dir, name + ".mp4")
    encode(page_frames(saved(), args.seconds), len(images) * args.seconds, mp4)
    print("wrote", mp4)
    return pngs


# ---------------------------------------------------------------- --mode scroll

def strip_of(images):
    """The pages one under the other, PAGE_GAP apart."""
    height = sum(i.height for i in images) + PAGE_GAP * (len(images) - 1)
    strip = Image.new("RGB", (PAGE_WIDTH, height), FRAME_FILL)
    y = 0
    for img in images:
        strip.paste(img, (0, y))
        y += img.height + PAGE_GAP
    return strip


def trapezoid(u, r=0.08):
    """0..1 for u in 0..1: speeds up, goes at an even speed, slows down."""
    u = min(1.0, max(0.0, u))
    v = 1 / (1 - r)
    if u < r:
        return v * u * u / (2 * r)
    if u > 1 - r:
        return 1 - v * (1 - u) ** 2 / (2 * r)
    return v * (u - r / 2)


def run_scroll_mode(images, lines, args, out_dir, name):
    slide = Slide(strip_of(images), lines, args.sizes, "left", args.bar, "scroll")
    sw, sh = slide.picture.size
    window = slide.window_h
    distance = max(0.0, sh - window)

    def frame(y):
        return slide.frame_for((0, y, sw, y + window))

    # The images: the screens from the top to the bottom, a little overlapping.
    pngs, y, n = [], 0.0, 1
    while True:
        png = os.path.join(out_dir, f"{name}_{n:02d}.png")
        frame(y).save(png)
        print("wrote", png)
        pngs.append(png)
        if y >= distance:
            break
        y, n = min(distance, y + window * 0.9), n + 1

    if args.video:
        seconds = len(images) * args.seconds
        hold = min(1.0, seconds * 0.1)            # still at the top and at the bottom
        count = max(2, round(seconds * FPS))
        mp4 = os.path.join(out_dir, name + ".mp4")
        encode((frame(distance * trapezoid((i / FPS - hold) / (seconds - 2 * hold)))
                for i in range(count)), count / FPS, mp4)
        print("wrote", mp4)
    return pngs


# ---------------------------------------------------------------- main

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("file", nargs="?", help="the Word file or PDF; without it, a dialog asks for it")
    p.add_argument("lines", nargs="*", help="text lines on the left, with the styles of make_title.py")
    p.add_argument("-f", "--text", help="text file with the lines on the left")
    p.add_argument("-o", "--out-dir", help="folder for the images and the video")
    p.add_argument("--mode", choices=["page", "scroll"], default="page")
    p.add_argument("--pages", help="pages to use, e.g. 1-3,5 (default: all)")
    p.add_argument("--video", action="store_true", help="also make an MP4")
    p.add_argument("--seconds", type=float, help="seconds for each page (default: 4 with page, 8 with scroll)")
    p.add_argument("--page-numbers", action="store_true", help="'page / pages' in the footer (--mode page)")
    p.add_argument("--bar", action="store_true", help="a window title bar above the pages")
    p.add_argument("--sizes", type=parse_sizes, metavar='"30,128,46,34,40,28"',
                   help="6 font sizes, as in make_title.py")
    args = p.parse_intermixed_args()

    if not args.file:
        args.file = choose_file("Chọn file Word (hoặc PDF)", WORD_FILES)
        if not args.file:
            raise SystemExit("Không có file nào được chọn.")
    if not os.path.isfile(args.file):
        raise SystemExit(f"make_word: {args.file} not found")
    if args.seconds is None:
        args.seconds = 4.0 if args.mode == "page" else 8.0
    if args.video and args.seconds < 1.5:
        raise SystemExit("make_word: --seconds must be at least 1.5")

    name = os.path.splitext(os.path.basename(args.file))[0]
    out_dir = args.out_dir or unused(os.path.join(
        HERE, "Output", datetime.datetime.now().strftime("%Y-%m-%d_%H"), name))
    lines = (read_lines(args.text) if args.text else []) + args.lines

    tmp = tempfile.mkdtemp(prefix="make_word_")
    try:
        if args.file.lower().endswith(".pdf"):
            pdf = args.file
        else:
            pdf = os.path.join(tmp, name + ".pdf")
            print(f"Word: making a PDF of {args.file}...")
            word_to_pdf(args.file, pdf)
        total = page_count(pdf)
        pages = parse_pages(args.pages, total)
        print(f"{len(pages)} of {total} pages")
        images = render_pages(pdf, pages)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    os.makedirs(out_dir, exist_ok=True)
    if args.mode == "page":
        run_page_mode(images, [n + 1 for n in pages], total, lines, args, out_dir, name)
    else:
        run_scroll_mode(images, lines, args, out_dir, name)
    print(f"Output: {out_dir}")


if __name__ == "__main__":
    main()
