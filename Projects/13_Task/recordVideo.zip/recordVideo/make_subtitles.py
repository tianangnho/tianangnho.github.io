"""Make subtitles (.srt) from the speech of a video, with Whisper (faster-whisper), offline.

    python make_subtitles.py demo.mp4                        # writes demo.srt next to the video
    python make_subtitles.py demo.mp4 --language vi          # say the language: faster, no wrong guess
    python make_subtitles.py demo.mp4 --model medium         # more accurate, slower
    python make_subtitles.py demo.mp4 --to en                # Vietnamese speech -> English subtitles
    python make_subtitles.py demo.mp4 --to vi                # English speech -> Vietnamese subtitles
    python make_subtitles.py demo.mp4 --to en --translator argos
    python make_subtitles.py demo.mp4 --prompt "RA0E1, FSP, e2 studio, CMake"
    python make_subtitles.py a.mp4 b.mp4 --format vtt        # several videos; also: txt
    python make_subtitles.py selected_files.txt              # the videos listed in a .txt file

Models, from fastest to most accurate: tiny, base, small (default), medium,
large-v3-turbo, large-v3. A model is downloaded once (75 MB to 3 GB) into the
Hugging Face cache; after that, everything runs without internet.

Without --to, the subtitles are in the language spoken. --to en translates with
Whisper itself (better with medium or larger), or with Argos Translate when
--translator argos is given. --to vi translates with Argos Translate (Whisper
translates only into English): the speech is written down, then each sentence
is translated, offline. The translated file is named demo.vi.srt / demo.en.srt.

--prompt gives words the speaker uses (product names, abbreviations), so that
Whisper writes them correctly. Long sentences are cut into subtitles of at most
--max-chars characters and --max-seconds seconds, at the timing of the words.
The .srt can then be put into the video with merge_video_audio.py.
--also-original, with --to, writes the subtitles in the language spoken as
well (demo.vi.srt), from the same transcription.

Needs ffmpeg and the faster-whisper package (pip install faster-whisper); for
--to vi or --translator argos, also argostranslate (pip install argostranslate),
whose language packages are downloaded the first time they are needed.
"""
import argparse
import math
import os
import subprocess
import sys
import tempfile
import time

from merge_video_audio import find_ffmpeg

MODELS = ["tiny", "base", "small", "medium", "large-v3-turbo", "large-v3", "tiny.en", "base.en", "small.en",
          "medium.en", "distil-large-v3"]


def collect(inputs):
    files = []
    for item in inputs:
        if item.lower().endswith(".txt"):
            raw = open(item, "rb").read()
            try:
                text = raw.decode("utf-8-sig")
            except UnicodeDecodeError:
                text = raw.decode("mbcs" if os.name == "nt" else "latin-1")
            files += [l.strip().strip('"') for l in text.splitlines() if l.strip()]
        else:
            files.append(item)
    missing = [f for f in files if not os.path.isfile(f)]
    if missing:
        sys.exit("not found:\n  " + "\n  ".join(missing))
    return files


def extract_audio(ffmpeg, video, wav):
    """The sound of the video as 16 kHz mono WAV, which is what Whisper works on."""
    result = subprocess.run([ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", video,
                             "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", wav])
    if result.returncode != 0 or not os.path.exists(wav):
        sys.exit(f"ffmpeg could not take the sound out of {video} (does it have sound?)")


def text_of(words):
    return "".join(w.word for w in words).strip()


def split_evenly(words, max_chars, max_seconds):
    """Cuts a sentence that is too long into parts of about the same length, preferring commas."""
    text_len = len(text_of(words))
    seconds = words[-1].end - words[0].start
    n = max(math.ceil(text_len / max_chars), math.ceil(seconds / max_seconds), 1)
    if n == 1 or len(words) == 1:
        return [words]
    ends, pos = [], 0  # characters up to the end of each word
    for w in words:
        pos += len(w.word)
        ends.append(pos)
    cuts, last = [], 0
    for k in range(1, n):
        ideal = ends[-1] * k / n
        best = min(range(last + 1, len(words)),
                   key=lambda i: abs(ends[i - 1] - ideal) - (10 if words[i - 1].word.rstrip()[-1:] in ",;:" else 0))
        cuts.append(best)
        last = best
        if last >= len(words) - 1:
            break
    parts = [words[a:b] for a, b in zip([0] + cuts, cuts + [len(words)]) if words[a:b]]
    # a part can still be too long when the words are unevenly long: cut it again
    return [q for p in parts for q in (split_evenly(p, max_chars, max_seconds) if len(p) < len(words) else [p])]


def split_text(text, start, end, max_chars, max_seconds):
    """Cuts a translated sentence into (start, end, text) parts; the time is shared by length."""
    tokens = text.split()
    n = max(math.ceil(len(text) / max_chars), math.ceil((end - start) / max_seconds), 1)
    n = min(n, len(tokens)) or 1
    if n == 1:
        return [(start, end, text)]
    ends, pos = [], 0
    for t in tokens:
        pos += len(t) + 1
        ends.append(pos)
    cuts, last = [], 0
    for k in range(1, n):
        ideal = ends[-1] * k / n
        if last + 1 >= len(tokens):
            break
        best = min(range(last + 1, len(tokens)),
                   key=lambda i: abs(ends[i - 1] - ideal) - (10 if tokens[i - 1][-1:] in ",;:" else 0))
        cuts.append(best)
        last = best
    parts, t0 = [], start
    for a, b in zip([0] + cuts, cuts + [len(tokens)]):
        t1 = start + (end - start) * ends[b - 1] / ends[-1]
        parts.append((t0, t1, " ".join(tokens[a:b])))
        t0 = t1
    return parts


def make_cues(words, max_chars, max_seconds, translate=None):
    """(start, end, text) subtitles from the timed words of the whole video.

    With translate (a function [texts] -> [texts]), each sentence is translated whole, then cut."""
    sentences, cur = [], []
    for w in words:
        # a long pause also ends a sentence, for speech that Whisper gives without punctuation
        if cur and w.start - cur[-1].end > 1.5:
            sentences.append(cur)
            cur = []
        cur.append(w)
        if w.word.rstrip()[-1:] in ".?!。？！":
            sentences.append(cur)
            cur = []
    if cur:
        sentences.append(cur)

    if translate:
        parts = []
        texts = translate([text_of(s) for s in sentences])
        for s, text in zip(sentences, texts):
            print(f"  {stamp(s[0].start, '.')[:-4]}  {text}")
            parts += split_text(text, s[0].start, s[-1].end, max_chars, max_seconds)
    else:
        parts = [(p[0].start, p[-1].end, text_of(p))
                 for s in sentences for p in split_evenly(s, max_chars, max_seconds)]

    groups = []  # short sentences that follow each other closely share a subtitle
    for start, end, text in parts:
        if not text:
            continue
        if groups and len(groups[-1][2]) + 1 + len(text) <= max_chars \
                and end - groups[-1][0] <= max_seconds and start - groups[-1][1] < 0.8:
            groups[-1] = (groups[-1][0], end, groups[-1][2] + " " + text)
        else:
            groups.append((start, end, text))

    cues = []
    for i, (start, end, text) in enumerate(groups):
        # leave a short subtitle on the screen long enough to be read, up to the next one
        next_start = groups[i + 1][0] if i + 1 < len(groups) else end + 1.0
        cues.append((start, max(end, min(start + 1.0, next_start)), text))
    return cues


def argos_translator(src, dst, device):
    """A function [sentences] -> [translations] from src to dst, with the models of Argos Translate.

    The packages (through English when there is none from src to dst) are downloaded the first
    time. Their CTranslate2 model is used directly: the sentences are already split, which spares
    the sentence splitter of Argos, which downloads more models."""
    try:
        import argostranslate.package as package
        import ctranslate2
        import sentencepiece
    except ImportError:
        sys.exit("argostranslate is not installed: pip install argostranslate")

    def installed():
        return {(p.from_code, p.to_code): p for p in package.get_installed_packages()}

    have = installed()
    chain = [(src, dst)] if (src, dst) in have else [(src, "en"), ("en", dst)]
    if any(pair not in have for pair in chain):
        print(f"downloading the translation packages {src} -> {dst} (once)...")
        package.update_package_index()
        available = {(p.from_code, p.to_code): p for p in package.get_available_packages()}
        chain = [(src, dst)] if (src, dst) in have or (src, dst) in available else [(src, "en"), ("en", dst)]
        for pair in chain:
            if pair in have:
                continue
            if pair not in available:
                sys.exit(f"Argos Translate has no package {pair[0]} -> {pair[1]}")
            package.install_from_path(available[pair].download())
        have = installed()

    steps = []
    for pair in chain:
        path = have[pair].package_path
        steps.append((ctranslate2.Translator(str(path / "model"), device=device,
                                             compute_type="int8" if device == "cpu" else "float16"),
                      sentencepiece.SentencePieceProcessor(model_file=str(path / "sentencepiece.model"))))

    def translate(texts):
        for model, sp in steps:
            results = model.translate_batch([sp.encode(t, out_type=str) for t in texts],
                                            beam_size=4, max_decoding_length=512)
            texts = ["".join(r.hypotheses[0]).replace("▁", " ").strip() for r in results]
        return texts
    return translate


def wrap(text, width):
    """Two lines at most: breaks at the space nearest the middle when the text is long."""
    if len(text) <= width or " " not in text:
        return text
    mid = len(text) // 2
    spaces = [i for i, c in enumerate(text) if c == " "]
    cut = min(spaces, key=lambda i: abs(i - mid))
    return text[:cut] + "\n" + text[cut + 1:]


def stamp(t, sep):
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02}{sep}{ms:03}"


def write(cues, path, fmt, line_width):
    with open(path, "w", encoding="utf-8") as f:
        if fmt == "txt":
            f.write("\n".join(text for _, _, text in cues) + "\n")
            return
        if fmt == "vtt":
            f.write("WEBVTT\n\n")
        for n, (start, end, text) in enumerate(cues, 1):
            sep = "," if fmt == "srt" else "."
            if fmt == "srt":
                f.write(f"{n}\n")
            f.write(f"{stamp(start, sep)} --> {stamp(end, sep)}\n{wrap(text, line_width)}\n\n")


def main():
    summary, _, details = __doc__.partition("\n")
    ap = argparse.ArgumentParser(description=summary, epilog="examples:" + details,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("inputs", nargs="+", help="the videos (or audio files), or .txt files listing them")
    ap.add_argument("-o", "--output", help="the subtitle file (one input only); default: the video name with .srt")
    ap.add_argument("--out-dir", help="folder of the subtitle files; default: that of each video")
    ap.add_argument("--format", choices=["srt", "vtt", "txt"], default="srt", help="default srt")
    ap.add_argument("--model", default="small", help="tiny, base, small (default), medium, large-v3-turbo, large-v3")
    ap.add_argument("--language", help="language spoken, e.g. vi, en, ja; default: detected")
    ap.add_argument("--to", choices=["vi", "en"], help="language of the subtitles; default: the language spoken")
    ap.add_argument("--translator", choices=["whisper", "argos"], default="whisper",
                    help="how --to en translates: whisper (default) or argos; --to vi always uses argos")
    ap.add_argument("--also-original", action="store_true",
                    help="with --to: also write the subtitles in the language spoken, <video>.<language>.srt")
    ap.add_argument("--prompt", help="words the speaker uses, so that they are written correctly")
    ap.add_argument("--max-chars", type=int, default=84, help="most characters of a subtitle; default 84")
    ap.add_argument("--max-seconds", type=float, default=6.0, help="longest time of a subtitle; default 6")
    ap.add_argument("--line-width", type=int, default=42, help="longer subtitles are put on two lines; default 42")
    ap.add_argument("--no-vad", action="store_true", help="do not skip the silent parts (if speech is missed)")
    ap.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto", help="default auto")
    ap.add_argument("--compute-type", default="default", help="e.g. int8 (fast on CPU), float16 (GPU)")
    ap.add_argument("--threads", type=int, default=0, help="CPU threads; default: all")
    ap.add_argument("--ffmpeg", help="path of ffmpeg.exe")
    args = ap.parse_args()

    files = collect(args.inputs)
    if args.output and len(files) > 1:
        sys.exit("-o can be given with one input only")
    if args.model not in MODELS and not os.path.isdir(args.model):
        print(f"note: {args.model} is not a known model name; trying it anyway")

    try:
        from faster_whisper import WhisperModel
    except ImportError:
        sys.exit("faster-whisper is not installed: pip install faster-whisper")
    ffmpeg = find_ffmpeg(args.ffmpeg)

    print(f"loading model {args.model} (the first time, it is downloaded)...")
    device = args.device
    if device == "auto":
        import ctranslate2
        device = "cuda" if ctranslate2.get_cuda_device_count() > 0 else "cpu"
    compute = args.compute_type
    if compute == "default":
        compute = "int8" if device == "cpu" else "float16"
    print(f"device: {device}, {compute}")
    model = WhisperModel(args.model, device=device, compute_type=compute, cpu_threads=args.threads)

    # Whisper translates into English only; anything else is written down, then translated by Argos
    whisper_translates = args.to == "en" and args.translator == "whisper" and args.language != "en"
    if args.also_original and whisper_translates:
        # the words of Whisper are then English: translate the written-down speech instead
        print("note: --also-original translates with Argos Translate, from one transcription")
        whisper_translates = False

    for video in files:
        suffix = f".{args.to}" if args.to else ""
        out = args.output or os.path.splitext(video)[0] + suffix + "." + args.format
        if args.out_dir and not args.output:
            os.makedirs(args.out_dir, exist_ok=True)
            out = os.path.join(args.out_dir, os.path.basename(out))
        print(f"\n{video}")
        t0 = time.time()
        with tempfile.TemporaryDirectory() as tmp:
            wav = os.path.join(tmp, "audio.wav")
            extract_audio(ffmpeg, video, wav)
            segments, info = model.transcribe(
                wav, language=args.language, task="translate" if whisper_translates else "transcribe",
                initial_prompt=args.prompt, word_timestamps=True, vad_filter=not args.no_vad,
                beam_size=5, condition_on_previous_text=False)
            if not args.language:
                print(f"language: {info.language} ({info.language_probability:.0%})")
            if whisper_translates and info.language != "en":
                print("translating into English with Whisper")
            words = []
            for seg in segments:  # transcribed while iterating
                words += [w for w in (seg.words or []) if w.word.strip()]
                pct = min(seg.end / info.duration, 1) if info.duration else 0
                print(f"  [{pct:4.0%}] {stamp(seg.start, '.')[:-4]}  {seg.text.strip()}")
        translate = None
        if args.to and not whisper_translates and info.language != args.to and words:
            print(f"translating {info.language} -> {args.to} with Argos Translate")
            translate = argos_translator(info.language, args.to, device)
        if args.also_original and args.to and words:
            original = os.path.join(os.path.dirname(os.path.abspath(out)),
                                    f"{os.path.splitext(os.path.basename(video))[0]}.{info.language}.{args.format}")
            if os.path.abspath(original) != os.path.abspath(out):
                cues = make_cues(words, args.max_chars, args.max_seconds)
                write(cues, original, args.format, args.line_width)
                print(f"wrote {original}: {len(cues)} subtitles in the language spoken")
        cues = make_cues(words, args.max_chars, args.max_seconds, translate)
        if not cues:
            print("no speech found; nothing written")
            continue
        write(cues, out, args.format, args.line_width)
        took = time.time() - t0
        print(f"wrote {out}: {len(cues)} subtitles, {info.duration:.0f}s of video in {took:.0f}s")


if __name__ == "__main__":
    main()
