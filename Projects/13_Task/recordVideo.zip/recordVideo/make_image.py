"""Make a slide from a picture (a screenshot, a diagram...) as a PNG, and optionally an MP4,
in the style of make_title.py: dark background, the picture in a window frame.

Text lines are optional and use the styles of make_title.py (// label, # title,
## subtitle, $ code, == code block ==, --- footer | right). Give them on the
command line after the picture, or in a text file (UTF-8):

    python make_image.py --video            (dialogs ask for the picture and the text file)
    python make_image.py shot.png
    python make_image.py shot.png "// DEMO" "# Kết quả *convert*" "--- CMake Conversion Tool | part 2 / 5"
    python make_image.py shot.png -f caption.txt --layout left
    python make_image.py shot.png -f caption.txt --video --seconds 5 --motion zoom
    python make_image.py long_page.png --video --motion scroll --seconds 8

--layout   top (default): the text above the picture; left: the text in a column on the left
--motion   none (default): a still picture with fade in/out
           zoom: the picture slowly zooms in (--zoom 1.08 = 8 % at the end)
           scroll: a tall picture scrolls from its top to its bottom
--sizes    6 font sizes, as in make_title.py: label, title, subtitle, code, text, footer
--no-bar   no window title bar above the picture

Needs Pillow; --video also needs ffmpeg.
"""
import argparse
import datetime
import os
import subprocess

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageOps

from make_title import (ACCENT, H, LEFT, SIZE_KEYS, W, background, default_sizes, draw_blocks, draw_footer,
                        footer_y, glow, layout, make_video, parse_sizes, read_lines, split_footer)

FPS = 30
BAR = 44                     # height of the window title bar
RADIUS = 14
FRAME_FILL = (20, 24, 32)    # same as the code boxes of make_title
FRAME_LINE = (44, 52, 66)
DOT = (62, 70, 86)
TEXT_COLUMN = 640            # width of the text with --layout left
GAP = 70                     # between the text and the picture


def smooth(p):
    p = min(1.0, max(0.0, p))
    return p * p * (3 - 2 * p)


def fit_column(d, body, sizes, height):
    """Lay the text out in the left column; when it is taller than height, the
    font sizes are made smaller until it fits. Returns (sizes, blocks, text height)."""
    scaled = dict(sizes)
    blocks, text_h = layout(d, body, scaled, TEXT_COLUMN)
    k = 1.0
    while text_h > height and k > 0.35:
        k *= 0.92
        scaled = {key: max(10, round(v * k)) if key != "footer" else v for key, v in sizes.items()}
        blocks, text_h = layout(d, body, scaled, TEXT_COLUMN)
    if k < 1.0:
        print("note: the text is too tall for the column; font sizes used: "
              + ",".join(str(scaled[key]) for key in SIZE_KEYS))
    return scaled, blocks, text_h


def load(path):
    """The picture as RGB; transparent parts become the frame colour."""
    img = ImageOps.exif_transpose(Image.open(path))
    if img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGBA")
        flat = Image.new("RGB", img.size, FRAME_FILL)
        flat.paste(img, mask=img.getchannel("A"))
        return flat
    return img.convert("RGB")


class Slide:
    """The still parts (background, text, frame) and where the picture goes."""

    def __init__(self, picture, lines, sizes, layout_name="top", bar=True, motion="none", zoom=1.08):
        self.motion, self.zoom = motion, zoom
        self.bar = BAR if bar else 0
        sizes = sizes or default_sizes()
        base = background()
        d = ImageDraw.Draw(base)
        body, footer = split_footer(lines)
        top, bottom = 70, (footer_y(sizes) - 45 if footer else H - 70)

        # Area for the picture (frame included), and where the text goes.
        if not body:
            blocks, text_h = [], 0
            area = (110, top, W - 110, bottom)
        else:
            if layout_name != "left":
                blocks, text_h = layout(d, body, sizes, W - 2 * LEFT)
                if bottom - top - text_h - self.bar < 360:       # the picture would be too small
                    print("note: the text is too long to go above the picture; it goes on the left")
                    layout_name = "left"
            if layout_name == "left":
                sizes, blocks, text_h = fit_column(d, body, sizes, bottom - top)
                area = (LEFT + TEXT_COLUMN + GAP, top, W - 110, bottom)
            else:
                area = (LEFT, top + text_h, W - LEFT, bottom)
        ax0, ay0, ax1, ay1 = area
        aw, ah = ax1 - ax0, ay1 - ay0 - self.bar
        if aw < 200 or ah < 120:
            raise SystemExit("make_image: the text leaves no room for the picture; "
                             "use fewer lines, smaller --sizes or --layout left")

        # Size of the picture on the slide.
        sw, sh = picture.size
        if motion == "scroll":
            scale = aw / sw
            if sh * scale <= ah:
                print("note: the picture is not taller than the frame; it is not scrolled")
                self.motion = motion = "none"
        if motion != "scroll":
            scale = min(aw / sw, ah / sh)
        self.dw, self.dh = max(1, round(sw * scale)), max(1, round(min(sh * scale, ah)))

        # A big picture is made smaller once, so that each video frame is quick to resize
        # (twice the shown size keeps the zoom sharp).
        if sw > 2 * self.dw:
            picture = picture.resize((2 * self.dw, max(1, round(sh * 2 * self.dw / sw))), Image.LANCZOS)
        self.picture = picture
        self.window_h = self.src_h(picture)

        # Position: centred in the area; with --layout top the text and the picture
        # are centred together.
        fw, fh = self.dw, self.dh + self.bar
        if body and layout_name != "left":
            y_text = max(top, (top + bottom - text_h - fh) // 2)
            fy = y_text + text_h
            fx = ax0 + (aw - fw) // 2
        else:
            fx = ax0 + (aw - fw) // 2
            fy = ay0 + (ay1 - ay0 - fh) // 2
            y_text = max(top, (top + bottom - text_h) // 2 + 10)
        self.frame = (fx, fy, fx + fw, fy + fh)
        self.at = (fx, fy + self.bar)

        # Shadow and a little light below the frame, then the frame itself.
        shadow = Image.new("L", (W, H), 0)
        ImageDraw.Draw(shadow).rounded_rectangle([fx + 6, fy + 22, fx + fw - 6, fy + fh + 22],
                                                 radius=RADIUS, fill=150)
        shadow = shadow.filter(ImageFilter.GaussianBlur(26))
        base = Image.composite(Image.new("RGB", (W, H), (0, 0, 0)), base, shadow)
        base = ImageChops.add(base, glow((fx + fw / 2, fy + fh), min(fw, 900) * 0.45, ACCENT, 0.10))
        d = ImageDraw.Draw(base)
        if blocks:
            draw_blocks(d, blocks, sizes, LEFT, y_text)
        if footer:
            draw_footer(d, footer, sizes)
        d.rounded_rectangle(self.frame, radius=RADIUS, fill=FRAME_FILL)
        if self.bar:
            for i in range(3):
                cx, cy = fx + 24 + i * 22, fy + self.bar // 2
                d.ellipse([cx - 6, cy - 6, cx + 6, cy + 6], fill=DOT)
        self.base = base

        # The picture is drawn through this mask, so it has the rounded corners of the frame.
        mask = Image.new("L", (W, H), 0)
        ImageDraw.Draw(mask).rounded_rectangle(self.frame, radius=RADIUS, fill=255)
        self.mask = mask.crop((self.at[0], self.at[1], self.at[0] + self.dw, self.at[1] + self.dh))

    def src_h(self, picture):
        """Height of the part of the picture shown at once (all of it, except when scrolling)."""
        sw, sh = picture.size
        return sh if self.motion != "scroll" else min(sh, self.dh * sw / self.dw)

    def box(self, t):
        """The part of the picture shown at time t (0..1)."""
        sw, sh = self.picture.size
        if self.motion == "zoom":
            z = 1 + (self.zoom - 1) * smooth(t)
            w, h = sw / z, sh / z
            return ((sw - w) / 2, (sh - h) / 2, (sw + w) / 2, (sh + h) / 2)
        if self.motion == "scroll":
            # stays still a moment at the top and at the bottom
            y = (sh - self.window_h) * smooth((t - 0.15) / 0.7)
            return (0, y, sw, y + self.window_h)
        return (0, 0, sw, sh)

    def frame_at(self, t):
        return self.frame_for(self.box(t))

    def frame_for(self, box):
        """The slide showing the part box (x0, y0, x1, y1) of the picture."""
        img = self.base.copy()
        shown = self.picture.resize((self.dw, self.dh), Image.BICUBIC, box=box)
        img.paste(shown, self.at, self.mask)
        d = ImageDraw.Draw(img)
        if self.bar:
            x0, y0, x1, _ = self.frame
            d.line([x0, y0 + self.bar - 1, x1, y0 + self.bar - 1], fill=FRAME_LINE, width=2)
        d.rounded_rectangle(self.frame, radius=RADIUS, outline=FRAME_LINE, width=2)
        return img


def write_video(slide, png, seconds, fade=0.6):
    """MP4 next to png: the slide moving as --motion says, with fade in/out."""
    if slide.motion == "none":
        return make_video(png, seconds, fade)
    mp4 = os.path.splitext(png)[0] + ".mp4"
    n = max(2, round(seconds * FPS))
    encode((slide.frame_at(i / (n - 1)) for i in range(n)), n / FPS, mp4, fade)
    return mp4


def encode(frames, seconds, mp4, fade=0.6):
    """Writes the W x H frames (PIL images, FPS a second) to mp4, with fade in/out
    and a silent audio track."""
    proc = subprocess.Popen([
        "ffmpeg", "-y", "-loglevel", "error",
        "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
        "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-t", f"{seconds:.3f}",
        "-vf", f"fade=in:st=0:d={fade},fade=out:st={seconds - fade:.3f}:d={fade},format=yuv420p",
        "-c:v", "libx264", "-c:a", "aac", "-shortest", mp4,
    ], stdin=subprocess.PIPE)
    try:
        for frame in frames:
            proc.stdin.write(frame.tobytes())
    except BrokenPipeError:
        pass
    proc.stdin.close()
    if proc.wait() != 0:
        raise SystemExit(f"ffmpeg failed making {mp4}")


def choose_file(title, filetype, initialdir=None):
    """A path chosen in an Open dialog, or "" when it is cancelled."""
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)   # in front of the console
    root.update()
    path = filedialog.askopenfilename(parent=root, title=title, initialdir=initialdir or os.getcwd(),
                                      filetypes=[filetype, ("Tất cả", "*.*")])
    root.destroy()
    return os.path.normpath(path) if path else ""


def unused(path):
    """path, or path with _2, _3... when that file exists."""
    stem, ext = os.path.splitext(path)
    n, candidate = 1, path
    while os.path.exists(candidate):
        n += 1
        candidate = f"{stem}_{n}{ext}"
    return candidate


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("image", nargs="?",
                   help="the picture (.png, .jpg...); without it, a dialog asks for the picture and the text file")
    p.add_argument("lines", nargs="*", help="text lines, with the styles of make_title.py")
    p.add_argument("-f", "--file", help="text file with one line per row")
    p.add_argument("-o", "--output", help="PNG to write (default: Output/<picture>_slide.png)")
    p.add_argument("--layout", choices=["top", "left"], default="top")
    p.add_argument("--sizes", type=parse_sizes, metavar='"30,128,46,34,40,28"',
                   help="6 font sizes: label, title, subtitle, code, text, footer; '-' or 0 keeps that default")
    p.add_argument("--no-bar", action="store_true", help="no window title bar above the picture")
    p.add_argument("--video", action="store_true", help="also make an MP4")
    p.add_argument("--seconds", type=float, default=5.0)
    p.add_argument("--motion", choices=["none", "zoom", "scroll"], default="none")
    p.add_argument("--zoom", type=float, default=1.08, help="zoom at the end of --motion zoom (default 1.08)")
    args = p.parse_intermixed_args()

    if not args.image:
        args.image = choose_file("Chọn hình", ("Hình", "*.png *.jpg *.jpeg *.bmp *.gif *.webp"))
        if not args.image:
            raise SystemExit("Không có hình nào được chọn.")
        if not args.file and not args.lines:
            args.file = choose_file("Chọn file chữ (.txt, như title_example.txt; Cancel = không có chữ)",
                                    ("File chữ", "*.txt"), os.path.dirname(os.path.abspath(__file__)))
        if not args.output:
            here = os.path.dirname(os.path.abspath(__file__))
            out_dir = os.path.join(here, "Output", datetime.datetime.now().strftime("%Y-%m-%d_%H"))
            args.output = unused(os.path.join(
                out_dir, os.path.splitext(os.path.basename(args.image))[0] + "_slide.png"))

    output = args.output or os.path.join(
        "Output", os.path.splitext(os.path.basename(args.image))[0] + "_slide.png")
    if os.path.abspath(output) == os.path.abspath(args.image):
        raise SystemExit("make_image: the output would overwrite the picture; give another -o")
    if args.video and args.seconds <= 1.2:
        raise SystemExit("make_image: --seconds must be more than 1.2 (fade in + fade out)")
    if not 1.0 <= args.zoom <= 2.0:
        raise SystemExit("make_image: --zoom must be between 1.0 and 2.0")

    lines = (read_lines(args.file) if args.file else []) + args.lines
    slide = Slide(load(args.image), lines, args.sizes, args.layout, not args.no_bar,
                  args.motion if args.video else "none", args.zoom)

    os.makedirs(os.path.dirname(output) or ".", exist_ok=True)
    slide.frame_at(0).save(output)
    print("wrote", output)
    if args.video:
        print("wrote", write_video(slide, output, args.seconds))


if __name__ == "__main__":
    main()
