"""Make a title card (dark background) as a PNG, and optionally a short MP4 with fade.

Give your own lines, either on the command line or in a text file (UTF-8).
The first characters of a line choose its style:

    // TOOL DEMO               small label in the accent colour (starts with //)
    # CMake Conversion *Tool*  big title; words between *...* are in the accent colour
    ## Chuyển đổi project ...  subtitle (grey, light)
    $ convert a → b            code box (starts with $)
    ==                         lines between two "==" lines: one code box with several lines
    $ tool cmd --config <name>
    [--path <file>] [--json]
    ==
    plain text                 normal text
    (empty line)               extra space
    --- left | right           footer at the bottom; "|" splits left and right parts

    python make_title.py "// TOOL DEMO" "# CMake Conversion *Tool*" "## Giới thiệu" "$ cmake-convert app.vcxproj"
    python make_title.py -f title.txt -o Output/intro.png
    python make_title.py -f title.txt --video --seconds 4
    python make_title.py                                  (the built-in example)

Font sizes: --sizes takes 6 numbers, in this order (default in brackets):
    label (30), title (128), subtitle (46), code (34), text (40), footer (28)
"-" or 0 keeps the default of that position:

    python make_title.py -f title.txt --sizes "36,150,52,38,44,30"
    python make_title.py -f title.txt --sizes "- 100 - - - -"     (only a smaller title)

Needs Pillow; --video also needs ffmpeg.
"""
import argparse
import os
import re
import subprocess

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

W, H = 1920, 1080
LEFT = 180
FONTS = r"C:\Windows\Fonts"

# Palette: near-black background, one accent colour, greys for secondary text.
BG = (11, 13, 18)
GRID = (24, 28, 36)
ACCENT = (56, 189, 248)      # cyan
ACCENT2 = (129, 140, 248)    # indigo, for the glow gradient
TEXT = (240, 243, 248)
MUTED = (140, 150, 165)

EXAMPLE = [
    "// TOOL DEMO",
    "# CMake Conversion *Tool*",
    "## Chuyển đổi project build cũ sang CMake — nhanh, sạch, tự động",
    "$ convert  Makefile / .vcxproj  →  CMakeLists.txt",
    "--- Giới thiệu & hướng dẫn sử dụng | v1.0  ·  2026",
]


def font(name, size):
    return ImageFont.truetype(os.path.join(FONTS, name), size)


# style: (font file, colour, space after)
STYLES = {
    "tag":   ("consolab.ttf", ACCENT, 20),
    "title": ("segoeuib.ttf", TEXT, 30),
    "sub":   ("segoeuil.ttf", MUTED, 40),
    "code":  ("consola.ttf", (200, 210, 222), 30),
    "text":  ("segoeui.ttf", TEXT, 22),
}

# Font sizes in pixels, in the order of --sizes.
SIZE_KEYS = ["tag", "title", "sub", "code", "text", "footer"]
DEFAULT_SIZES = [30, 128, 46, 34, 40, 28]


def parse_sizes(text):
    """'30,128,46,34,40,28' or '30 140 - - - -' -> {style: size}; '-' or 0 keeps the default."""
    parts = [p for p in re.split(r"[,\s;]+", text.strip()) if p]
    if len(parts) != 6:
        raise argparse.ArgumentTypeError(
            f"cần đúng 6 số (nhãn, tiêu đề, phụ đề, code, chữ thường, chân trang), nhận được {len(parts)}")
    sizes = {}
    for key, default, part in zip(SIZE_KEYS, DEFAULT_SIZES, parts):
        if part in ("-", "0"):
            sizes[key] = default
            continue
        try:
            n = int(part)
        except ValueError:
            raise argparse.ArgumentTypeError(f"'{part}' không phải số")
        if not 8 <= n <= 400:
            raise argparse.ArgumentTypeError(f"cỡ chữ {n} phải trong khoảng 8..400")
        sizes[key] = n
    return sizes


def parse(line):
    """Return (style, text) for one input line."""
    s = line.rstrip()
    if not s.strip():
        return "space", ""
    if s.startswith("---"):
        return "footer", s[3:].strip()
    if s.startswith("//"):
        return "tag", s
    if s.startswith("##"):
        return "sub", s[2:].strip()
    if s.startswith("#"):
        return "title", s[1:].strip()
    if s.startswith("$"):
        return "code", s
    return "text", s


def group(lines):
    """(style, text) for each line; the lines between two "==" lines become one
    ("code", [row, row...]) item. A single "$ ..." line is ("code", [row])."""
    items, block = [], None
    for line in lines:
        if line.strip() == "==":
            if block is None:
                block = []
            else:
                if block:
                    items.append(("code", block))
                block = None
            continue
        if block is not None:
            block.append(line.rstrip())
            continue
        style, text = parse(line)
        items.append((style, [text] if style == "code" else text))
    if block:                               # "==" not closed: keep what was given
        items.append(("code", block))
    return items


def wrap_code(d, row, f, width):
    """Split a long command row at spaces; the continuation is indented."""
    if d.textlength(row, font=f) <= width:
        return [row]
    out, cur = [], ""
    for word in row.split(" "):
        test = cur + " " + word if cur else word
        if cur.strip() and d.textlength(test, font=f) > width:
            out.append(cur)
            cur = "    " + word
        else:
            cur = test
    out.append(cur)
    return out


def glow(center, radius, color, strength):
    """A soft blurred circle of light, used behind the text."""
    layer = Image.new("RGB", (W, H), (0, 0, 0))
    x, y = center
    ImageDraw.Draw(layer).ellipse([x - radius, y - radius, x + radius, y + radius],
                                  fill=tuple(int(c * strength) for c in color))
    return layer.filter(ImageFilter.GaussianBlur(radius * 0.6))


def wrap(d, text, f, width):
    """Split text into lines that fit in width pixels."""
    lines, cur = [], ""
    for word in text.split(" "):
        test = (cur + " " + word).strip() if cur else word
        if cur and d.textlength(test.replace("*", ""), font=f) > width:
            lines.append(cur)
            cur = word
        else:
            cur = test
    lines.append(cur)
    return lines


def draw_marked(d, x, y, text, f, color):
    """Draw text where parts between *...* are in the accent colour."""
    for i, part in enumerate(re.split(r"\*", text)):
        d.text((x, y), part, font=f, fill=ACCENT if i % 2 else color)
        x += d.textlength(part, font=f)


def background():
    img = Image.new("RGB", (W, H), BG)
    img = ImageChops.add(img, glow((W * 0.22, H * 0.35), 420, ACCENT, 0.22))
    img = ImageChops.add(img, glow((W * 0.85, H * 0.80), 380, ACCENT2, 0.18))
    d = ImageDraw.Draw(img)
    for x in range(48, W, 48):          # faint dot grid
        for y in range(48, H, 48):
            d.point((x, y), fill=GRID)
            d.point((x + 1, y), fill=GRID)
    return img


def split_footer(lines):
    """(body items, footer text or None) of the input lines."""
    items = group(lines)
    footer = [t for s, t in items if s == "footer"]
    body = [(s, t) for s, t in items if s != "footer"]
    return body, (footer[-1] if footer else None)


def footer_y(sizes):
    """Top of the footer text; its line is 25 px above."""
    return H - 77 - sizes["footer"]


def layout(d, body, sizes, width):
    """Measure the body items in a column of width pixels.
    Returns ([(style, font, rows, height with space after)], total height)."""
    blocks, total = [], 0
    for style, text in body:
        if style == "space":
            blocks.append(("space", None, [], 40))
            total += 40
            continue
        name, color, after = STYLES[style]
        size = sizes[style]
        f = font(name, size)
        line_h = int(size * 1.25)
        if style == "code":
            rows = [r for row in text for r in wrap_code(d, row, f, width - 56)]
            h = line_h * len(rows) + 32
        else:
            rows = wrap(d, text, f, width)
            h = line_h * len(rows)
        if style == "title":          # room for the accent bar below the descenders
            h = line_h * (len(rows) - 1) + f.getbbox("gjpqyẤ")[3] + max(12, size // 8) + 8
        blocks.append((style, f, rows, h + after))
        total += h + after
    return blocks, total


def draw_blocks(d, blocks, sizes, x, y):
    """Draw blocks made by layout() with their top left corner at (x, y)."""
    for style, f, rows, step in blocks:
        if style == "space":
            y += step
            continue
        _, color, _ = STYLES[style]
        size = sizes[style]
        if style == "code":
            pad_x, pad_y = 28, 16
            line_h = int(size * 1.25)
            tw = max(d.textlength(r, font=f) for r in rows)
            d.rounded_rectangle([x, y, x + tw + 2 * pad_x, y + line_h * len(rows) + 2 * pad_y],
                                radius=12, fill=(20, 24, 32), outline=(44, 52, 66), width=2)
            for i, row in enumerate(rows):
                d.text((x + pad_x, y + pad_y + i * line_h), row, font=f, fill=color)
        else:
            line_h = int(size * 1.25)
            for i, row in enumerate(rows):
                draw_marked(d, x, y + i * line_h, row, f, color)
            if style == "title":
                # below the lowest descender (g, j, p, q, y) of the last row
                bar_y = y + line_h * (len(rows) - 1) + f.getbbox("gjpqyẤ")[3] + max(12, size // 8)
                d.rounded_rectangle([x, bar_y, x + 140, bar_y + 8], radius=4, fill=ACCENT)
        y += step
    return y


def draw_footer(d, text, sizes):
    """The footer line and text; "|" splits the left and right parts."""
    foot_y = footer_y(sizes)
    f = font("segoeui.ttf", sizes["footer"])
    left, _, right = text.partition("|")
    d.line([LEFT, foot_y - 25, W - LEFT, foot_y - 25], fill=(36, 42, 54), width=2)
    d.text((LEFT, foot_y), left.strip(), font=f, fill=MUTED)
    right = right.strip()
    if right:
        d.text((W - LEFT - d.textlength(right, font=f), foot_y), right, font=f, fill=MUTED)


def default_sizes():
    return dict(zip(SIZE_KEYS, DEFAULT_SIZES))


def render(lines, sizes=None):
    sizes = sizes or default_sizes()
    img = background()
    d = ImageDraw.Draw(img)
    body, footer = split_footer(lines)

    # Lay the body out first (to measure it), then centre it vertically.
    blocks, total = layout(d, body, sizes, W - 2 * LEFT)
    bottom = footer_y(sizes) - 45 if footer else H - 60
    draw_blocks(d, blocks, sizes, LEFT, max(60, (bottom - total) // 2 + 20))
    if footer:
        draw_footer(d, footer, sizes)
    return img


def make_video(png, seconds, fade=0.6):
    """A still MP4 of png with fade in/out and a silent audio track; returns its path."""
    mp4 = os.path.splitext(png)[0] + ".mp4"
    subprocess.run([
        "ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-i", png,
        "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo",
        "-t", str(seconds), "-r", "30",
        "-vf", f"fade=in:st=0:d={fade},fade=out:st={seconds - fade}:d={fade},format=yuv420p",
        "-c:v", "libx264", "-c:a", "aac", "-shortest", mp4,
    ], check=True)
    return mp4


def read_lines(path):
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "mbcs" if os.name == "nt" else "latin-1"):
        try:
            return raw.decode(enc).splitlines()
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("utf-8", "replace").splitlines()


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("lines", nargs="*", help="lines of the title card (see the styles above)")
    p.add_argument("-f", "--file", help="text file with one line per row")
    p.add_argument("-o", "--output", default=os.path.join("Output", "title.png"))
    p.add_argument("--sizes", type=parse_sizes, metavar='"30,128,46,34,40,28"',
                   help="6 font sizes: label, title, subtitle, code, text, footer; "
                        "'-' or 0 keeps that default (e.g. \"- 150 - - - -\")")
    p.add_argument("--video", action="store_true", help="also make an MP4 with fade in/out")
    p.add_argument("--seconds", type=float, default=4.0)
    args = p.parse_args()

    if args.video and args.seconds <= 1.2:
        raise SystemExit("make_title: --seconds must be more than 1.2 (fade in + fade out)")
    lines = (read_lines(args.file) if args.file else []) + args.lines
    if not lines:
        lines = EXAMPLE

    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
    render(lines, args.sizes).save(args.output)
    print("wrote", args.output)

    if args.video:
        print("wrote", make_video(args.output, args.seconds))


if __name__ == "__main__":
    main()
