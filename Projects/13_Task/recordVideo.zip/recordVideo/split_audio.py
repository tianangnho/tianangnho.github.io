"""Split a video into a video without sound and an .mp3 of its sound.

    python split_audio.py demo.mp4                    # writes demo_silent.mp4 and demo.mp3
    python split_audio.py a.mp4 b.mp4 --out-dir Output
    python split_audio.py demo.mp4 --bitrate 192k --mono
    python split_audio.py demo.mp4 --only mp3         # or: --only video

The picture is copied as it is (fast, no loss of quality); the sound is encoded
to MP3, 128 kbit/s by default.
"""
import argparse
import os
import subprocess
import sys

from merge_video_audio import find_ffmpeg


def main():
    summary, _, details = __doc__.partition("\n")
    ap = argparse.ArgumentParser(description=summary, epilog="examples:" + details,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("videos", nargs="+", help="the videos")
    ap.add_argument("--out-dir", help="folder of the files; default: that of each video")
    ap.add_argument("--bitrate", default="128k", help="bitrate of the .mp3; default 128k")
    ap.add_argument("--mono", action="store_true", help="a mono .mp3 (half the size, enough for a voice)")
    ap.add_argument("--only", choices=["video", "mp3"], help="write only the video without sound, or only the .mp3")
    args = ap.parse_args()

    missing = [v for v in args.videos if not os.path.isfile(v)]
    if missing:
        sys.exit("not found:\n  " + "\n  ".join(missing))
    ffmpeg = find_ffmpeg(None)
    failed = 0
    for video in args.videos:
        folder = args.out_dir or os.path.dirname(os.path.abspath(video))
        os.makedirs(folder, exist_ok=True)
        stem = os.path.join(folder, os.path.splitext(os.path.basename(video))[0])
        silent, mp3 = stem + "_silent.mp4", stem + ".mp3"
        print(f"\n{video}")
        base = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", video]
        if args.only != "mp3":
            if subprocess.run(base + ["-map", "0:v:0", "-c:v", "copy", "-an", "-sn",
                                      "-movflags", "+faststart", silent]).returncode:
                print("  could not write the video without sound")
                failed += 1
            else:
                print(f"  wrote {silent}: {os.path.getsize(silent) / 1024 / 1024:.1f} MB")
        if args.only != "video":
            cmd = base + ["-map", "0:a:0?", "-vn", "-c:a", "libmp3lame", "-b:a", args.bitrate]
            if args.mono:
                cmd += ["-ac", "1"]
            if subprocess.run(cmd + [mp3]).returncode or not os.path.isfile(mp3) or os.path.getsize(mp3) < 1024:
                print("  could not write the .mp3 (does the video have sound?)")
                if os.path.isfile(mp3):
                    os.remove(mp3)
                failed += 1
            else:
                print(f"  wrote {mp3}: {os.path.getsize(mp3) / 1024 / 1024:.1f} MB")
    if failed:
        sys.exit(f"{failed} file(s) not written")


if __name__ == "__main__":
    main()
