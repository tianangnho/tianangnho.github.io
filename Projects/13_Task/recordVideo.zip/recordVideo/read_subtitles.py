"""Read an .srt subtitle file aloud with a voice of Windows (SAPI).

    python read_subtitles.py demo_subtitles.srt                 # choose a voice, pause at each [ACTION]
    python read_subtitles.py demo_subtitles.srt --no-pause      # read straight through
    python read_subtitles.py demo_subtitles.srt --timed         # follow the times of the file
    python read_subtitles.py demo_subtitles.srt --voice Zira --rate -1
    python read_subtitles.py demo_subtitles.srt --start 20      # from entry 20
    python read_subtitles.py demo_subtitles.srt --save demo.wav # write the speech to a WAV file
    python read_subtitles.py demo.srt --save demo.mp3 --timed   # an MP3 that fits the video
    python read_subtitles.py --list-voices

Without --voice, the script lists the voices: type the number of one, or
p<number> to hear it first. Lines "[ACTION: ...]" are shown, not read; in the
default mode the script waits there for Enter (q to quit), so that you can do
the action. Lines "(...)" are notes, shown only. Ctrl+C stops the reading.

To replace the sound of a video with the speech: save it with --timed, so that
each entry is said at its time in the video, then
    python merge_video_audio.py demo.mp4 demo.mp3 demo.srt
Needs Windows and pywin32; .mp3 also needs ffmpeg.
"""
import argparse
import os
import re
import subprocess
import sys
import tempfile
import time
import wave

import win32com.client

# How the voice should say words it reads badly; the screen shows the text as it is.
PRONOUNCE = [
    (r"\.cproject", "dot C project"),
    (r"configuration\.xml", "configuration dot X M L"),
    (r"hal_warmstart\.c", "hal warm start dot C"),
    (r"\bRA0E1\b", "R A zero E one"),
    (r"\bcortex-m23\b", "cortex M 23"),
    (r"\bminus Oz\b", "minus O Z"),
    (r"\bOz\b", "O Z"),
    (r"\bCMake\b", "C Make"),
    (r"\bGCC\b", "G C C"),
    (r"\bFSP\b", "F S P"),
    (r"\bCI\b", "C I"),
    (r"\bsrec\b", "S rec"),
    (r"\bthe elf\b", "the E L F"),
    (r"\be2 studio\b", "E 2 studio"),
    (r"\binspect-command\b", "inspect command"),
    (r"\binspect-sources\b", "inspect sources"),
    (r"\bcompile_commands\.json\b", "compile commands dot JSON"),
    (r"\bcompile-commands\b", "compile commands"),
    (r"\bclangd\b", "clang D"),
    (r"C\+\+", "C plus plus"),
    (r"\bbss\b", "B S S"),
]

SVSF_ASYNC, SVSF_PURGE, SVSF_XML = 1, 2, 8
SSFM_CREATE_FOR_WRITE = 3
SAFT_22KHZ_16BIT_MONO = 22


def parse_srt(path):
    """Returns the entries of the file: (number, start seconds, text)."""
    with open(path, encoding="utf-8-sig") as f:
        blocks = re.split(r"\n\s*\n", f.read().strip())
    entries = []
    for block in blocks:
        lines = block.strip().splitlines()
        if len(lines) < 3 or "-->" not in lines[1]:
            continue
        h, m, s, ms = map(int, re.match(r"(\d+):(\d+):(\d+),(\d+)", lines[1]).groups())
        entries.append((int(lines[0]), h * 3600 + m * 60 + s + ms / 1000, " ".join(l.strip() for l in lines[2:])))
    return entries


def spoken(text):
    for pattern, words in PRONOUNCE:
        text = re.sub(pattern, words, text)
    return text


VOICE_CATEGORIES = [
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices",
    r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech_OneCore\Voices",
]
SAMPLE = "Hello. This is the voice that will read the demo."


def voices():
    """Returns the voices of this computer, desktop and OneCore ones, by description."""
    found = {}
    for path in VOICE_CATEGORIES:
        try:
            category = win32com.client.Dispatch("SAPI.SpObjectTokenCategory")
            category.SetId(path, False)
            tokens = category.EnumerateTokens()
        except Exception:
            continue
        for i in range(tokens.Count):
            token = tokens.Item(i)
            found.setdefault(token.GetDescription(), token)
    # English voices first, as the subtitles are in English
    return sorted(found.items(), key=lambda kv: ("English" not in kv[0], kv[0]))


def choose_voice(sapi, rate):
    """Lists the voices and lets the user pick one; p<number> plays a sample."""
    listed = voices()
    print("Voices of this computer:")
    for i, (description, _) in enumerate(listed, 1):
        print(f"  {i}. {description}")
    while True:
        try:
            answer = input("Number of the voice (Enter for 1, p<number> to hear it): ")
        except EOFError:
            sys.exit("no voice chosen")
        answer = answer.strip("﻿ \t").lower()
        if not answer:
            answer = "1"
        sample = answer.startswith("p")
        number = answer[1:] if sample else answer
        if not number.isdigit() or not 1 <= int(number) <= len(listed):
            print(f"  give a number from 1 to {len(listed)}")
            continue
        sapi.Voice = listed[int(number) - 1][1]
        sapi.Rate = rate
        if sample:
            say(sapi, SAMPLE)
            continue
        return


def voice_for(name, rate):
    """Returns a SAPI voice: the one name matches (its number or part of its
    description), else the one the user chooses from the list."""
    sapi = win32com.client.Dispatch("SAPI.SpVoice")
    sapi.Rate = rate
    if name is None:
        choose_voice(sapi, rate)
        return sapi
    listed = voices()
    for i, (description, token) in enumerate(listed, 1):
        if name == str(i) or name.lower() in description.lower():
            sapi.Voice = token
            sapi.Rate = rate
            return sapi
    sys.exit(f"no voice matches {name!r}; see --list-voices")


def say(sapi, text):
    """Speaks text and returns when it is said; Ctrl+C stops it."""
    sapi.Speak(text, SVSF_ASYNC)
    try:
        while not sapi.WaitUntilDone(100):
            pass
    except KeyboardInterrupt:
        sapi.Speak("", SVSF_ASYNC | SVSF_PURGE)
        raise


def show(kind, text):
    color = {"action": "\033[93m", "note": "\033[90m", "say": "\033[97m"}[kind]
    print(f"{color}{text}\033[0m", flush=True)


def kind_of(text):
    if text.startswith("[ACTION"):
        return "action"
    if text.startswith("(") and text.endswith(")"):
        return "note"
    return "say"


RATE, WIDTH = 22050, 2  # SAFT_22KHZ_16BIT_MONO


def speak_to_pcm(sapi, text, tmp):
    """The raw 22 kHz 16-bit mono samples of text spoken by sapi."""
    path = os.path.join(tmp, "entry.wav")
    stream = win32com.client.Dispatch("SAPI.SpFileStream")
    fmt = win32com.client.Dispatch("SAPI.SpAudioFormat")
    fmt.Type = SAFT_22KHZ_16BIT_MONO
    stream.Format = fmt
    stream.Open(path, SSFM_CREATE_FOR_WRITE, False)
    sapi.AudioOutputStream = stream
    sapi.Speak(text, 0)
    stream.Close()
    with wave.open(path, "rb") as w:
        return w.readframes(w.getnframes())


def save(entries, sapi, path, timed, bitrate):
    """Writes the spoken entries to a WAV or MP3 file.

    timed: each entry starts at its time in the subtitles, so that the file fits the video;
    otherwise the entries follow each other with a short silence between them."""
    def silence(seconds):
        return b"\0" * (int(seconds * RATE) * WIDTH)

    pcm, late = bytearray(), 0
    with tempfile.TemporaryDirectory() as tmp:
        for number, start, text in entries:
            kind = kind_of(text)
            if timed:
                if kind != "say":
                    continue
                at = len(pcm) / WIDTH / RATE
                if at > start + 0.3:  # the entry before was still being said
                    late += 1
                    print(f"  entry {number} starts {at - start:.1f}s late (the one before is too long for its time)")
                pcm += silence(max(0.0, start - at))
                pcm += speak_to_pcm(sapi, spoken(text), tmp)
            else:
                pcm += speak_to_pcm(sapi, spoken(text), tmp) if kind == "say" else silence(1.5)
                pcm += silence(0.4)
            print(f"  {number:3}  {text}" if kind == "say" else f"  {number:3}  (silence) {text}", flush=True)

        wav = path if path.lower().endswith(".wav") else os.path.join(tmp, "speech.wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(WIDTH)
            w.setframerate(RATE)
            w.writeframes(bytes(pcm))
        if wav != path:  # .mp3 or another format: ffmpeg converts it
            from merge_video_audio import find_ffmpeg
            codec = ["-c:a", "libmp3lame", "-b:a", bitrate] if path.lower().endswith(".mp3") else ["-b:a", bitrate]
            result = subprocess.run([find_ffmpeg(None), "-hide_banner", "-loglevel", "error", "-y",
                                     "-i", wav] + codec + [path])
            if result.returncode != 0:
                sys.exit(f"ffmpeg could not write {path}")
    seconds = len(pcm) / WIDTH / RATE
    print(f"wrote {path}: {seconds // 60:.0f}:{seconds % 60:04.1f}"
          + (f", {late} entries late: use a higher --rate, or shorter subtitles" if late else ""))


def main():
    summary, _, details = __doc__.partition("\n")
    ap = argparse.ArgumentParser(description=summary, epilog="examples:" + details,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("srt", nargs="?", help="the subtitle file, e.g. demo_subtitles.srt")
    ap.add_argument("--voice", help="number of the voice in --list-voices, or part of its name, e.g. Zira; default: choose from a list")
    ap.add_argument("--rate", type=int, default=0, help="speed from -10 (slow) to 10 (fast); default 0")
    ap.add_argument("--start", type=int, default=1, help="number of the first entry to read")
    ap.add_argument("--no-pause", action="store_true", help="do not wait for Enter at the [ACTION] lines")
    ap.add_argument("--timed", action="store_true",
                    help="start each entry at its time in the file; with --save, the file then fits the video")
    ap.add_argument("--save", metavar="FILE", help="write the speech to this .wav or .mp3 file instead of playing it")
    ap.add_argument("--bitrate", default="64k", help="bitrate of the .mp3 file of --save; default 64k")
    ap.add_argument("--list-voices", action="store_true", help="list the voices of this computer")
    args = ap.parse_args()

    if args.list_voices:
        for i, (description, _) in enumerate(voices(), 1):
            print(f"{i}. {description}")
        return
    if not args.srt:
        ap.error("give the subtitle file")

    entries = [e for e in parse_srt(args.srt) if e[0] >= args.start]
    sapi = voice_for(args.voice, max(-10, min(10, args.rate)))
    if args.save:
        save(entries, sapi, args.save, args.timed, args.bitrate)
        return

    print(f"Voice: {sapi.Voice.GetDescription()}. Ctrl+C to stop.\n")
    begin = time.monotonic() - (entries[0][1] if entries else 0)
    try:
        for number, start, text in entries:
            kind = kind_of(text)
            if args.timed:
                time.sleep(max(0.0, start - (time.monotonic() - begin)))
            show(kind, f"{number:3}  {text}")
            if kind == "say":
                say(sapi, spoken(text))
            elif kind == "action" and not args.no_pause and not args.timed:
                if input("     Enter to go on, q to quit: ").strip().lower() == "q":
                    break
    except KeyboardInterrupt:
        print("\nstopped")


if __name__ == "__main__":
    main()
