"""Concatenate several videos, one after another, into one .mp4.

    python concat_videos.py part1.mp4 part2.mp4 part3.mp4 -o full.mp4
    python concat_videos.py selected_files.txt                 (one path per line)
    python concat_videos.py *.mp4 --sort time                  (oldest first)
    python concat_videos.py b.mp4 a.mp4 --sort none            (keep the given order)
    python concat_videos.py a.mp4 b.mkv --reencode --codec h265

The order is the natural order of the file names by default (clip2 before clip10);
--sort time orders by modification time, --sort none keeps the order given.

When all the videos have the same codec, size, frame rate and audio format, they
are joined without re-encoding (fast, no loss of quality). Otherwise, or with
--reencode, they are re-encoded to the size and frame rate of the first video;
smaller or differently shaped videos are centred with black borders, and videos
without sound get silence.

Needs ffmpeg and ffprobe: on PATH, given with --ffmpeg, or installed by winget.
"""
import argparse
import datetime
import json
import os
import re
import subprocess
import sys
import tempfile

from merge_video_audio import find_ffmpeg


def read_list(path):
    """Paths from a text file, one per line; the file may be UTF-8 or the Windows code page."""
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "mbcs" if os.name == "nt" else "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except (UnicodeDecodeError, LookupError):
            continue
    return [l.strip().strip('"') for l in text.splitlines() if l.strip()]


def collect(inputs):
    files = []
    for item in inputs:
        if item.lower().endswith(".txt"):
            files += read_list(item)
        else:
            files.append(item)
    missing = [f for f in files if not os.path.isfile(f)]
    if missing:
        sys.exit("not found:\n  " + "\n  ".join(missing))
    return [os.path.abspath(f) for f in files]


def natural_key(path):
    name = os.path.basename(path).lower()
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", name)]


def probe(ffprobe, path):
    out = subprocess.run([ffprobe, "-v", "error", "-show_streams", "-show_format", "-of", "json", path],
                         capture_output=True, text=True, encoding="utf-8")
    if out.returncode != 0:
        sys.exit(f"ffprobe could not read {path}:\n{out.stderr}")
    info = json.loads(out.stdout)
    v = next((s for s in info["streams"] if s["codec_type"] == "video"), None)
    a = next((s for s in info["streams"] if s["codec_type"] == "audio"), None)
    if v is None:
        sys.exit(f"{path} has no video stream")
    return {
        "duration": float(info["format"].get("duration") or v.get("duration") or 0),
        "width": v["width"], "height": v["height"],
        "fps": v.get("avg_frame_rate") if v.get("avg_frame_rate") not in (None, "0/0") else v.get("r_frame_rate"),
        "video": (v["codec_name"], v.get("profile"), v["width"], v["height"], v.get("pix_fmt"),
                  v.get("r_frame_rate"), v.get("time_base")),
        "audio": (a["codec_name"], a.get("sample_rate"), a.get("channels"), a.get("time_base")) if a else None,
    }


def copy_command(ffmpeg, files, output, tmp):
    lst = os.path.join(tmp, "list.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p in files:
            f.write("file '" + p.replace("\\", "/").replace("'", "'\\''") + "'\n")
    return [ffmpeg, "-hide_banner", "-y", "-f", "concat", "-safe", "0", "-i", lst,
            "-map", "0", "-c", "copy", "-movflags", "+faststart", output]


def reencode_command(ffmpeg, files, infos, output, args):
    w, h = args.width or infos[0]["width"], args.height or infos[0]["height"]
    w, h = w // 2 * 2, h // 2 * 2
    fps = args.fps or infos[0]["fps"]
    has_audio = any(i["audio"] for i in infos)

    cmd = [ffmpeg, "-hide_banner", "-y"]
    for p in files:
        cmd += ["-i", p]
    parts, pairs = [], []
    for n, info in enumerate(infos):
        parts.append(f"[{n}:v]scale={w}:{h}:force_original_aspect_ratio=decrease,"
                     f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps},format=yuv420p[v{n}]")
        pair = f"[v{n}]"
        if has_audio:
            if info["audio"]:
                parts.append(f"[{n}:a]aresample=48000,aformat=channel_layouts=stereo[a{n}]")
            else:
                parts.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={info['duration']:.3f}[a{n}]")
            pair += f"[a{n}]"
        pairs.append(pair)
    parts.append("".join(pairs) + f"concat=n={len(files)}:v=1:a={1 if has_audio else 0}"
                 + ("[v][a]" if has_audio else "[v]"))
    cmd += ["-filter_complex", ";".join(parts), "-map", "[v]"]
    if has_audio:
        cmd += ["-map", "[a]", "-c:a", "aac", "-b:a", args.audio_bitrate]
    codec = {"h264": ["-c:v", "libx264"],
             "h265": ["-c:v", "libx265", "-tag:v", "hvc1", "-x265-params", "log-level=error"]}[args.codec]
    crf = args.crf if args.crf is not None else {"h264": 23, "h265": 28}[args.codec]
    cmd += codec + ["-crf", str(crf), "-preset", args.preset, "-movflags", "+faststart", output]
    return cmd


def run_ffmpeg(cmd):
    """Runs ffmpeg showing its output; returns (exit code, True when the timestamps
    came out broken, which makes the joined video freeze when played)."""
    proc = subprocess.Popen(cmd, stderr=subprocess.PIPE)
    seen, tail = False, b""
    while True:
        chunk = proc.stderr.read1(4096) if hasattr(proc.stderr, "read1") else proc.stderr.read(4096)
        if not chunk:
            break
        sys.stderr.buffer.write(chunk)
        sys.stderr.flush()
        tail = (tail + chunk)[-200:]
        seen = seen or b"Non-monotonic DTS" in tail or b"Non-monotonous DTS" in tail
    return proc.wait(), seen


def show(cmd):
    print(" ".join(f'"{c}"' if " " in c or ";" in c else c for c in cmd))


def main():
    summary, _, details = __doc__.partition("\n")
    ap = argparse.ArgumentParser(description=summary, epilog="examples:" + details,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("inputs", nargs="+", help="the videos, or .txt files listing them (one path per line)")
    ap.add_argument("-o", "--output", help="the joined file; default merged_<date>_<time>.mp4 next to the first video")
    ap.add_argument("--sort", choices=["name", "time", "none"], default="name",
                    help="name: natural order of the file names (default); time: oldest first; none: as given")
    ap.add_argument("--reencode", action="store_true", help="re-encode even when the videos could be joined as they are")
    ap.add_argument("--codec", choices=["h264", "h265"], default="h264", help="codec when re-encoding; default h264")
    ap.add_argument("--crf", type=int, help="quality when re-encoding, higher is smaller: default 23 (h264) or 28 (h265)")
    ap.add_argument("--preset", default="medium", help="encoder preset when re-encoding; default medium")
    ap.add_argument("--width", type=int, help="width when re-encoding; default that of the first video")
    ap.add_argument("--height", type=int, help="height when re-encoding; default that of the first video")
    ap.add_argument("--fps", help="frame rate when re-encoding; default that of the first video")
    ap.add_argument("--audio-bitrate", default="128k", help="AAC bitrate when re-encoding; default 128k")
    ap.add_argument("--ffmpeg", help="path of ffmpeg.exe (ffprobe.exe is looked for next to it)")
    ap.add_argument("--dry-run", action="store_true", help="print the order and the ffmpeg command, do not run it")
    args = ap.parse_args()

    files = collect(args.inputs)
    if len(files) < 2:
        sys.exit("give at least two videos")
    if args.sort == "name":
        files.sort(key=natural_key)
    elif args.sort == "time":
        files.sort(key=os.path.getmtime)

    ffmpeg = find_ffmpeg(args.ffmpeg)
    ffprobe = os.path.join(os.path.dirname(ffmpeg), "ffprobe" + (".exe" if os.name == "nt" else ""))
    if not os.path.isfile(ffprobe):
        ffprobe = "ffprobe"

    output = os.path.abspath(args.output or os.path.join(
        os.path.dirname(files[0]), datetime.datetime.now().strftime("merged_%Y%m%d_%H%M%S.mp4")))
    if output in files:
        sys.exit("the output must not be one of the inputs")

    infos = [probe(ffprobe, p) for p in files]
    print("order:")
    for n, (p, i) in enumerate(zip(files, infos), 1):
        print(f"  {n:2}. {os.path.basename(p)}  ({i['width']}x{i['height']}, {i['duration']:.1f}s"
              + ("" if i["audio"] else ", no sound") + ")")
    print(f"total: {sum(i['duration'] for i in infos):.1f}s")

    same = all(i["video"] == infos[0]["video"] and i["audio"] == infos[0]["audio"] for i in infos)
    copy = same and not args.reencode
    print("joining without re-encoding" if copy else
          "re-encoding" + ("" if args.reencode else " (the videos differ in format)"))

    with tempfile.TemporaryDirectory() as tmp:
        cmd = copy_command(ffmpeg, files, output, tmp) if copy else reencode_command(ffmpeg, files, infos, output, args)
        show(cmd)
        if args.dry_run:
            return
        code, broken = run_ffmpeg(cmd)
        if copy and (code != 0 or broken):
            print("\njoining without re-encoding " + ("gave broken timestamps (the video would freeze)"
                                                     if code == 0 else "failed") + "; re-encoding instead")
            cmd = reencode_command(ffmpeg, files, infos, output, args)
            show(cmd)
            code, _ = run_ffmpeg(cmd)
        if code != 0:
            sys.exit(f"ffmpeg failed with exit code {code}")
    print(f"wrote {output}: {os.path.getsize(output) / 1024 / 1024:.1f} MB")


if __name__ == "__main__":
    main()
