"""Menu of the video tools; record.cmd starts it.

Each tool asks its options one after another (9 or Enter takes the default
of the step, 0 goes back), then opens a dialog to choose the files, shows the command and
asks whether to choose more files or to run it. Everything a tool writes goes
into Output\\<YYYY-MM-DD_hh> next to this script.
"""
import datetime
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_ROOT = os.path.join(HERE, "Output")
PY = sys.executable

VIDEO = ("Video", "*.mp4 *.mkv *.avi *.mov *.webm *.m4v *.wmv")
AUDIO = ("Âm thanh", "*.mp3 *.wav *.m4a *.aac *.wma *.flac *.ogg")
SUBS = ("Phụ đề", "*.srt")
TEXT = ("File chữ", "*.txt")
IMAGE = ("Hình", "*.png *.jpg *.jpeg *.bmp *.gif *.webp")
WORD = ("Word / PDF", "*.docx *.doc *.docm *.rtf *.odt *.pdf")

# Step of make_title / make_image: the 6 font sizes.
SIZES_STEP = {"key": "sizes", "title": "Cỡ chữ (nhãn, tiêu đề, phụ đề, code, chữ thường, chân trang)", "options": [
    ("Mặc định: 30, 128, 46, 34, 40, 28", None),
    ("Nhỏ hơn:  26, 104, 38, 30, 34, 24 (khi có nhiều dòng)", "26,104,38,30,34,24"),
    ("Lớn hơn:  36, 156, 54, 40, 48, 32 (khi ít chữ)", "36,156,54,40,48,32"),
    ("Tự nhập 6 số", "custom")]}

last_dir = os.getcwd()


# ---------------------------------------------------------------- screen and input

def clear():
    if sys.stdout.isatty():
        os.system("cls" if os.name == "nt" else "clear")


def header(title):
    clear()
    print("=" * 50)
    print(f"  {title}")
    print("=" * 50)


def ask(prompt):
    try:
        return input(prompt).strip("﻿ \t").lower()
    except EOFError:
        sys.exit()


def pause():
    ask("\nEnter để tiếp tục...")


def numbers(n):
    """1..8, then 10, 11...: 9 and 0 are kept for 'default' and 'back'."""
    return [str(i) for i in range(1, n + 2) if i != 9][:n]


def ask_options(title, steps):
    """Asks the steps one after another; returns {key: value}, or None for 0 (back).

    A step is {key, title, options: [(label, value)] or f(chosen), default: index, when: f(chosen)}.
    9 (or Enter) takes the default of this step only."""
    chosen = {}
    for step in steps:
        if step.get("when") and not step["when"](chosen):
            continue
        options = step["options"](chosen) if callable(step["options"]) else step["options"]
        default = step.get("default", 0)
        header(title)
        done = [f"{s['title']}: {label}" for s in steps if s["key"] in chosen
                for label, value in (s["options"](chosen) if callable(s["options"]) else s["options"])
                if value == chosen[s["key"]]]
        for line in done:
            print(f"  ✓ {line}")
        if done:
            print()
        print(step["title"])
        keys = numbers(len(options))
        for i, (key, (label, _)) in enumerate(zip(keys, options)):
            print(f"  {key}. {label}" + ("   (mặc định)" if i == default else ""))
        print(f"  9. Mặc định: {options[default][0]}")
        print("  0. Quay lại")
        while True:
            answer = ask("Chọn [Enter = 9]: ")
            if answer == "0":
                return None
            if answer in ("", "9"):
                chosen[step["key"]] = options[default][1]
                break
            if answer in keys:
                chosen[step["key"]] = options[keys.index(answer)][1]
                break
            print("  Lựa chọn không hợp lệ.")
    return chosen


def dialog(title, filetype, multiple=True):
    """Paths chosen in an Open dialog; [] when it is cancelled."""
    global last_dir
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)  # in front of the console
    root.update()
    kw = dict(parent=root, title=title, initialdir=last_dir, filetypes=[filetype, ("Tất cả", "*.*")])
    if multiple:
        paths = list(root.tk.splitlist(filedialog.askopenfilenames(**kw)))
    else:
        path = filedialog.askopenfilename(**kw)
        paths = [path] if path else []
    root.destroy()
    paths = [os.path.normpath(p) for p in paths]
    if paths:
        last_dir = os.path.dirname(paths[0])
    return paths


# ---------------------------------------------------------------- output and commands

def output_dir():
    return os.path.join(OUTPUT_ROOT, datetime.datetime.now().strftime("%Y-%m-%d_%H"))


def unique(path, taken):
    """path, or path with _2, _3... when it exists or is already given to another command."""
    stem, ext = os.path.splitext(path)
    n, candidate = 1, path
    while os.path.exists(candidate) or candidate in taken:
        n += 1
        candidate = f"{stem}_{n}{ext}"
    taken.add(candidate)
    return candidate


def stem(path):
    return os.path.splitext(os.path.basename(path))[0]


def shown(cmd):
    return subprocess.list2cmdline(["python" if cmd[0] == PY else cmd[0]] + cmd[1:])


def run(cmds, out_dir):
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    failed = 0
    for cmd in cmds:
        print("\n> " + shown(cmd) + "\n", flush=True)
        try:
            failed += subprocess.run(cmd).returncode != 0
        except KeyboardInterrupt:
            print("\nĐã dừng.")
            failed += 1
            break
    print("\n" + "-" * 50)
    print("Xong." if not failed else f"{failed} lệnh bị lỗi, xem thông báo ở trên.")
    if out_dir:
        print(f"Output: {out_dir}")
    pause()


def choose_and_run(title, pick, build, out_dir):
    """Opens the dialog(s) with pick(), shows the command(s) of build(items), then asks
    whether to choose more files, to run, or to go back."""
    items = []
    while True:
        new = pick()
        items += [i for i in new if i not in items]
        if not items:
            print("Không có file nào được chọn.")
            pause()
            return
        header(title)
        print("File đã chọn:")
        for n, item in enumerate(items, 1):
            print(f"  {n}. " + "\n     ".join(item if isinstance(item, tuple) else [item]))
        cmds = build(items)
        print("\nLệnh sẽ chạy:")
        for cmd in cmds:
            print("  " + shown(cmd))
        print("\n  1. Chọn thêm file")
        print("  2. Chạy lệnh   (Enter)")
        print("  0. Quay lại")
        while True:
            answer = ask("Chọn: ")
            if answer in ("0", "1", "2", ""):
                break
            print("  Lựa chọn không hợp lệ.")
        if answer == "0":
            return
        if answer in ("2", ""):
            run(cmds, out_dir)
            return


# ---------------------------------------------------------------- the tools

def tool_concat():
    title = "NỐI VIDEO"
    opts = ask_options(title, [
        {"key": "sort", "title": "Thứ tự nối", "options": [
            ("Theo thứ tự chọn file: chọn trước nối trước, mỗi lần chọn 1 video", "none"),
            ("Theo tên file (clip2 trước clip10), chọn nhiều video một lần", "name"),
            ("Theo thời gian sửa file, cũ trước, chọn nhiều video một lần", "time")]},
        {"key": "codec", "title": "Cách nối", "options": [
            ("Tự động: nối thẳng nếu cùng định dạng, khác thì encode lại", None),
            ("Luôn encode lại, H.264 (phát được mọi nơi)", "h264"),
            ("Luôn encode lại, H.265 (file nhỏ hơn)", "h265")]},
    ])
    if opts is None:
        return
    out_dir = output_dir()

    def build(files):
        from concat_videos import natural_key
        if opts["sort"] == "name":
            files = sorted(files, key=natural_key)
        elif opts["sort"] == "time":
            files = sorted(files, key=os.path.getmtime)
        out = unique(os.path.join(out_dir, f"merged_{stem(files[0])}.mp4"), set())
        cmd = [PY, os.path.join(HERE, "concat_videos.py"), *files, "--sort", "none", "-o", out]
        if opts["codec"]:
            cmd += ["--reencode", "--codec", opts["codec"]]
        return [cmd]

    picked = []

    def pick():
        # Windows does not give the files of one dialog in the order they were clicked:
        # for the order of choosing, each dialog takes one video
        if opts["sort"] == "none":
            new = dialog(f"Chọn video thứ {len(picked) + 1} (theo thứ tự nối)", VIDEO, multiple=False)
        else:
            new = dialog("Chọn các video cần nối", VIDEO)
        picked.extend(new)
        return new

    choose_and_run(title, pick, build, out_dir)


def ask_durations(files):
    """Lengths of the parts typed on one line, for concat_subtitles.py; "" = all from the videos."""
    from concat_subtitles import parse_durations, video_duration
    print("\nNhập độ dài video của từng phần, MỘT LẦN trên một dòng, theo thứ tự trên,")
    print("  cách nhau bằng dấu cách, ví dụ:  1:25 2:03.5 90   (giây, m:ss hoặc h:mm:ss)")
    print(f"  Cần {len(files) - 1} số (phần cuối không cần). Phần không nhập thì lấy từ video cùng tên:")
    for n, srt in enumerate(files[:-1], 1):
        found = video_duration(srt)
        print(f"    {n}. " + (f"{found[1]}: {found[0]:.1f}s" if found else "không có video cùng tên → hết câu cuối"))
    print("  Enter = lấy hết từ video cùng tên")
    while True:
        answer = ask("Độ dài: ")
        try:
            durations = parse_durations(answer)
        except ValueError as e:
            print(f"  {e}")
            continue
        if len(durations) > len(files):
            print(f"  Nhập nhiều nhất {len(files)} số.")
            continue
        return " ".join(f"{d:g}" for d in durations)


def tool_concat_subs():
    title = "NỐI NHIỀU PHỤ ĐỀ THÀNH 1 FILE"
    opts = ask_options(title, [
        {"key": "sort", "title": "Thứ tự nối", "options": [
            ("Theo thứ tự chọn file: chọn trước nối trước, mỗi lần chọn 1 file", "none"),
            ("Theo tên file (p2 trước p10), chọn nhiều file một lần", "name")]},
        {"key": "gap", "title": "Khoảng chèn giữa các phần (vd. trang tiêu đề chèn giữa)", "options": [
            ("Không có", 0), ("3 giây", 3), ("4 giây", 4), ("5 giây", 5)]},
    ])
    if opts is None:
        return
    out_dir = output_dir()
    picked, asked = [], {}

    def pick():
        if opts["sort"] == "none":
            new = dialog(f"Chọn phụ đề thứ {len(picked) + 1} (theo thứ tự nối)", SUBS, multiple=False)
        else:
            new = dialog("Chọn các file phụ đề cần nối", SUBS)
        picked.extend(new)
        return new

    def build(files):
        from concat_subtitles import natural_key
        if opts["sort"] == "name":
            files = sorted(files, key=natural_key)
            print("\nThứ tự nối (theo tên): " + ", ".join(os.path.basename(f) for f in files))
        key = tuple(files)
        if key not in asked:
            asked[key] = ask_durations(files) if len(files) > 1 else ""
        cmd = [PY, os.path.join(HERE, "concat_subtitles.py"), *files,
               "-o", unique(os.path.join(out_dir, f"merged_{stem(files[0])}.srt"), set())]
        if asked[key]:
            cmd += ["--durations", asked[key]]
        if opts["gap"]:
            cmd += ["--gap", str(opts["gap"])]
        return [cmd]

    choose_and_run(title, pick, build, out_dir)


def ask_cuts(video):
    """The parts of video to remove, typed by the user, e.g. "[10,15], [20,24]"."""
    from concat_subtitles import format_time
    from concat_videos import probe
    from cut_video import kept_parts, parse_cuts
    from merge_video_audio import find_ffmpeg
    ffprobe = os.path.join(os.path.dirname(find_ffmpeg(None)), "ffprobe.exe")
    duration = probe(ffprobe if os.path.isfile(ffprobe) else "ffprobe", video)["duration"]
    print(f"\n{os.path.basename(video)}: dài {format_time(duration)[:-4]} ({duration:.1f} giây)")
    print("Nhập các đoạn cần CẮT BỎ, ví dụ:  [10,15], [20,24]   hoặc  [1:20-1:31.5]")
    print("  thời gian: giây (10.5), m:ss (1:20) hoặc h:mm:ss;  [-5] = 5 giây đầu,  [80-] = từ 80 giây đến hết")
    while True:
        answer = ask("Đoạn cắt bỏ: ")
        try:
            cuts = parse_cuts(answer, duration)
        except ValueError as e:
            print(f"  {e}")
            continue
        parts = kept_parts(cuts, duration)
        if not parts:
            print("  Cắt hết cả video, nhập lại.")
            continue
        left = sum(e - s for s, e in parts)
        print("  Giữ lại: " + ", ".join(f"[{s:g}-{e:g}]" for s, e in parts)
              + f"  → còn {left:.1f} giây (bỏ {duration - left:.1f} giây)")
        return ", ".join(f"[{s:g}-{e:g}]" for s, e in cuts)


def tool_cut():
    title = "CẮT BỎ CÁC ĐOẠN TRONG VIDEO"
    opts = ask_options(title, [
        {"key": "codec", "title": "Hình (video được encode lại để cắt đúng từng khung hình)", "options": [
            ("H.264 (phát được mọi nơi)", "h264"), ("H.265 (file nhỏ hơn)", "h265")]},
    ])
    if opts is None:
        return
    out_dir = output_dir()
    asked = {}

    def pick():
        video = dialog("1/2  Chọn video cần cắt", VIDEO, multiple=False)
        if not video:
            return []
        srt = dialog("2/2  Chọn phụ đề của video để cắt theo (Cancel = không có)", SUBS, multiple=False)
        return [tuple(video + srt)]

    def build(sets):
        taken, cmds = set(), []
        for files in sets:
            if files not in asked:
                asked[files] = ask_cuts(files[0])
            cmd = [PY, os.path.join(HERE, "cut_video.py"), files[0], asked[files], "--codec", opts["codec"],
                   "-o", unique(os.path.join(out_dir, stem(files[0]) + "_cut.mp4"), taken)]
            if len(files) > 1:
                cmd += ["--srt", files[1]]
            cmds.append(cmd)
        return cmds

    choose_and_run(title, pick, build, out_dir)


def tool_split_audio():
    title = "TÁCH VIDEO KHÔNG TIẾNG + MP3"
    opts = ask_options(title, [
        {"key": "only", "title": "Xuất ra", "options": [
            ("Cả video không tiếng (_silent.mp4) và file .mp3", None),
            ("Chỉ file .mp3", "mp3"),
            ("Chỉ video không tiếng", "video")]},
        {"key": "quality", "title": "Chất lượng mp3", "when": lambda chosen: chosen["only"] != "video",
         "options": [
             ("128 kbit/s stereo (thường dùng)", ("128k", False)),
             ("192 kbit/s stereo (nhạc, chất lượng cao)", ("192k", False)),
             ("64 kbit/s mono (giọng nói, file nhỏ)", ("64k", True))]},
    ])
    if opts is None:
        return
    out_dir = output_dir()

    def build(files):
        cmd = [PY, os.path.join(HERE, "split_audio.py"), *files, "--out-dir", out_dir]
        if opts["only"]:
            cmd += ["--only", opts["only"]]
        if opts.get("quality"):
            bitrate, mono = opts["quality"]
            cmd += ["--bitrate", bitrate] + (["--mono"] if mono else [])
        return [cmd]

    choose_and_run(title, lambda: dialog("Chọn các video cần tách tiếng", VIDEO), build, out_dir)


def tool_subtitles():
    title = "TẠO PHỤ ĐỀ TỪ VIDEO"
    opts = ask_options(title, [
        {"key": "language", "title": "Ngôn ngữ người nói trong video", "options": [
            ("Tự nhận diện", None), ("Tiếng Việt", "vi"), ("Tiếng Anh", "en"), ("Tiếng Nhật", "ja")]},
        {"key": "to", "title": "Ngôn ngữ phụ đề xuất ra", "options": [
            ("Giống ngôn ngữ người nói", None), ("Tiếng Việt", "vi"), ("Tiếng Anh", "en")]},
        {"key": "model", "title": "Model nhận dạng giọng nói", "options": [
            ("small: cân bằng tốc độ và độ chính xác", "small"),
            ("base: nhanh, kém chính xác hơn", "base"),
            ("medium: chính xác hơn, chậm hơn (dịch sang tiếng Anh tốt hơn)", "medium"),
            ("large-v3-turbo: chính xác nhất, chậm, tải ~1.6 GB lần đầu", "large-v3-turbo")]},
        {"key": "format", "title": "Định dạng file", "options": [
            (".srt", "srt"), (".vtt", "vtt"), (".txt (chỉ chữ, không có thời gian)", "txt")]},
    ])
    if opts is None:
        return
    out_dir = output_dir()

    def build(files):
        cmd = [PY, os.path.join(HERE, "make_subtitles.py"), *files,
               "--model", opts["model"], "--format", opts["format"], "--out-dir", out_dir]
        if opts["language"]:
            cmd += ["--language", opts["language"]]
        if opts["to"]:
            cmd += ["--to", opts["to"]]
        return [cmd]

    choose_and_run(title, lambda: dialog("Chọn các video cần tạo phụ đề", VIDEO), build, out_dir)


def voice_options(_):
    from read_subtitles import voices
    return [(description, str(n)) for n, (description, _) in enumerate(voices(), 1)]


def tool_read():
    title = "ĐỌC PHỤ ĐỀ / XUẤT MP3"
    opts = ask_options(title, [
        {"key": "mode", "title": "Làm gì", "options": [
            ("Lưu mp3 khớp thời gian video (để thay tiếng của video)", "mp3-timed"),
            ("Lưu mp3, đọc liền các câu", "mp3"),
            ("Đọc to, dừng ở mỗi dòng [ACTION]", "play"),
            ("Đọc to theo thời gian trong file", "play-timed")]},
        {"key": "voice", "title": "Giọng đọc", "options": voice_options},
        {"key": "rate", "title": "Tốc độ đọc", "options": [
            ("Bình thường (0)", 0), ("Nhanh hơn (+2)", 2), ("Rất nhanh (+4)", 4), ("Chậm hơn (-2)", -2)]},
    ])
    if opts is None:
        return
    saves = opts["mode"].startswith("mp3")
    out_dir = output_dir() if saves else None

    def build(files):
        taken, cmds = set(), []
        for srt in files:
            cmd = [PY, os.path.join(HERE, "read_subtitles.py"), srt,
                   "--voice", opts["voice"], f"--rate={opts['rate']}"]
            if saves:
                cmd += ["--save", unique(os.path.join(out_dir, stem(srt) + ".mp3"), taken)]
            if opts["mode"].endswith("timed"):
                cmd += ["--timed"]
            cmds.append(cmd)
        return cmds

    choose_and_run(title, lambda: dialog("Chọn các file phụ đề (.srt)", SUBS), build, out_dir)


def tool_merge():
    title = "GHÉP VIDEO + FILE MP3 CÓ SẴN + PHỤ ĐỀ"
    opts = ask_options(title, [
        {"key": "mix", "title": "Âm thanh", "options": [
            ("Thay tiếng gốc của video bằng file âm thanh mới", False),
            ("Trộn file âm thanh mới với tiếng gốc", True)]},
        {"key": "subs", "title": "Phụ đề", "options": [
            ("Track phụ đề, người xem bật/tắt được", "soft"),
            ("In thẳng vào hình", "burn"),
            ("Không có phụ đề", "none")]},
        {"key": "video", "title": "Hình", "options": lambda chosen: [
            ("Nén nhỏ, H.265", "h265"),
            ("Nén, H.264 (phát được mọi nơi)", "h264")] + ([] if chosen.get("subs") == "burn" else [
            ("Giữ nguyên hình, chỉ thay tiếng (nhanh nhất)", "copy")])},
    ])
    if opts is None:
        return
    out_dir = output_dir()

    def pick():
        video = dialog("1/3  Chọn video", VIDEO, multiple=False)
        if not video:
            return []
        audio = dialog("2/3  Chọn file âm thanh có sẵn (mp3, wav...)", AUDIO, multiple=False)
        if not audio:
            return []
        srt = []
        if opts["subs"] != "none":
            srt = dialog("3/3  Chọn file phụ đề (Cancel = không có phụ đề)", SUBS, multiple=False)
        return [tuple(video + audio + srt)]

    def build(sets):
        taken, cmds = set(), []
        for files in sets:
            cmd = [PY, os.path.join(HERE, "merge_video_audio.py"), *files, "--subs", opts["subs"]]
            cmd += ["--copy-video"] if opts["video"] == "copy" else ["--codec", opts["video"]]
            if opts["mix"]:
                cmd += ["--mix"]
            cmd += ["-o", unique(os.path.join(out_dir, stem(files[0]) + "_final.mp4"), taken)]
            cmds.append(cmd)
        return cmds

    choose_and_run(title, pick, build, out_dir)


def tool_dub():
    title = "VIDEO + PHỤ ĐỀ → MP3 + VIDEO CÓ GIỌNG ĐỌC VÀ PHỤ ĐỀ"
    opts = ask_options(title, [
        {"key": "voice", "title": "Giọng đọc", "options": voice_options},
        {"key": "rate", "title": "Tốc độ đọc", "options": [
            ("Bình thường (0)", 0), ("Nhanh hơn (+2)", 2), ("Rất nhanh (+4)", 4), ("Chậm hơn (-2)", -2)]},
        {"key": "mix", "title": "Âm thanh", "options": [
            ("Thay tiếng gốc của video bằng giọng đọc", False),
            ("Trộn giọng đọc với tiếng gốc", True)]},
        {"key": "subs", "title": "Phụ đề trong video", "options": [
            ("Track phụ đề, người xem bật/tắt được", "soft"),
            ("In thẳng vào hình", "burn"),
            ("Không có phụ đề (chỉ giọng đọc)", "none")]},
        {"key": "video", "title": "Hình", "options": lambda chosen: [
            ("Nén nhỏ, H.265", "h265"),
            ("Nén, H.264 (phát được mọi nơi)", "h264")] + ([] if chosen.get("subs") == "burn" else [
            ("Giữ nguyên hình (nhanh nhất)", "copy")])},
    ])
    if opts is None:
        return
    out_dir = output_dir()

    def pick():
        video = dialog("1/2  Chọn video", VIDEO, multiple=False)
        if not video:
            return []
        srt = dialog("2/2  Chọn file phụ đề (.srt): giọng đọc mp3 được tạo từ phụ đề này", SUBS, multiple=False)
        if not srt:
            return []
        return [tuple(video + srt)]

    def build(sets):
        taken, cmds = set(), []
        for video, srt in sets:
            cmd = [PY, os.path.join(HERE, "dub_video.py"), video, srt,
                   "--voice", opts["voice"], f"--rate={opts['rate']}", "--subs", opts["subs"],
                   "--mp3", unique(os.path.join(out_dir, stem(video) + ".mp3"), taken),
                   "-o", unique(os.path.join(out_dir, stem(video) + "_final.mp4"), taken)]
            cmd += ["--copy-video"] if opts["video"] == "copy" else ["--codec", opts["video"]]
            if opts["mix"]:
                cmd += ["--mix"]
            cmds.append(cmd)
            print(f"\n  → sẽ tạo: {os.path.basename(cmd[cmd.index('--mp3') + 1])} (đọc từ phụ đề)"
                  f" và {os.path.basename(cmd[cmd.index('-o') + 1])}")
        return cmds

    choose_and_run(title, pick, build, out_dir)


def tool_vi_to_en():
    title = "VIDEO TIẾNG VIỆT → BẢN TIẾNG ANH"
    opts = ask_options(title, [
        {"key": "model", "title": "Model nhận dạng giọng nói tiếng Việt", "options": [
            ("small: cân bằng tốc độ và độ chính xác", "small"),
            ("medium: chính xác hơn, chậm hơn", "medium"),
            ("large-v3-turbo: chính xác nhất, chậm, tải ~1.6 GB lần đầu", "large-v3-turbo"),
            ("base: nhanh, kém chính xác", "base")]},
        {"key": "translator", "title": "Cách dịch sang tiếng Anh", "options": [
            ("Argos: nhận dạng 1 lần rồi dịch từng câu, 2 phụ đề cùng thời gian", "argos"),
            ("Whisper: nhận dạng thêm 1 lần để dịch (nên dùng medium trở lên)", "whisper")]},
        {"key": "voice", "title": "Giọng đọc tiếng Anh", "options": voice_options},
        {"key": "rate", "title": "Tốc độ đọc", "options": [
            ("Bình thường (0)", 0), ("Nhanh hơn (+2)", 2), ("Rất nhanh (+4)", 4), ("Chậm hơn (-2)", -2)]},
        {"key": "subs", "title": "Phụ đề tiếng Anh trong video", "options": [
            ("In thẳng lên màn hình", "burn"),
            ("Track phụ đề, người xem bật/tắt được", "soft")]},
        {"key": "codec", "title": "Hình", "options": [
            ("H.264 (phát được mọi nơi)", "h264"), ("H.265 (file nhỏ hơn)", "h265")]},
    ])
    if opts is None:
        return
    out_dir = output_dir()

    def build(files):
        cmds = []
        for video in files:
            # each video in its own folder: its 5 files keep the name of the video
            folder = unique(os.path.join(out_dir, stem(video)), set()) if len(files) > 1 else out_dir
            cmds.append([PY, os.path.join(HERE, "vi_to_en_video.py"), video, "--out-dir", folder,
                         "--model", opts["model"], "--translator", opts["translator"],
                         "--voice", opts["voice"], f"--rate={opts['rate']}",
                         "--subs", opts["subs"], "--codec", opts["codec"]])
        return cmds

    choose_and_run(title, lambda: dialog("Chọn video nói tiếng Việt", VIDEO), build, out_dir)


def ask_sizes(title):
    """6 font sizes typed by the user, as "a,b,c,d,e,f"; None for 0 (back)."""
    from make_title import DEFAULT_SIZES, SIZE_KEYS, parse_sizes
    header(title)
    print("Nhập 6 cỡ chữ (pixel), cách nhau bằng dấu phẩy hoặc dấu cách, theo thứ tự:")
    print("  nhãn, tiêu đề, phụ đề, code, chữ thường, chân trang")
    print("  Mặc định: " + ", ".join(map(str, DEFAULT_SIZES)))
    print("  Ghi - để giữ mặc định ở vị trí đó, ví dụ:  - 150 - - - -")
    print("  Enter = dùng mặc định, 0 = quay lại")
    while True:
        answer = ask("Cỡ chữ: ")
        if answer == "0":
            return None
        if not answer:
            return ""
        try:
            sizes = parse_sizes(answer)
        except Exception as e:
            print(f"  {e}")
            continue
        return ",".join(str(sizes[k]) for k in SIZE_KEYS)


def ask_seconds(title, opts, label="Độ dài video (giây)", minimum=1.5):
    """When opts["seconds"] is "custom", asks the user for it; False for 0 (back)."""
    if opts.get("seconds") != "custom":
        return True
    header(title)
    print(f"Nhập {label.lower()}, ví dụ: 6 hoặc 7.5   (ít nhất {minimum:g} giây, 0 = quay lại)")
    while True:
        answer = ask(f"{label}: ").replace(",", ".")
        if answer == "0":
            return False
        try:
            value = float(answer)
        except ValueError:
            print("  Không phải số, ví dụ: 6 hoặc 7.5")
            continue
        if value < minimum or value > 3600:
            print(f"  Phải từ {minimum:g} đến 3600 giây.")
            continue
        opts["seconds"] = int(value) if value.is_integer() else value
        return True


def tool_title():
    title = "TẠO TRANG TIÊU ĐỀ"
    opts = ask_options(title, [
        {"key": "video", "title": "Xuất ra", "options": [
            ("Ảnh .png và video .mp4 (mờ dần vào/ra, để nối vào đầu video)", True),
            ("Chỉ ảnh .png", False)]},
        {"key": "seconds", "title": "Độ dài video", "when": lambda chosen: chosen["video"], "options": [
            ("4 giây", 4), ("3 giây", 3), ("5 giây", 5), ("8 giây", 8), ("Tự nhập số giây...", "custom")]},
        SIZES_STEP,
    ])
    if opts is None:
        return
    if not ask_seconds(title, opts):
        return
    if opts["sizes"] == "custom":
        opts["sizes"] = ask_sizes(title)
        if opts["sizes"] is None:
            return
    out_dir = output_dir()

    def build(files):
        taken, cmds = set(), []
        for txt in files:
            cmd = [PY, os.path.join(HERE, "make_title.py"), "-f", txt,
                   "-o", unique(os.path.join(out_dir, stem(txt) + ".png"), taken)]
            if opts["sizes"]:
                cmd += ["--sizes", opts["sizes"]]
            if opts["video"]:
                cmd += ["--video", "--seconds", str(opts["seconds"])]
            cmds.append(cmd)
        return cmds

    def pick():
        global last_dir
        if not any(f.lower().endswith(".txt") for f in os.listdir(last_dir)):
            last_dir = HERE  # start where title_example.txt is
        return dialog("Chọn file chữ của trang tiêu đề (.txt, xem title_example.txt)", TEXT)

    choose_and_run(title, pick, build, out_dir)


def tool_image():
    title = "TẠO ẢNH / VIDEO TỪ HÌNH"
    opts = ask_options(title, [
        {"key": "video", "title": "Xuất ra", "options": [
            ("Ảnh .png và video .mp4 (mờ dần vào/ra, để nối vào video)", True),
            ("Chỉ ảnh .png", False)]},
        {"key": "motion", "title": "Chuyển động của hình", "when": lambda chosen: chosen["video"], "options": [
            ("Đứng yên", "none"),
            ("Phóng to chậm (zoom)", "zoom"),
            ("Cuộn từ trên xuống (cho ảnh chụp dài)", "scroll")]},
        {"key": "seconds", "title": "Độ dài video", "when": lambda chosen: chosen["video"], "options": [
            ("5 giây", 5), ("4 giây", 4), ("6 giây", 6), ("8 giây", 8), ("10 giây", 10),
            ("Tự nhập số giây...", "custom")]},
        {"key": "layout", "title": "Chỗ đặt chữ (khi có file chữ)", "options": [
            ("Phía trên hình", "top"),
            ("Bên trái hình", "left")]},
        {"key": "bar", "title": "Khung hình", "options": [
            ("Khung cửa sổ có thanh tiêu đề (3 chấm)", True),
            ("Khung không có thanh tiêu đề", False)]},
        SIZES_STEP,
    ])
    if opts is None:
        return
    if not ask_seconds(title, opts):
        return
    if opts["sizes"] == "custom":
        opts["sizes"] = ask_sizes(title)
        if opts["sizes"] is None:
            return
    out_dir = output_dir()

    def pick():
        picture = dialog("1/2  Chọn hình", IMAGE, multiple=False)
        if not picture:
            return []
        txt = dialog("2/2  Chọn file chữ (.txt, như title_example.txt; Cancel = không có chữ)",
                     TEXT, multiple=False)
        return [tuple(picture + txt)]

    def build(sets):
        taken, cmds = set(), []
        for files in sets:
            cmd = [PY, os.path.join(HERE, "make_image.py"), files[0]]
            if len(files) > 1:
                cmd += ["-f", files[1], "--layout", opts["layout"]]
            cmd += ["-o", unique(os.path.join(out_dir, stem(files[0]) + "_slide.png"), taken)]
            if not opts["bar"]:
                cmd += ["--no-bar"]
            if opts["sizes"]:
                cmd += ["--sizes", opts["sizes"]]
            if opts["video"]:
                cmd += ["--video", "--seconds", str(opts["seconds"]), "--motion", opts["motion"]]
            cmds.append(cmd)
        return cmds

    choose_and_run(title, pick, build, out_dir)


def ask_pages(title):
    """Pages typed by the user, as "1-3,5"; "" for all, None for 0 (back)."""
    header(title)
    print("Trang cần lấy, ví dụ: 1-3,5   (Enter = tất cả các trang, 0 = quay lại)")
    while True:
        answer = ask("Trang: ").replace(" ", "")
        if answer == "0":
            return None
        if all(part and all(n.isdigit() for n in part.split("-", 1)) for part in answer.split(",")) or not answer:
            return answer
        print("  Không đúng dạng, ví dụ: 1-3,5")


def tool_word():
    title = "WORD → ẢNH FULL HD / VIDEO"
    opts = ask_options(title, [
        {"key": "video", "title": "Xuất ra", "options": [
            ("Ảnh .png (1920x1080) và video .mp4", True),
            ("Chỉ ảnh .png (1920x1080)", False)]},
        {"key": "mode", "title": "Cách hiện các trang", "options": [
            ("Từng trang: cả trang trong một ảnh, video chuyển mờ giữa các trang", "page"),
            ("Cuộn: trang rộng bằng khung (dễ đọc), video cuộn từ trên xuống", "scroll")]},
        {"key": "seconds", "title": "Thời gian cho mỗi trang", "when": lambda chosen: chosen["video"],
         "options": lambda chosen: [(f"{s} giây", s) for s in ((4, 3, 5, 6, 8) if chosen["mode"] == "page"
                                                                else (8, 5, 10, 12, 15))] + [("Tự nhập số giây...", "custom")]},
        {"key": "numbers", "title": "Số trang ở chân trang", "when": lambda chosen: chosen["mode"] == "page",
         "options": [("Có (ví dụ 2 / 16)", True), ("Không", False)]},
    ])
    if opts is None:
        return
    if not ask_seconds(title, opts, "Thời gian mỗi trang (giây)", 1):
        return
    pages = ask_pages(title)
    if pages is None:
        return
    out_dir = output_dir()

    def pick():
        doc = dialog("1/2  Chọn file Word (hoặc PDF)", WORD, multiple=False)
        if not doc:
            return []
        txt = dialog("2/2  Chọn file chữ đặt bên trái các trang (.txt; Cancel = không có chữ)",
                     TEXT, multiple=False)
        return [tuple(doc + txt)]

    def build(sets):
        taken, cmds = set(), []
        for files in sets:
            cmd = [PY, os.path.join(HERE, "make_word.py"), files[0], "--mode", opts["mode"],
                   "-o", unique(os.path.join(out_dir, stem(files[0])), taken)]
            if len(files) > 1:
                cmd += ["-f", files[1]]
            if pages:
                cmd += ["--pages", pages]
            if opts.get("numbers"):
                cmd += ["--page-numbers"]
            if opts["video"]:
                cmd += ["--video", "--seconds", str(opts["seconds"])]
            cmds.append(cmd)
        return cmds

    choose_and_run(title, pick, build, out_dir)


TOOLS = [
    ("Tạo trang tiêu đề", tool_title),
    ("Tạo ảnh / video từ hình", tool_image),
    ("Word → ảnh Full HD / video", tool_word),
    ("Nối video", tool_concat),
    ("Cắt bỏ các đoạn trong video", tool_cut),
    ("Tách video không tiếng + mp3", tool_split_audio),
    ("Tạo phụ đề từ video", tool_subtitles),
    ("Nối nhiều phụ đề thành 1 file", tool_concat_subs),
    ("Đọc phụ đề / xuất mp3", tool_read),
    ("Ghép video + file mp3 có sẵn + phụ đề", tool_merge),
    ("Video + Phụ đề → mp3 + video có giọng đọc và phụ đề (tự tạo mp3)", tool_dub),
    ("Video tiếng Việt → phụ đề Việt/Anh, mp3 và video tiếng Anh", tool_vi_to_en),
]


def main():
    sys.path.insert(0, HERE)
    while True:
        header("VIDEO TOOLS")
        for n, (name, _) in enumerate(TOOLS, 1):
            print(f"  {n}. {name}")
        print("  0. Thoát")
        answer = ask("Chọn: ")
        if answer == "0":
            return
        if answer.isdigit() and 1 <= int(answer) <= len(TOOLS):
            try:
                TOOLS[int(answer) - 1][1]()
            except KeyboardInterrupt:
                print("\nĐã dừng.")
                pause()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
