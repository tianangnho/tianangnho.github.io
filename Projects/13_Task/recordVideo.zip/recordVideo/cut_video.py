"""Cut parts out of a video and join what is left.

    python cut_video.py demo.mp4 "[10,15], [20,24]"             # writes demo_cut.mp4
    python cut_video.py demo.mp4 "[0:10-0:15] [1:20-1:31.5]" -o short.mp4
    python cut_video.py demo.mp4 "10-15 20-24 80-"               # 80- : from 80 s to the end
    python cut_video.py demo.mp4 "[10,15]" --srt demo.srt         # also writes demo_cut.srt
    python cut_video.py demo.mp4 "[10,15]" --dry-run              # show what is kept

Each part to remove is [start, end] or [start-end], or start-end without brackets;
a time is seconds (10, 10.5), m:ss (1:20) or h:mm:ss. An empty start is the
beginning of the video, an empty end its end ([-5] the first 5 s, [80-] from 80 s).
Parts that overlap are joined. The video is re-encoded, so that the cuts fall on
the exact frame. With --srt, the subtitles are cut the same way: the entries in a
removed part are left out, the others are moved earlier.
"""
import argparse
import os
import re
import subprocess
import sys

from concat_subtitles import format_time, parse_duration, read_srt
from concat_videos import probe
from merge_video_audio import find_ffmpeg


def parse_cuts(text, duration):
    """The parts to remove, [(start, end)] in seconds, sorted and joined; ValueError if wrong."""
    text = text.strip()
    if "[" in text:
        items = re.findall(r"\[([^\]]*)\]", text)
        if re.sub(r"\[[^\]]*\]", "", text).strip(" ,;\t"):
            raise ValueError("write each part as [start, end], e.g. [10,15], [20,24]")
    else:
        items = [t for t in re.split(r"[\s;]+", text) if t]
    cuts = []
    for item in items:
        pair = re.split(r"\s*[,\-–]\s*", item.strip())
        if len(pair) != 2:
            raise ValueError(f"[{item}]: give a start and an end, e.g. [10,15] or [1:20-1:31]")
        start = parse_duration(pair[0]) if pair[0] else 0.0
        end = parse_duration(pair[1]) if pair[1] else duration
        if end <= start:
            raise ValueError(f"[{item}]: the end ({end:g}s) must be after the start ({start:g}s)")
        if start >= duration:
            raise ValueError(f"[{item}]: starts after the end of the video ({duration:.1f}s)")
        cuts.append((start, min(end, duration)))
    if not cuts:
        raise ValueError("no part to remove given")
    cuts.sort()
    joined = [list(cuts[0])]
    for start, end in cuts[1:]:
        if start <= joined[-1][1]:
            joined[-1][1] = max(joined[-1][1], end)
        else:
            joined.append([start, end])
    return [tuple(c) for c in joined]


def kept_parts(cuts, duration):
    parts, at = [], 0.0
    for start, end in cuts:
        if start - at > 0.01:
            parts.append((at, start))
        at = end
    if duration - at > 0.01:
        parts.append((at, duration))
    return parts


def command(ffmpeg, video, parts, has_audio, output, args):
    graph, pairs = [], ""
    for n, (start, end) in enumerate(parts):
        graph.append(f"[0:v]trim=start={start:.3f}:end={end:.3f},setpts=PTS-STARTPTS[v{n}]")
        pairs += f"[v{n}]"
        if has_audio:
            graph.append(f"[0:a]atrim=start={start:.3f}:end={end:.3f},asetpts=PTS-STARTPTS[a{n}]")
            pairs += f"[a{n}]"
    graph.append(pairs + f"concat=n={len(parts)}:v=1:a={int(has_audio)}" + ("[v][a]" if has_audio else "[v]"))
    codec = {"h264": ["-c:v", "libx264"],
             "h265": ["-c:v", "libx265", "-tag:v", "hvc1", "-x265-params", "log-level=error"]}[args.codec]
    crf = args.crf if args.crf is not None else {"h264": 23, "h265": 28}[args.codec]
    cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-stats", "-y", "-i", video,
           "-filter_complex", ";".join(graph), "-map", "[v]"]
    if has_audio:
        cmd += ["-map", "[a]", "-c:a", "aac", "-b:a", args.audio_bitrate]
    return cmd + codec + ["-crf", str(crf), "-preset", args.preset, "-pix_fmt", "yuv420p",
                          "-movflags", "+faststart", output]


def cut_srt(src, dst, parts):
    """Writes the entries of src that are in the kept parts to dst, at their new times."""
    shift, at = [], 0.0
    for start, end in parts:  # new time = old time - shift of its part
        shift.append(start - at)
        at += end - start
    out = []
    for start, end, lines in read_srt(src):
        # the pieces of the entry that are kept, at their new times
        pieces = [(max(start, a) - d, min(end, b) - d) for (a, b), d in zip(parts, shift)
                  if min(end, b) - max(start, a) > 0.05]
        if not pieces:
            continue
        new_start, new_end = pieces[0][0], pieces[-1][1]
        out.append(f"{len(out) + 1}\n{format_time(new_start)} --> {format_time(new_end)}\n" + "\n".join(lines))
    with open(dst, "w", encoding="utf-8") as f:
        f.write("\n\n".join(out) + "\n")
    return len(out)


def main():
    summary, _, details = __doc__.partition("\n")
    ap = argparse.ArgumentParser(description=summary, epilog="examples:" + details,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video", help="the video")
    ap.add_argument("cuts", help='the parts to remove, e.g. "[10,15], [20,24]"')
    ap.add_argument("-o", "--output", help="the cut video; default <video>_cut.mp4")
    ap.add_argument("--srt", help="subtitles of the video, cut the same way into <output>.srt")
    ap.add_argument("--codec", choices=["h264", "h265"], default="h264", help="default h264")
    ap.add_argument("--crf", type=int, help="quality, higher is smaller: default 23 (h264) or 28 (h265)")
    ap.add_argument("--preset", default="medium", help="encoder preset; default medium")
    ap.add_argument("--audio-bitrate", default="128k", help="default 128k")
    ap.add_argument("--dry-run", action="store_true", help="show the parts kept, write nothing")
    args = ap.parse_args()

    for path in (args.video, args.srt):
        if path and not os.path.isfile(path):
            sys.exit(f"{path} does not exist")
    ffmpeg = find_ffmpeg(None)
    ffprobe = os.path.join(os.path.dirname(ffmpeg), "ffprobe" + (".exe" if os.name == "nt" else ""))
    info = probe(ffprobe if os.path.isfile(ffprobe) else "ffprobe", args.video)
    duration = info["duration"]
    try:
        cuts = parse_cuts(args.cuts, duration)
    except ValueError as e:
        sys.exit(str(e))
    parts = kept_parts(cuts, duration)
    if not parts:
        sys.exit("nothing would be left of the video")

    print(f"{os.path.basename(args.video)}: {format_time(duration)}")
    for start, end in cuts:
        print(f"  remove  {format_time(start)} - {format_time(end)}  ({end - start:.1f}s)")
    for start, end in parts:
        print(f"  keep    {format_time(start)} - {format_time(end)}  ({end - start:.1f}s)")
    left = sum(e - s for s, e in parts)
    print(f"  length: {format_time(duration)} -> {format_time(left)}  ({duration - left:.1f}s removed)")
    if args.dry_run:
        return

    output = os.path.abspath(args.output or os.path.splitext(args.video)[0] + "_cut.mp4")
    if output == os.path.abspath(args.video):
        sys.exit("the output must not be the video itself")
    os.makedirs(os.path.dirname(output), exist_ok=True)
    if subprocess.run(command(ffmpeg, args.video, parts, info["audio"] is not None, output, args)).returncode:
        sys.exit("ffmpeg failed")
    print(f"wrote {output}: {os.path.getsize(output) / 1024 / 1024:.1f} MB")
    if args.srt:
        srt = os.path.splitext(output)[0] + ".srt"
        print(f"wrote {srt}: {cut_srt(args.srt, srt, parts)} subtitles")


if __name__ == "__main__":
    main()
