"""Merge a screen recording (.mp4), a narration (.wav, .mp3) and subtitles (.srt) into one small .mp4.

    python merge_video_audio.py demo.mp4 demo_voice.wav demo_subtitles.srt -o demo_final.mp4
    python merge_video_audio.py demo.mp4 demo_voice.mp3 demo_subtitles.srt --subs burn
    python merge_video_audio.py demo.mp4 demo_voice.mp3 --copy-video   # only replace the sound: fast
    python merge_video_audio.py demo.mp4 demo_voice.wav demo_subtitles.srt --codec h264
    python merge_video_audio.py demo.mp4 demo_voice.wav demo_subtitles.srt --dry-run

The default settings make the file as small as possible for a screen recording:
H.265 (CRF 30, preset slow), 15 frames per second, 1280 pixels wide, mono AAC
at 48 kbit/s, and the subtitles as a track of the file, which the viewer turns
on or off. Use --codec h264 when the file must play on players without H.265,
and --subs burn to draw the subtitles into the picture.

The [ACTION: ...] and (...) lines of the subtitles are cues for the presenter;
they are left out unless --keep-cues is given. The narration replaces the sound
of the recording, unless --mix is given. --copy-video keeps the picture as it is
(no re-encoding, much faster); it cannot be used with --subs burn.

Needs ffmpeg: on PATH, given with --ffmpeg, or from the imageio-ffmpeg package.
"""
import argparse
import glob
import os
import re
import shutil
import subprocess
import sys
import tempfile


def find_ffmpeg(given):
    if given:
        return given
    on_path = shutil.which("ffmpeg")
    if on_path:
        return on_path
    # installed by winget, before the shell has the new PATH
    winget = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "WinGet")
    found = glob.glob(os.path.join(winget, "Links", "ffmpeg.exe")) + \
        glob.glob(os.path.join(winget, "Packages", "Gyan.FFmpeg*", "*", "bin", "ffmpeg.exe"))
    if found:
        return found[0]
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        sys.exit("ffmpeg not found: install it (winget install Gyan.FFmpeg, or pip install imageio-ffmpeg), "
                 "or give its path with --ffmpeg")


def clean_srt(src, dst, keep_cues):
    """Writes the entries of src to dst, renumbered, without the presenter cues."""
    with open(src, encoding="utf-8-sig") as f:
        blocks = re.split(r"\n\s*\n", f.read().strip())
    out = []
    for block in blocks:
        lines = block.strip().splitlines()
        if len(lines) < 3 or "-->" not in lines[1]:
            continue
        text = " ".join(l.strip() for l in lines[2:])
        if not keep_cues and (text.startswith("[ACTION") or (text.startswith("(") and text.endswith(")"))):
            continue
        out.append(f"{len(out) + 1}\n{lines[1]}\n" + "\n".join(lines[2:]))
    with open(dst, "w", encoding="utf-8") as f:
        f.write("\n\n".join(out) + "\n")
    return len(out)


def command(args, ffmpeg, subs):
    codec = {"h265": ["-c:v", "libx265", "-tag:v", "hvc1", "-x265-params", "log-level=error"],
             "h264": ["-c:v", "libx264", "-tune", "stillimage"]}[args.codec]
    crf = args.crf if args.crf is not None else {"h265": 30, "h264": 28}[args.codec]
    filters = []
    if args.fps:
        filters.append(f"fps={args.fps}")
    if args.width:
        filters.append(f"scale='min({args.width},iw)':-2:flags=lanczos")
    if args.subs == "burn":
        style = "FontName=Segoe UI,FontSize=18,Outline=1,Shadow=0,MarginV=20"
        filters.append(f"subtitles={os.path.basename(subs)}:force_style='{style}'")

    cmd = [ffmpeg, "-hide_banner", "-y", "-i", os.path.abspath(args.video), "-i", os.path.abspath(args.audio)]
    if args.subs == "soft":
        cmd += ["-i", os.path.basename(subs)]
    if args.mix:
        cmd += ["-filter_complex", "[0:a][1:a]amix=inputs=2:duration=longest[a]", "-map", "0:v", "-map", "[a]"]
    else:
        cmd += ["-map", "0:v", "-map", "1:a"]
    if args.subs == "soft":
        cmd += ["-map", "2:s", "-c:s", "mov_text", "-metadata:s:s:0", "language=eng"]
    if args.copy_video:
        cmd += ["-c:v", "copy"]
    else:
        if filters:
            cmd += ["-vf", ",".join(filters)]
        cmd += codec + ["-crf", str(crf), "-preset", args.preset, "-pix_fmt", "yuv420p"]
    cmd += ["-c:a", "aac", "-b:a", args.audio_bitrate, "-ac", "1"]
    if args.shortest:
        cmd += ["-shortest"]
    cmd += ["-movflags", "+faststart", os.path.abspath(args.output)]
    return cmd


def main():
    summary, _, details = __doc__.partition("\n")
    ap = argparse.ArgumentParser(description=summary, epilog="examples:" + details,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video", help="the screen recording, .mp4")
    ap.add_argument("audio", help="the narration, .wav or .mp3 (any sound file ffmpeg reads)")
    ap.add_argument("srt", nargs="?", help="the subtitles, .srt (optional)")
    ap.add_argument("-o", "--output", default="demo_final.mp4", help="the merged file; default demo_final.mp4")
    ap.add_argument("--subs", choices=["soft", "burn", "none"], default="soft",
                    help="soft: a subtitle track (default); burn: drawn into the picture; none: no subtitles")
    ap.add_argument("--codec", choices=["h265", "h264"], default="h265",
                    help="h265: smallest (default); h264: plays everywhere, a little larger")
    ap.add_argument("--crf", type=int, help="quality, higher is smaller: default 30 (h265) or 28 (h264)")
    ap.add_argument("--preset", default="slow", help="encoder preset; slower is smaller: default slow")
    ap.add_argument("--fps", type=int, default=15, help="frames per second; default 15, 0 keeps those of the video")
    ap.add_argument("--width", type=int, default=1280, help="maximum width in pixels; default 1280, 0 keeps it")
    ap.add_argument("--audio-bitrate", default="48k", help="bitrate of the mono narration; default 48k")
    ap.add_argument("--mix", action="store_true", help="mix the narration with the sound of the recording")
    ap.add_argument("--copy-video", action="store_true",
                    help="keep the picture as it is, only replace the sound (fast; not with --subs burn)")
    ap.add_argument("--shortest", action="store_true", help="end with the shorter of the video and the narration")
    ap.add_argument("--keep-cues", action="store_true", help="keep the [ACTION] and (...) lines in the subtitles")
    ap.add_argument("--ffmpeg", help="path of ffmpeg.exe")
    ap.add_argument("--dry-run", action="store_true", help="print the ffmpeg command, do not run it")
    args = ap.parse_args()

    for path in (args.video, args.audio, args.srt):
        if path and not os.path.exists(path):
            sys.exit(f"{path} does not exist")
    if args.subs != "none" and not args.srt:
        args.subs = "none"
    if args.copy_video and args.subs == "burn":
        sys.exit("--subs burn draws into the picture, which --copy-video keeps as it is: use one or the other")

    ffmpeg = "ffmpeg" if args.dry_run and not args.ffmpeg else find_ffmpeg(args.ffmpeg)
    with tempfile.TemporaryDirectory() as tmp:
        subs = os.path.join(tmp, "subtitles.srt")
        if args.subs != "none":
            n = clean_srt(args.srt, subs, args.keep_cues)
            print(f"subtitles: {n} entries" + ("" if args.keep_cues else ", without the presenter cues"))
        cmd = command(args, ffmpeg, subs)
        print(" ".join(f'"{c}"' if " " in c or "'" in c else c for c in cmd))
        if args.dry_run:
            return
        # the subtitles are given by name: ffmpeg runs in their folder, which avoids
        # escaping a Windows path in the subtitles filter
        result = subprocess.run(cmd, cwd=tmp)
        if result.returncode != 0:
            sys.exit(f"ffmpeg failed with exit code {result.returncode}")
    size = os.path.getsize(args.output)
    print(f"wrote {args.output}: {size / 1024 / 1024:.1f} MB")


if __name__ == "__main__":
    main()
