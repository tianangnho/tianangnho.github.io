@echo off
rem Menu of the video tools: see record_menu.py
rem
rem   record.cmd                                  mo menu
rem   record.cmd title FILE.txt                   tao trang tieu de, co chu mac dinh
rem   record.cmd title FILE.txt "36,150,52,38,44,30"
rem   record.cmd title FILE.txt "- 100 - - - -"   chi doi co tieu de
rem
rem 6 co chu: nhan, tieu de, phu de, code, chu thuong, chan trang
rem Mac dinh: 30, 128, 46, 34, 40, 28  ("-" = giu mac dinh o vi tri do)
title Video Tools
chcp 65001 >nul
if /i "%~1"=="title" goto title
python "%~dp0record_menu.py" %*
goto :eof

:title
if "%~2"=="" (
    echo Thieu file chu. Vi du: record.cmd title "%~dp0title_example.txt" "- 100 - - - -"
    exit /b 1
)
set "OUT=%~dp0Output\%~n2.png"
if "%~3"=="" (
    python "%~dp0make_title.py" -f "%~2" -o "%OUT%" --video
) else (
    python "%~dp0make_title.py" -f "%~2" -o "%OUT%" --video --sizes "%~3"
)
