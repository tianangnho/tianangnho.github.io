@echo off
rem Cai dat Video Tools tren may moi (Windows 10/11).
rem
rem   setup.cmd            cai Python, ffmpeg va cac goi Python can thiet
rem   setup.cmd /full      cai them argostranslate (dich phu de Viet <-> Anh, nang ~1-2 GB)
rem   setup.cmd /quiet     khong hoi, khong dung lai cuoi cung
rem
rem Can: Internet, winget (co san tren Windows 10 1809+ / Windows 11).
rem Ghi chu: make_word.py can Microsoft Word; read_subtitles.py dung giong doc cua Windows.
setlocal EnableExtensions
title Video Tools - Setup
chcp 65001 >nul
cd /d "%~dp0"

set "FULL="
set "QUIET="
for %%A in (%*) do (
    if /i "%%~A"=="/full"  set "FULL=1"
    if /i "%%~A"=="/quiet" set "QUIET=1"
)

echo ==================================================
echo   Video Tools - cai dat
echo   Thu muc: %~dp0
echo ==================================================
echo.

rem ---------- 1. winget ----------
where winget >nul 2>&1
if errorlevel 1 (
    set "HAVE_WINGET="
    echo [!] Khong tim thay winget. Neu thieu Python/ffmpeg, hay cai tay:
    echo     Python : https://www.python.org/downloads/  ^(tick "Add python.exe to PATH"^)
    echo     ffmpeg : https://www.gyan.dev/ffmpeg/builds/ ^(hoac pip se cai imageio-ffmpeg^)
    echo.
) else (
    set "HAVE_WINGET=1"
)

rem ---------- 2. Python ----------
echo [1/4] Kiem tra Python...
call :find_python
if not defined PY (
    if not defined HAVE_WINGET goto no_python
    echo     Chua co Python, dang cai Python 3.12 bang winget...
    winget install -e --id Python.Python.3.12 --scope user --accept-source-agreements --accept-package-agreements
    rem PATH cua cua so nay chua duoc cap nhat: tim python o thu muc cai dat
    if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
        set "PATH=%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python312\Scripts;%PATH%"
    )
    call :find_python
)
if not defined PY goto no_python
for /f "delims=" %%V in ('%PY% --version 2^>^&1') do echo     OK: %%V
echo.

rem ---------- 3. ffmpeg ----------
echo [2/4] Kiem tra ffmpeg...
where ffmpeg >nul 2>&1
if not errorlevel 1 (
    echo     OK: ffmpeg da co tren PATH
) else if defined HAVE_WINGET (
    echo     Chua co ffmpeg, dang cai Gyan.FFmpeg bang winget...
    winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
    if exist "%LOCALAPPDATA%\Microsoft\WinGet\Links\ffmpeg.exe" set "PATH=%LOCALAPPDATA%\Microsoft\WinGet\Links;%PATH%"
) else (
    echo     [!] Khong co ffmpeg; se dung ffmpeg cua goi imageio-ffmpeg ^(mot so chuc nang can ffmpeg tren PATH^).
)
echo.

rem ---------- 4. Goi Python ----------
echo [3/4] Cai cac goi Python...
%PY% -m pip install --upgrade pip
%PY% -m pip install --upgrade pillow pymupdf pywin32 imageio-ffmpeg faster-whisper
if errorlevel 1 (
    echo [X] pip install loi. Xem thong bao o tren.
    goto fail
)

if not defined FULL if not defined QUIET (
    echo.
    set /p "ANS=Cai them argostranslate de dich phu de Viet-Anh? [nang, ~1-2 GB] [y/N]: "
)
if /i "%ANS%"=="y" set "FULL=1"
if defined FULL (
    %PY% -m pip install --upgrade argostranslate
    if errorlevel 1 echo [!] Cai argostranslate loi; cac chuc nang khac van dung duoc.
)
echo.

rem ---------- 5. Thu muc va kiem tra ----------
echo [4/4] Kiem tra...
if not exist "%~dp0Output" mkdir "%~dp0Output"
%PY% -c "import PIL, pymupdf, win32com.client, imageio_ffmpeg, faster_whisper; print('    OK: cac goi Python da san sang')"
if errorlevel 1 goto fail
%PY% -c "import sys; sys.path.insert(0, r'%~dp0.'); from merge_video_audio import find_ffmpeg; print('    ffmpeg:', find_ffmpeg(None))"

echo.
echo ==================================================
echo   Xong! Chay tool bang:  record.cmd
echo   (Mo cua so CMD moi neu vua cai Python/ffmpeg de PATH duoc cap nhat.)
echo   Lan dau tao phu de, model Whisper se duoc tai ve (75 MB - 3 GB).
echo ==================================================
if not defined QUIET pause
exit /b 0

:no_python
echo [X] Khong tim thay Python. Cai Python 3.10+ tu https://www.python.org/downloads/
echo     ^(tick "Add python.exe to PATH"^), mo lai CMD roi chay lai setup.cmd.
goto fail

:fail
echo.
echo Cai dat CHUA hoan tat.
if not defined QUIET pause
exit /b 1

rem Tim lenh python that (bo qua ban gia "App execution alias" cua Microsoft Store)
:find_python
set "PY="
python -c "import sys" >nul 2>&1 && set "PY=python" && goto :eof
py -3 -c "import sys" >nul 2>&1 && set "PY=py -3" && goto :eof
goto :eof
