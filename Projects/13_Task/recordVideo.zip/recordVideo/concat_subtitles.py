"""Join several subtitle files (.srt) into one, for the video made by joining their videos.

    python concat_subtitles.py p0.srt p1.srt p2.srt --durations "1:25 2:03.5" -o all.srt
    python concat_subtitles.py p0.srt p1.srt p2.srt            # durations from p0.mp4, p1.mp4...
    python concat_subtitles.py p*.srt --sort name --durations "85 123.5 60"
    python concat_subtitles.py p0.srt p1.srt --gap 4 --durations 85   # a 4 s title page between them

The entries of each file are moved later by the length of the parts before it,
then all are numbered again. --durations gives the length of each part, in
order, separated by spaces, commas or ';': seconds (85, 85.5), m:ss (1:25) or
h:mm:ss (1:01:25). The last part needs no length. A part without a length takes
that of the video of the same name next to its .srt (p0.mp4 for p0.srt), found
with ffprobe; when there is none, the end of its last subtitle.
--gap adds seconds between parts (e.g. a title page put in between).
"""
import argparse
import glob
import os
import re
import subprocess
import sys

TIME = re.compile(r"(\d+):(\d+):(\d+)[,.](\d+)")
VIDEO_EXTS = (".mp4", ".mkv", ".mov", ".avi", ".webm", ".m4v", ".wmv")


def parse_time(text):
    h, m, s, ms = TIME.match(text.strip()).groups()
    return int(h) * 3600 + int(m) * 60 + int(s) + int(ms.ljust(3, "0")[:3]) / 1000


def format_time(seconds):
    ms = max(0, round(seconds * 1000))
    return f"{ms // 3600000:02}:{ms // 60000 % 60:02}:{ms // 1000 % 60:02},{ms % 1000:03}"


def read_srt(path):
    """The entries of the file: (start, end, [lines of text])."""
    raw = open(path, "rb").read()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("mbcs" if os.name == "nt" else "latin-1")
    entries = []
    for block in re.split(r"\n\s*\n", text.replace("\r\n", "\n").strip()):
        lines = block.strip().splitlines()
        at = next((i for i, l in enumerate(lines) if "-->" in l), None)
        if at is None:
            continue
        start, end = lines[at].split("-->")
        try:
            entries.append((parse_time(start), parse_time(end), lines[at + 1:]))
        except AttributeError:
            sys.exit(f"{path}: bad time line {lines[at]!r}")
    return entries


def parse_duration(text):
    """Seconds of "85", "85.5", "1:25", "1:01:25.5"."""
    parts = text.strip().split(":")
    if len(parts) > 3 or not all(re.fullmatch(r"\d+(\.\d+)?", p) for p in parts):
        raise ValueError(f"not a length: {text!r} (e.g. 85, 85.5, 1:25 or 1:01:25)")
    seconds = 0.0
    for p in parts:
        seconds = seconds * 60 + float(p)
    return seconds


def parse_durations(text):
    return [parse_duration(t) for t in re.split(r"[\s,;]+", text.strip()) if t]


def video_duration(srt):
    """Length of the video of the same name next to srt, or None."""
    stem = os.path.splitext(srt)[0]
    video = next((stem + e for e in VIDEO_EXTS if os.path.isfile(stem + e)), None)
    if not video:
        return None
    try:
        from merge_video_audio import find_ffmpeg
        ffmpeg = find_ffmpeg(None)
        ffprobe = os.path.join(os.path.dirname(ffmpeg), "ffprobe" + (".exe" if os.name == "nt" else ""))
        if not os.path.isfile(ffprobe):
            ffprobe = "ffprobe"
        out = subprocess.run([ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", video],
                             capture_output=True, text=True)
        return float(out.stdout.strip()), os.path.basename(video)
    except (ValueError, OSError, SystemExit):
        return None


def natural_key(path):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", os.path.basename(path))]


def main():
    summary, _, details = __doc__.partition("\n")
    ap = argparse.ArgumentParser(description=summary, epilog="examples:" + details,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("srt", nargs="+", help="the subtitle files, in the order of the videos")
    ap.add_argument("-o", "--output", default="merged.srt", help="the joined file; default merged.srt")
    ap.add_argument("--durations", default="", help='length of each part, e.g. "1:25 2:03.5 60"')
    ap.add_argument("--gap", type=float, default=0, help="seconds added between two parts; default 0")
    ap.add_argument("--sort", choices=["none", "name"], default="none",
                    help="none: the order given (default); name: by name, p2 before p10")
    args = ap.parse_args()

    files = []
    for item in args.srt:  # the shell of Windows does not expand p*.srt
        found = sorted(glob.glob(item)) if any(c in item for c in "*?") else [item]
        files += found or [item]
    missing = [f for f in files if not os.path.isfile(f)]
    if missing:
        sys.exit("not found:\n  " + "\n  ".join(missing))
    if args.sort == "name":
        files.sort(key=natural_key)
    try:
        durations = parse_durations(args.durations)
    except ValueError as e:
        sys.exit(str(e))
    if len(durations) > len(files):
        sys.exit(f"{len(durations)} lengths for {len(files)} files")

    out, offset = [], 0.0
    print("part  starts at     length       file")
    for n, path in enumerate(files):
        entries = read_srt(path)
        last = n == len(files) - 1
        if n < len(durations):
            length, source = durations[n], "given"
        elif last:
            length, source = None, ""
        else:
            found = video_duration(path)
            if found:
                length, source = found[0], f"from {found[1]}"
            else:
                length, source = (max((e[1] for e in entries), default=0), "end of its last subtitle")
        shown = f"{length:.1f}s" if length is not None else "-"
        print(f"{n + 1:4}  {format_time(offset)}  {shown:11}  {os.path.basename(path)}  "
              f"({len(entries)} entries{', length ' + source if source else ''})")
        for start, end, lines in entries:
            if length is not None and start >= length:
                print(f"      warning: an entry at {format_time(start)} is after the end of this part")
            out.append(f"{len(out) + 1}\n{format_time(start + offset)} --> {format_time(end + offset)}\n"
                       + "\n".join(lines))
        if length is not None:
            offset += length + args.gap

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        f.write("\n\n".join(out) + "\n")
    print(f"wrote {args.output}: {len(out)} entries")


if __name__ == "__main__":
    main()
