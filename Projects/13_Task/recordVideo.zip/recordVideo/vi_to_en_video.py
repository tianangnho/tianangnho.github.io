"""From a video spoken in Vietnamese, make its English version.

    python vi_to_en_video.py demo.mp4                          # into the folder of the video
    python vi_to_en_video.py demo.mp4 --out-dir Output --voice Zira --rate 1
    python vi_to_en_video.py demo.mp4 --model medium --translator whisper
    python vi_to_en_video.py demo.mp4 --subs soft --codec h264

Writes, with the name of the video:
    demo_silent.mp4   the video without its sound
    demo.vi.srt       the Vietnamese subtitles (Whisper)
    demo.en.srt       the English subtitles
    demo.en.mp3       the English subtitles read by a voice of Windows, at their times
    demo_en.mp4       the video with the English voice and the English subtitles drawn on it

Translation: argos (default) writes the speech down once and translates each
sentence, offline, so that both subtitle files have the same times; whisper
transcribes a second time and lets Whisper translate (better with --model medium
or larger, slower). Check and correct demo.en.srt if needed, then make the mp3 and
the video again with: python dub_video.py demo_silent.mp4 demo.en.srt --subs burn
"""
import argparse
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def step(n, text):
    print(f"\n{'=' * 60}\n {n}/4  {text}\n{'=' * 60}", flush=True)


def run(cmd, what):
    if subprocess.run(cmd).returncode != 0:
        sys.exit(f"failed: {what}")


def main():
    summary, _, details = __doc__.partition("\n")
    ap = argparse.ArgumentParser(description=summary, epilog="examples:" + details,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video", help="the video spoken in Vietnamese")
    ap.add_argument("--out-dir", help="folder of the files; default: that of the video")
    ap.add_argument("--model", default="small", help="Whisper model: base, small (default), medium, large-v3-turbo")
    ap.add_argument("--translator", choices=["argos", "whisper"], default="argos",
                    help="argos: one transcription, same times (default); whisper: a second pass")
    ap.add_argument("--prompt", help="words the speaker uses (product names), so that they are written correctly")
    ap.add_argument("--voice", help="number or part of the name of the English voice; default: choose from a list")
    ap.add_argument("--rate", type=int, default=0, help="speed of the voice, -10 to 10; default 0")
    ap.add_argument("--subs", choices=["burn", "soft"], default="burn",
                    help="burn: drawn on the picture (default); soft: a track the viewer turns on")
    ap.add_argument("--codec", choices=["h265", "h264"], default="h264",
                    help="of the English video: h264 plays everywhere (default), h265 is smaller")
    args = ap.parse_args()

    if not os.path.isfile(args.video):
        sys.exit(f"{args.video} does not exist")
    from merge_video_audio import find_ffmpeg
    ffmpeg = find_ffmpeg(None)
    out_dir = os.path.abspath(args.out_dir or os.path.dirname(os.path.abspath(args.video)))
    os.makedirs(out_dir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(args.video))[0]
    path = lambda suffix: os.path.join(out_dir, stem + suffix)
    silent, vi_srt, en_srt, en_mp3, en_video = (path("_silent.mp4"), path(".vi.srt"), path(".en.srt"),
                                                path(".en.mp3"), path("_en.mp4"))

    step(1, f"video without sound -> {silent}")
    run([ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", args.video,
         "-map", "0:v", "-c:v", "copy", "-an", "-sn", "-movflags", "+faststart", silent], "the video without sound")

    step(2, "Vietnamese and English subtitles")
    subs = [sys.executable, os.path.join(HERE, "make_subtitles.py"), args.video, "--model", args.model,
            "--language", "vi", "--out-dir", out_dir]
    if args.prompt:
        subs += ["--prompt", args.prompt]
    if args.translator == "argos":
        # one transcription: demo.en.srt and, with --also-original, demo.vi.srt
        run(subs + ["--to", "en", "--translator", "argos", "--also-original", "-o", en_srt], "the subtitles")
    else:
        run(subs + ["-o", vi_srt], "the Vietnamese subtitles")
        run(subs + ["--to", "en", "--translator", "whisper", "-o", en_srt], "the English subtitles")
    for f in (vi_srt, en_srt):
        if not os.path.isfile(f):
            sys.exit(f"{f} was not written (no speech found?)")

    step(3, f"English voice -> {en_mp3}")
    voice = args.voice
    if voice is None:
        voice = "English"  # the first English voice, unless the user chooses one
        try:
            if sys.stdin.isatty():
                voice = None
        except (AttributeError, ValueError):
            pass
    read = [sys.executable, os.path.join(HERE, "read_subtitles.py"), en_srt, "--save", en_mp3, "--timed",
            f"--rate={args.rate}"]
    if voice:
        read += ["--voice", voice]
    run(read, "the English voice")

    step(4, f"English video -> {en_video}")
    run([sys.executable, os.path.join(HERE, "merge_video_audio.py"), silent, en_mp3, en_srt,
         "--subs", args.subs, "--codec", args.codec, "-o", en_video], "the English video")

    print("\ndone:")
    for f in (silent, vi_srt, en_srt, en_mp3, en_video):
        print(f"  {f}")


if __name__ == "__main__":
    main()
