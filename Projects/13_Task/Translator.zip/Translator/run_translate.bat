@echo off
cd /d "%~dp0"
start "" "C:\Users\a5090173\AppData\Local\Programs\Python\Python312\pythonw.exe" live_translate.py
