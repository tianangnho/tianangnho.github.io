"""Makes sure every model the app needs is inside models/ (so the folder can be copied).

For each model: already in models/ -> copy from this machine's cache -> download.
    python setup_models.py          Whisper 'small' + Vosk + Piper voices + Argos en<->vi
    python setup_models.py --all    also Whisper 'tiny' and 'base'
"""
import io
import os
import shutil
import sys
import zipfile

os.environ.setdefault("ARGOS_CHUNK_TYPE", "MINISBD")
try:
    import truststore  # corporate SSL proxies: trust the Windows certificate store
    truststore.inject_into_ssl()
except ImportError:
    pass

import requests

APP_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS = os.path.join(APP_DIR, "models")
HF_HUB = os.path.join(os.path.expanduser("~"), ".cache", "huggingface", "hub")

VOSK = "vosk-model-small-en-us-0.15"
VOSK_URL = f"https://alphacephei.com/vosk/models/{VOSK}.zip"
PIPER_URL = "https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/en/en_GB"
PIPER_VOICES = ["alan", "northern_english_male", "jenny_dioco", "cori"]
ARGOS_PAIRS = [("en", "vi"), ("vi", "en")]

failed = []


def step(title):
    print(f"\n[{title}]", flush=True)


def download(url, dest=None):
    print(f"  tai {url}", flush=True)
    r = requests.get(url, timeout=600)
    r.raise_for_status()
    if dest:
        with open(dest, "wb") as f:
            f.write(r.content)
    return r.content


def whisper(name):
    target = os.path.join(MODELS, "whisper", name)
    if os.path.isfile(os.path.join(target, "model.bin")):
        print(f"  whisper {name}: co san")
        return
    snapshots = os.path.join(HF_HUB, f"models--Systran--faster-whisper-{name}", "snapshots")
    if os.path.isdir(snapshots) and os.listdir(snapshots):
        src = os.path.join(snapshots, os.listdir(snapshots)[0])
        shutil.copytree(src, target, dirs_exist_ok=True)  # follows HF cache symlinks
        print(f"  whisper {name}: chep tu cache cua may nay")
        return
    from huggingface_hub import snapshot_download
    snapshot_download(f"Systran/faster-whisper-{name}", local_dir=target)
    print(f"  whisper {name}: da tai")


def vosk():
    if os.path.isdir(os.path.join(MODELS, VOSK)):
        print("  vosk: co san")
        return
    zipfile.ZipFile(io.BytesIO(download(VOSK_URL))).extractall(MODELS)
    print("  vosk: da tai")


def piper():
    d = os.path.join(MODELS, "piper")
    os.makedirs(d, exist_ok=True)
    for name in PIPER_VOICES:
        stem = f"en_GB-{name}-medium"
        for ext in (".onnx", ".onnx.json"):
            path = os.path.join(d, stem + ext)
            if not os.path.exists(path):
                download(f"{PIPER_URL}/{name}/medium/{stem}{ext}", path)
        print(f"  piper {name}: ok")


def _zip_package(pkg_dir, dest):
    """Repack an installed Argos package (a folder) as a .argosmodel zip."""
    root = os.path.basename(pkg_dir)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for folder, _, files in os.walk(pkg_dir):
            for f in files:
                full = os.path.join(folder, f)
                z.write(full, os.path.join(root, os.path.relpath(full, pkg_dir)))


def argos():
    import argostranslate.package as pkg
    d = os.path.join(MODELS, "argos")
    os.makedirs(d, exist_ok=True)
    installed = {(p.from_code, p.to_code): p for p in pkg.get_installed_packages()}
    index = None
    for src, tgt in ARGOS_PAIRS:
        bundled = os.path.join(d, f"translate-{src}_{tgt}.argosmodel")
        if (src, tgt) in installed:
            if not os.path.exists(bundled):
                _zip_package(str(installed[(src, tgt)].package_path), bundled)
                print(f"  argos {src}->{tgt}: dong goi vao models/argos")
            else:
                print(f"  argos {src}->{tgt}: co san")
            continue
        if not os.path.exists(bundled):
            if index is None:
                pkg.update_package_index()
                index = pkg.get_available_packages()
            match = next(p for p in index if p.from_code == src and p.to_code == tgt)
            shutil.copy(match.download(), bundled)
        pkg.install_from_path(bundled)
        print(f"  argos {src}->{tgt}: da cai")


def run(title, fn, *args):
    try:
        fn(*args)
    except Exception as e:
        print(f"  LOI {title}: {e}")
        failed.append(title)


def main():
    os.makedirs(MODELS, exist_ok=True)
    step("Whisper - nhan dang giong noi")
    for name in (["tiny", "base", "small"] if "--all" in sys.argv else ["small"]):
        run(f"whisper {name}", whisper, name)
    step("Vosk - live caption")
    run("vosk", vosk)
    step("Piper - giong doc UK")
    run("piper", piper)
    step("Argos - dich offline")
    run("argos", argos)
    if failed:
        print(f"\nCHUA XONG: {', '.join(failed)}. Kiem tra mang roi chay lai setup.")
        sys.exit(1)
    print("\nModel: day du.")


if __name__ == "__main__":
    main()
