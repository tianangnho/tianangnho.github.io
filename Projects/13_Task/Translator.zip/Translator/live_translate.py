import os
import sys
import json
import queue
import threading
import time
import datetime
import traceback
from xml.sax.saxutils import escape


def _redirect_output_when_windowless():
    # pythonw has no console (sys.stderr is None): send warnings and tracebacks to a file.
    if sys.stderr is not None:
        return
    log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
    os.makedirs(log_dir, exist_ok=True)
    path = os.path.join(log_dir, "error.txt")
    if os.path.exists(path) and os.path.getsize(path) > 1_000_000:
        os.remove(path)
    f = open(path, "a", encoding="utf-8", buffering=1)
    f.write(f"\n=== {datetime.datetime.now():%Y-%m-%d %H:%M:%S} ===\n")
    sys.stdout = sys.stderr = f


_redirect_output_when_windowless()

# Argos' default sentence splitter downloads a model at runtime; MINISBD works offline.
os.environ.setdefault("ARGOS_CHUNK_TYPE", "MINISBD")
os.environ.setdefault("HF_HUB_OFFLINE", "1")

try:
    import truststore  # use the Windows cert store (corporate SSL proxy)
    truststore.inject_into_ssl()
except ImportError:
    pass

import numpy as np
import sounddevice as sd
import tkinter as tk
from tkinter import ttk, messagebox

SR = 16000
CHUNK_SEC = 0.05
APP_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(APP_DIR, "logs")
SETTINGS_FILE = os.path.join(APP_DIR, "settings.json")
VOSK_DIR = os.path.join(APP_DIR, "models", "vosk-model-small-en-us-0.15")
PIPER_DIR = os.path.join(APP_DIR, "models", "piper")
WHISPER_DIR = os.path.join(APP_DIR, "models", "whisper")
PIPER_PREFIX = "Piper · "
PIPER_NAMES = {"alan": "Alan (UK, nam)", "northern_english_male": "Northern English (UK, nam)",
               "jenny_dioco": "Jenny (UK, nữ)", "cori": "Cori (UK, nữ)"}

FONT = "Segoe UI"
BG = "#16181d"
PANEL = "#22252c"
FG_VI = "#f2f2f2"
FG_EN = "#8c93a3"
FG_TIME = "#5d7fbf"
FG_PARTIAL = "#e8cf7a"
LIVE_BG = "#0b0c0f"
SPEAKER_COLORS = {"Bạn": "#6fcf7f", "Người khác": "#6fa8ff", "Bạn (máy đọc)": "#c792ea"}
COMPOSE_KEY = "compose"

ENGINES = ["Argos (offline)", "Google (online)"]
MODELS = ["tiny", "base", "small"]
NO_MIC = "Không dùng"
ME, OTHERS = "Bạn", "Người khác"

LOOPBACK_DEFAULT = ("loop", None)

_model_lock = threading.Lock()
_whisper_lock = threading.Lock()  # one transcription at a time across all sources
_whisper_cache = {}
_vosk_model = [None]


def _whisper_local_dir(name):
    path = os.path.join(WHISPER_DIR, name)
    return path if os.path.isfile(os.path.join(path, "model.bin")) else None


def available_whisper_models():
    """Models bundled in models/whisper or already in the HuggingFace cache."""
    hub = os.path.join(os.path.expanduser("~"), ".cache", "huggingface", "hub")
    return [m for m in MODELS if _whisper_local_dir(m) or
            os.path.isdir(os.path.join(hub, f"models--Systran--faster-whisper-{m}"))]


def get_whisper(name):
    with _model_lock:
        if name not in _whisper_cache:
            from faster_whisper import WhisperModel
            model = WhisperModel(_whisper_local_dir(name) or name, device="cpu",
                                 compute_type="int8", local_files_only=True)
            list(model.transcribe(np.zeros(SR, dtype=np.float32), language="en")[0])  # warm-up
            _whisper_cache[name] = model
        return _whisper_cache[name]


def get_vosk():
    with _model_lock:
        if _vosk_model[0] is None and os.path.isdir(VOSK_DIR):
            import vosk
            vosk.SetLogLevel(-1)
            _vosk_model[0] = vosk.Model(VOSK_DIR)
        return _vosk_model[0]


def list_input_devices():
    """Returns [(source, label)]; source is ("loop", output_name|None) or ("sd", index)."""
    out = []
    try:
        import pyaudiowpatch as pa
        p = pa.PyAudio()
        try:
            out.append((LOOPBACK_DEFAULT, "🔊 Âm thanh đang phát trên máy (loa/tai nghe mặc định)"))
            for lb in p.get_loopback_device_info_generator():
                name = lb["name"].replace(" [Loopback]", "")
                out.append((("loop", name), f"🔊 {name}  [Loopback]"))
        finally:
            p.terminate()
    except Exception:
        pass
    apis = sd.query_hostapis()
    for i, d in enumerate(sd.query_devices()):
        if d["max_input_channels"] <= 0:
            continue
        api = apis[d["hostapi"]]["name"].replace("Windows ", "")
        if api == "WDM-KS":
            continue
        out.append((("sd", i), f"🎤 {d['name']}  [{api}]"))
    return out


def is_real_mic(label):
    return label.startswith("🎤") and not any(
        k in label for k in ("Stereo Mix", "Sound Mapper", "Primary Sound"))


def to_16k(x, rate):
    if rate == SR:
        return x.astype(np.float32)
    if rate % SR == 0:
        k = rate // SR
        n = len(x) // k * k
        return x[:n].reshape(-1, k).mean(axis=1).astype(np.float32)
    n = int(round(len(x) * SR / rate))
    return np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype(np.float32)


class Recognizer(threading.Thread):
    """Captures one audio source. Vosk streams the live line; Whisper transcribes each
    finished sentence in a separate worker so the live line never stalls.
    Emits ('partial'|'final', speaker, text) to out_q."""

    def __init__(self, source, model_name, out_q, speaker=None, live_partial=True):
        super().__init__(daemon=True)
        self.source = source
        self.model_name = model_name
        self.out = out_q
        self.speaker = speaker
        self.live_partial = live_partial
        self.audio_q = queue.Queue()
        self.final_q = queue.Queue()
        self.stop_evt = threading.Event()
        self.model = None
        self.vosk = None

        self.silence_end = 0.7
        self.max_seg = 12.0
        self.preroll_chunks = int(0.3 / CHUNK_SEC)
        self._reset()
        self.noise = 0.002
        self.prompt = ""
        self.last_partial_at = 0.0
        self.partial_cost = 0.0
        self.vosk_done = ""
        self.last_live = ""
        self.seg_id = 0
        self.seg_heard = False
        self.muted = False  # set while the app itself is speaking, so it doesn't hear itself

    def _reset(self):
        self.buf = []
        self.buf_len = 0
        self.speech = 0.0
        self.silence = 0.0

    def _tag(self, text):
        return f"[{self.speaker}] {text}" if self.speaker else text

    def load_models(self):
        self.model = get_whisper(self.model_name)
        vm = get_vosk()
        if vm is not None:
            import vosk
            self.vosk = vosk.KaldiRecognizer(vm, SR)

    def _open_stream(self):
        """Returns (rate, device_name, close_fn) with the stream already running."""
        if self.source[0] == "loop":
            return self._open_loopback(self.source[1])
        return self._open_sd(self.source[1])

    def _open_loopback(self, output_name):
        import pyaudiowpatch as pa
        p = pa.PyAudio()
        try:
            if output_name is None:
                wasapi = p.get_host_api_info_by_type(pa.paWASAPI)
                output_name = p.get_device_info_by_index(wasapi["defaultOutputDevice"])["name"]
            dev = next((lb for lb in p.get_loopback_device_info_generator()
                        if lb["name"].startswith(output_name)), None)
            if dev is None:
                raise RuntimeError(f"Không tìm thấy loopback cho '{output_name}'")
            rate = int(dev["defaultSampleRate"])
            ch = dev["maxInputChannels"]

            def callback(data, frames, t, status):
                self.audio_q.put(np.frombuffer(data, dtype=np.float32).reshape(-1, ch).mean(axis=1))
                return (None, pa.paContinue)

            stream = p.open(format=pa.paFloat32, channels=ch, rate=rate, input=True,
                            input_device_index=dev["index"],
                            frames_per_buffer=int(rate * CHUNK_SEC), stream_callback=callback)
        except Exception:
            p.terminate()
            raise

        def close():
            stream.stop_stream()
            stream.close()
            p.terminate()
        return rate, dev["name"], close

    def _open_sd(self, device):
        # Same physical device on other host APIs, used as fallback (Realtek WASAPI is flaky).
        name = sd.query_devices(device)["name"][:20]
        candidates = [device] + [i for i, d in enumerate(sd.query_devices())
                                 if i != device and d["max_input_channels"] > 0
                                 and d["name"].startswith(name)]
        last_err = None
        for dev in candidates:
            info = sd.query_devices(dev)
            rate = int(info["default_samplerate"])
            max_ch = info["max_input_channels"]
            for ch in dict.fromkeys([min(2, max_ch), max_ch]):
                stream = None
                try:
                    stream = sd.InputStream(device=dev, samplerate=rate, channels=ch,
                                            dtype="float32", blocksize=int(rate * CHUNK_SEC),
                                            callback=self._callback)
                    stream.start()
                    return rate, info["name"], stream.close
                except Exception as e:
                    last_err = e
                    if stream is not None:
                        stream.close()
        raise last_err

    def _callback(self, indata, frames, t, status):
        self.audio_q.put(indata.mean(axis=1).copy())

    def run(self):
        try:
            self.out.put(("status", self._tag(f"Đang nạp model Whisper '{self.model_name}'...")))
            self.load_models()
            rate, dev_name, close = self._open_stream()
        except Exception as e:
            self.out.put(("error", self._tag(f"Không khởi động được: {e}")))
            return
        worker = threading.Thread(target=self._final_loop, daemon=True)
        worker.start()
        live = "Vosk (nhanh)" if self.vosk else "Whisper"
        try:
            self.out.put(("status", self._tag(f"Đang nghe: {dev_name}  ·  live: {live}")))
            while not self.stop_evt.is_set():
                try:
                    chunks = [self.audio_q.get(timeout=0.2)]
                except queue.Empty:
                    # Loopback delivers nothing while playback is silent; feed silence so
                    # the current sentence still gets finalized.
                    if self.speech > 0:
                        self.handle(np.zeros(int(SR * 0.2), dtype=np.float32))
                    continue
                while True:
                    try:
                        chunks.append(self.audio_q.get_nowait())
                    except queue.Empty:
                        break
                x = to_16k(np.concatenate(chunks), rate)
                self.handle(np.zeros_like(x) if self.muted else x)
        finally:
            close()
        self.flush()
        self.final_q.put(None)
        worker.join()
        self.out.put(("status", self._tag("Đã dừng.")))

    def handle(self, x):
        step = int(SR * CHUNK_SEC)
        for i in range(0, len(x), step):
            self._feed(x[i:i + step])
        if self.vosk is None:
            self._maybe_whisper_partial()

    def _feed(self, c):
        if len(c) == 0:
            return
        dur = len(c) / SR
        rms = float(np.sqrt(np.mean(c * c)))
        thr = max(0.004, self.noise * 3.0)
        if rms > thr:
            self.speech += dur
            self.silence = 0.0
        else:
            self.noise = 0.97 * self.noise + 0.03 * rms
            self.silence += dur
        self.out.put(("level", self.speaker, min(1.0, rms / 0.1)))

        self.buf.append(c)
        self.buf_len += len(c)
        if self.vosk is not None:
            self._vosk_feed(c)

        if self.speech == 0.0:
            if len(self.buf) > self.preroll_chunks:
                drop = self.buf[:-self.preroll_chunks]
                self.buf = self.buf[-self.preroll_chunks:]
                self.buf_len -= sum(len(d) for d in drop)
            return

        total = self.buf_len / SR
        if self.silence >= self.silence_end or total >= self.max_seg:
            if self.speech >= 0.3:
                self._finalize()
            else:
                self._reset()

    def _vosk_feed(self, c):
        pcm = (np.clip(c, -1.0, 1.0) * 32767).astype(np.int16).tobytes()
        if self.vosk.AcceptWaveform(pcm):
            said = json.loads(self.vosk.Result()).get("text", "")
            if said:
                self.vosk_done = f"{self.vosk_done} {said}".strip()
            part = ""
        else:
            part = json.loads(self.vosk.PartialResult()).get("partial", "")
        text = f"{self.vosk_done} {part}".strip()
        # Only count words while the energy detector agrees someone is speaking (Vosk
        # tends to hallucinate short words like "the" on background noise).
        if text and self.speech > 0:
            self.seg_heard = True
            if self.live_partial and text != self.last_live:
                self.last_live = text
                self.out.put(("partial", self.speaker, self.seg_id, text))

    def _finalize(self):
        # Skip Whisper for segments Vosk heard no words in (mic noise would otherwise
        # keep Whisper busy and delay real sentences).
        if self.vosk is None or self.seg_heard:
            self.final_q.put((self.seg_id, np.concatenate(self.buf)))
        self._reset()
        if self.vosk is not None:
            self.vosk.Reset()
        self.vosk_done = ""
        self.last_live = ""
        self.seg_heard = False
        self.seg_id += 1

    def flush(self):
        if self.buf and self.speech >= 0.3:
            self._finalize()

    def _final_loop(self):
        while True:
            item = self.final_q.get()
            if item is None:
                return
            seg_id, audio = item
            text = self.transcribe(audio, final=True)
            if text:
                self.prompt = text[-200:]
                self.out.put(("final", self.speaker, seg_id, text))

    def _maybe_whisper_partial(self):
        if not self.live_partial or self.speech < 0.5:
            return
        now = time.time()
        if now - self.last_partial_at < min(2.0, max(0.6, self.partial_cost * 1.3)):
            return
        t0 = time.time()
        text = self.transcribe(np.concatenate(self.buf), final=False)
        self.partial_cost = time.time() - t0
        self.last_partial_at = time.time()
        if self.speech > 0 and text:
            self.out.put(("partial", self.speaker, self.seg_id, text))

    def transcribe(self, audio, final):
        with _whisper_lock:
            segments, _ = self.model.transcribe(
                audio,
                language="en",
                beam_size=3 if final else 1,
                vad_filter=final,
                condition_on_previous_text=False,
                without_timestamps=True,
                initial_prompt=self.prompt or None,
            )
            return " ".join(s.text.strip() for s in segments).strip()


class Translator(threading.Thread):
    def __init__(self, out_q, get_engine):
        super().__init__(daemon=True)
        self.in_q = queue.Queue()
        self.out = out_q
        self.get_engine = get_engine
        self._google = None
        # Latest in-progress sentence; only translated when no finished sentence is waiting.
        self.live_text = None

    def run(self):
        try:
            import argostranslate.translate
            argostranslate.translate.translate("Hello.", "en", "vi")
        except Exception as e:
            self.out.put(("status", f"Argos chưa sẵn sàng: {e.__class__.__name__}"))
        while True:
            try:
                item = self.in_q.get(timeout=0.05)
            except queue.Empty:
                text, self.live_text = self.live_text, None
                if text:
                    self.out.put(("live_vi", self.translate(text)))
                continue
            if item is None:
                return
            key, text, src, tgt = item
            self.out.put(("translation", key, self.translate(text, src, tgt)))

    def translate(self, text, src="en", tgt="vi"):
        if self.get_engine().startswith("Google"):
            try:
                return self._google_translate(text, src, tgt)
            except Exception as e:
                self.out.put(("status", f"Google lỗi ({e.__class__.__name__}), tạm dùng Argos offline"))
        try:
            import argostranslate.translate
            return argostranslate.translate.translate(text, src, tgt)
        except Exception as e:
            return f"[Lỗi dịch: {e.__class__.__name__}]"

    def _google_translate(self, text, src, tgt):
        import requests
        if self._google is None:
            self._google = requests.Session()
        r = self._google.get("https://translate.googleapis.com/translate_a/single",
                             params={"client": "gtx", "sl": src, "tl": tgt, "dt": "t", "q": text},
                             timeout=8)
        r.raise_for_status()
        return "".join(part[0] for part in r.json()[0] if part[0])


def _voice_tokens():
    """Windows voices as {description: SAPI token}. Newer voices such as Mark are only
    registered under Speech_OneCore, so both registries are read."""
    import win32com.client
    tokens = {}
    cat = win32com.client.Dispatch("SAPI.SpObjectTokenCategory")
    cat.SetId(r"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech_OneCore\Voices", False)
    for group in (cat.EnumerateTokens(), win32com.client.Dispatch("SAPI.SpVoice").GetVoices()):
        for i in range(group.Count):
            tok = group.Item(i)
            tokens.setdefault(tok.GetDescription(), tok)
    return tokens


def piper_voices():
    """{label: .onnx path} for Piper voices downloaded into models/piper."""
    out = {}
    if os.path.isdir(PIPER_DIR):
        for f in sorted(os.listdir(PIPER_DIR)):
            if f.endswith(".onnx"):
                key = f.split("-")[1] if f.count("-") >= 2 else f[:-5]
                out[PIPER_PREFIX + PIPER_NAMES.get(key, key)] = os.path.join(PIPER_DIR, f)
    return out


def find_voice(name, voices):
    """Exact name, else a case-insensitive partial match (e.g. 'Northern English' or 'mark')."""
    if not name:
        return None
    if name in voices:
        return name
    key = name.lower().replace(PIPER_PREFIX.lower(), "").strip()
    return next((v for v in voices if key in v.lower()), None)


def list_voices():
    try:
        windows = list(_voice_tokens())
    except Exception:
        windows = []
    return windows + list(piper_voices())


class Speech(threading.Thread):
    """Reads text aloud with a Windows (SAPI) or Piper voice; emits ('tts', True/False)
    around each phrase. Queue items: ("load", voice) to preload, or (voice, text, rate, pitch)."""

    def __init__(self, out_q):
        super().__init__(daemon=True)
        self.q = queue.Queue()
        self.out = out_q
        self.stop_now = threading.Event()
        self._piper = {}

    def run(self):
        import pythoncom
        import win32com.client
        pythoncom.CoInitialize()
        self.sapi = win32com.client.Dispatch("SAPI.SpVoice")
        self.tokens = _voice_tokens()
        self.piper_paths = piper_voices()
        while True:
            item = self.q.get()
            if item is None:
                return
            if item[0] == "load":
                if item[1] in self.piper_paths:
                    self._load_piper(item[1])
                continue
            desc, text, rate, pitch = item
            self.stop_now.clear()
            self.out.put(("tts", True))
            try:
                if desc in self.piper_paths:
                    self._speak_piper(desc, text, rate, pitch)
                else:
                    self._speak_sapi(desc, text, rate, pitch)
            except Exception as e:
                self.out.put(("status", f"Lỗi giọng đọc: {e}"))
            self.out.put(("tts", False))

    def _speak_sapi(self, desc, text, rate, pitch):
        if desc in self.tokens:
            self.sapi.Voice = self.tokens[desc]
        self.sapi.Rate = rate
        self.sapi.Speak(f'<pitch absmiddle="{pitch}">{escape(text)}</pitch>', 1 | 8)  # async | XML
        while not self.sapi.WaitUntilDone(50):
            if self.stop_now.is_set():
                self.sapi.Speak("", 3)  # async + purge: stops current speech
                return

    def _load_piper(self, desc):
        if desc not in self._piper:
            from piper import PiperVoice
            self.out.put(("status", f"Đang nạp giọng {desc}..."))
            self._piper[desc] = PiperVoice.load(self.piper_paths[desc])
            self.out.put(("status", f"Giọng {desc} sẵn sàng."))
        return self._piper[desc]

    def _speak_piper(self, desc, text, rate, pitch):
        from piper.config import SynthesisConfig
        voice = self._load_piper(desc)
        # Same -10..10 scale as SAPI: rate ±10 = 2x faster/slower; pitch ±10 ≈ ±3 semitones.
        # Pitch: synthesize stretched by f, then resample by 1/f so duration is unchanged.
        f = 2 ** (pitch / 40)
        cfg = SynthesisConfig(length_scale=2 ** (-rate / 10) * f)
        chunks = list(voice.synthesize(text, cfg))
        if not chunks or self.stop_now.is_set():
            return
        audio = np.concatenate([c.audio_float_array for c in chunks])
        sr = chunks[0].sample_rate
        if f != 1:
            n = int(len(audio) / f)
            audio = np.interp(np.linspace(0, len(audio) - 1, n), np.arange(len(audio)),
                              audio).astype(np.float32)
        sd.play(audio, sr)
        stream = sd.get_stream()
        while stream.active:
            if self.stop_now.is_set():
                sd.stop()
                return
            time.sleep(0.05)


def _norm(word):
    return word.strip(".,!?;:\"'…").lower()


class Typewriter:
    """Shows text in a Label; small additions appear at once, big jumps are revealed word by
    word. Words already shown are kept when the text is revised."""

    def __init__(self, root, label, lines=2):
        self.root = root
        self.label = label
        self.lines = lines
        self.shown = []
        self.target = []
        self._tick()

    def set(self, text, instant=False):
        words = text.split()
        n = 0
        while n < min(len(self.shown), len(words)) and _norm(self.shown[n]) == _norm(words[n]):
            n += 1
        self.shown = words[:n]
        self.target = words
        if instant or len(words) - n <= 2:
            self.shown = list(words)
        self._render()

    def clear(self):
        self.set("", instant=True)

    def _tick(self):
        if len(self.shown) < len(self.target):
            self.shown.append(self.target[len(self.shown)])
            self._render()
        self.root.after(30, self._tick)

    def _render(self):
        text = " ".join(self.shown)
        width = max(200, self.label.winfo_width())
        font_px = int(self.label.tk.call("font", "measure", self.label.cget("font"), "0")) or 10
        max_chars = int(width / font_px * self.lines * 0.95)
        if len(text) > max_chars:
            cut = text[-max_chars:]
            text = "… " + cut[cut.find(" ") + 1:]
        self.label.configure(text=text)


def load_settings():
    """Returns (settings, error message or None). utf-8-sig also accepts files saved with a BOM."""
    if not os.path.exists(SETTINGS_FILE):
        return {}, None
    try:
        with open(SETTINGS_FILE, encoding="utf-8-sig") as f:
            return json.load(f), None
    except Exception as e:
        return {}, f"⚠ settings.json bị lỗi, đang dùng mặc định: {e}"


class App:
    def __init__(self, root):
        self.root = root
        self.q = queue.Queue()
        self.recognizers = []
        self.log_file = None
        self.log_path = ""
        self.entries = {}
        self.next_idx = 0
        self.vi_size = 20
        self.en_size = 12
        self.live_done = True
        self.live_speaker = None
        self.live_seg = None
        self.live_final_idx = None
        self.levels = {}
        self.settings, settings_error = load_settings()

        root.title("Live Translate  EN → VI")
        root.geometry("1100x660")
        root.configure(bg=BG)
        root.protocol("WM_DELETE_WINDOW", self.on_close)

        self.engine_var = tk.StringVar(value=self.settings.get("engine", ENGINES[0]))
        self.translator = Translator(self.q, self.engine_var.get)
        self.translator.start()
        self.speech = Speech(self.q)
        self.speech.start()
        self.speaking = False
        self.compose_seq = 0
        self.compose_src = ""
        self.speak_after_translate = False
        self._compose_job = None

        self._save_job = None
        self._build_ui()
        self._watch_settings()
        if settings_error:
            self.status.configure(text=settings_error, fg="#e0a050")
        self.root.after(50, self.poll)

    def _build_ui(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(".", background=PANEL, foreground="#ddd", fieldbackground="#2d313a")
        style.configure("TCheckbutton", background=PANEL, foreground="#ddd")
        style.map("TCheckbutton", background=[("active", PANEL)])
        style.configure("TLabel", background=PANEL, foreground="#ddd")
        style.map("TCombobox",
                  fieldbackground=[("readonly", "#2d313a"), ("disabled", "#26292f")],
                  foreground=[("readonly", "#e6e6e6"), ("disabled", "#888")],
                  selectbackground=[("readonly", "#2d313a")],
                  selectforeground=[("readonly", "#e6e6e6")])
        self.root.option_add("*TCombobox*Listbox.background", "#2d313a")
        self.root.option_add("*TCombobox*Listbox.foreground", "#e6e6e6")
        style.configure("Start.TButton", font=(FONT, 10, "bold"))
        style.configure("Level.Horizontal.TProgressbar", troughcolor="#2d313a", background="#4caf50")

        bar = tk.Frame(self.root, bg=PANEL, padx=8, pady=6)
        bar.pack(fill="x")

        self.devices = list_input_devices()
        labels = [label for _, label in self.devices]
        ttk.Label(bar, text="Loa:").pack(side="left")
        self.dev_var = tk.StringVar()
        self.dev_combo = ttk.Combobox(bar, textvariable=self.dev_var, state="readonly", width=40,
                                      values=labels)
        saved = self.settings.get("source")
        self.dev_combo.current(labels.index(saved) if saved in labels else 0)
        self.dev_combo.pack(side="left", padx=(4, 10))

        mics = [label for label in labels if is_real_mic(label)]
        ttk.Label(bar, text="+ Micro:").pack(side="left")
        self.mic_var = tk.StringVar()
        self.mic_combo = ttk.Combobox(bar, textvariable=self.mic_var, state="readonly", width=30,
                                      values=[NO_MIC] + mics)
        saved = self.settings.get("mic")
        default_mic = next((m for m in mics if "External" in m and "WASAPI" in m),
                           next((m for m in mics if "WASAPI" in m), NO_MIC))
        self.mic_var.set(saved if saved in [NO_MIC] + mics else default_mic)
        self.mic_combo.pack(side="left", padx=(4, 10))

        ttk.Label(bar, text="Model:").pack(side="left")
        models = available_whisper_models() or MODELS
        saved = self.settings.get("model", "small")
        self.model_var = tk.StringVar(value=saved if saved in models else models[-1])
        ttk.Combobox(bar, textvariable=self.model_var, state="readonly", width=6,
                     values=models).pack(side="left", padx=(4, 10))

        ttk.Label(bar, text="Dịch:").pack(side="left")
        ttk.Combobox(bar, textvariable=self.engine_var, state="readonly", width=14,
                     values=ENGINES).pack(side="left", padx=(4, 10))

        self.start_btn = ttk.Button(bar, text="▶ Bắt đầu", style="Start.TButton",
                                    command=self.toggle)
        self.start_btn.pack(side="left", padx=4)

        self.level = ttk.Progressbar(bar, style="Level.Horizontal.TProgressbar",
                                     length=70, maximum=1.0)
        self.level.pack(side="left", padx=8)

        bar2 = tk.Frame(self.root, bg=PANEL, padx=8, pady=2)
        bar2.pack(fill="x")
        self.top_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(bar2, text="Luôn trên cùng", variable=self.top_var,
                        command=lambda: self.root.attributes("-topmost", self.top_var.get())
                        ).pack(side="left")
        self.show_en_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(bar2, text="Hiện tiếng Anh", variable=self.show_en_var,
                        command=self.apply_fonts).pack(side="left", padx=8)
        self.partial_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(bar2, text="Live caption từng chữ",
                        variable=self.partial_var).pack(side="left", padx=8)
        self.partial_var.trace_add("write", lambda *a: [
            setattr(r, "live_partial", self.partial_var.get()) for r in self.recognizers])
        ttk.Button(bar2, text="A−", width=3, command=lambda: self.zoom(-2)).pack(side="left", padx=(12, 2))
        ttk.Button(bar2, text="A+", width=3, command=lambda: self.zoom(2)).pack(side="left")
        ttk.Label(bar2, text="  Trong suốt:").pack(side="left")
        ttk.Scale(bar2, from_=0.4, to=1.0, value=1.0, length=90,
                  command=lambda v: self.root.attributes("-alpha", float(v))).pack(side="left")
        ttk.Button(bar2, text="Xóa màn hình", command=self.clear).pack(side="right")
        ttk.Button(bar2, text="Mở thư mục log", command=self.open_logs).pack(side="right", padx=6)

        # Bottom widgets are packed first so they stay visible when the window shrinks.
        self.status = tk.Label(self.root, bg="#101216", fg="#888", anchor="w", padx=8,
                               text="🔊 Loa = âm thanh máy đang phát (YouTube, người khác trong Teams/Zoom). "
                                    "🎤 Micro = giọng bạn. Nên đeo tai nghe khi dùng cả hai.")
        self.status.pack(side="bottom", fill="x")

        live = tk.Frame(self.root, bg=LIVE_BG, padx=16, pady=8)
        live.pack(side="bottom", fill="x")
        self.live_header = tk.Label(live, text="● LIVE", bg=LIVE_BG, fg="#e05555",
                                    font=(FONT, 8, "bold"))
        self.live_header.pack(anchor="w")
        self.live_en = tk.Label(live, bg=LIVE_BG, fg=FG_PARTIAL, anchor="w", justify="left")
        self.live_en.pack(fill="x")
        self.live_vi = tk.Label(live, bg=LIVE_BG, fg=FG_VI, anchor="w", justify="left")
        self.live_vi.pack(fill="x", pady=(2, 0))
        live.bind("<Configure>", lambda e: [w.configure(wraplength=max(200, e.width - 32))
                                            for w in (self.live_en, self.live_vi)])
        self.tw_en = Typewriter(self.root, self.live_en)
        self.tw_vi = Typewriter(self.root, self.live_vi)

        self._build_compose()

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True)
        self.text = tk.Text(body, bg=BG, fg=FG_VI, wrap="word", bd=0, padx=16, pady=10,
                            insertbackground=BG, state="disabled", cursor="arrow")
        scroll = ttk.Scrollbar(body, command=self.text.yview)
        self.text.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.text.pack(side="left", fill="both", expand=True)
        self.apply_fonts()

    def _build_compose(self):
        box = tk.Frame(self.root, bg=PANEL, padx=12, pady=8)
        box.pack(side="bottom", fill="x")
        box.columnconfigure(0, weight=1)
        box.columnconfigure(2, weight=1)
        text_opts = dict(height=3, wrap="word", bg="#2d313a", fg="#f2f2f2", bd=0, padx=8, pady=6,
                         insertbackground="#f2f2f2", font=(FONT, 12), undo=True)

        ttk.Label(box, text="Tiếng Việt  (Enter = đọc · Shift+Enter = xuống dòng · Esc = xóa)"
                  ).grid(row=0, column=0, sticky="w")
        ttk.Label(box, text="English").grid(row=0, column=2, sticky="w")
        ttk.Label(box, text="Giọng đọc").grid(row=0, column=3, sticky="w", padx=(10, 0))

        self.vi_input = tk.Text(box, **text_opts)
        self.vi_input.grid(row=1, column=0, sticky="nsew")
        self.vi_input.bind("<KeyRelease>", self._on_vi_typed)
        self.vi_input.bind("<Return>", self._on_vi_enter)

        mid = tk.Frame(box, bg=PANEL)
        mid.grid(row=1, column=1, padx=8)
        ttk.Button(mid, text="Dịch ➜", command=self.translate_compose).pack(fill="x")
        ttk.Button(mid, text="✖ Xóa", command=self.clear_compose).pack(fill="x", pady=(6, 0))
        self.vi_input.bind("<Escape>", lambda e: self.clear_compose())

        self.en_output = tk.Text(box, **text_opts)
        self.en_output.grid(row=1, column=2, sticky="nsew")

        side = tk.Frame(box, bg=PANEL)
        side.grid(row=1, column=3, sticky="n", padx=(10, 0))
        voices = list_voices()
        default_voice = (find_voice(self.settings.get("voice"), voices)
                         or find_voice("Mark", voices) or (voices[0] if voices else ""))
        self.voice_var = tk.StringVar(value=default_voice)
        ttk.Combobox(side, textvariable=self.voice_var, state="readonly", width=30,
                     values=voices).pack(fill="x")
        # Piper voices take ~5 s to load, so load the selected one ahead of time.
        self.voice_var.trace_add("write", lambda *a: self.speech.q.put(("load", self.voice_var.get())))
        self.speech.q.put(("load", default_voice))
        self.rate_var = tk.IntVar(value=self.settings.get("rate", 0))
        self.pitch_var = tk.IntVar(value=self.settings.get("pitch", 0))
        self._add_slider(side, "Tốc độ", self.rate_var, "chậm", "nhanh")
        self._add_slider(side, "Cao độ", self.pitch_var, "trầm", "cao")
        self.speak_btn = ttk.Button(side, text="🔊 Đọc", style="Start.TButton",
                                    command=self.toggle_speak)
        self.speak_btn.pack(fill="x", pady=(6, 0))

    def _add_slider(self, parent, title, var, low, high):
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill="x", pady=(4, 0))
        value = ttk.Label(row, width=9)
        ttk.Label(row, text=title, width=7).pack(side="left")
        ttk.Label(row, text=low, foreground="#888").pack(side="left")

        def show(*_):
            v = round(var.get())
            value.configure(text="mặc định" if v == 0 else f"{v:+d}")

        scale = ttk.Scale(row, from_=-10, to=10, length=110, variable=var,
                          command=lambda v: var.set(round(float(v))))
        scale.pack(side="left", padx=2)
        ttk.Label(row, text=high, foreground="#888").pack(side="left")
        value.pack(side="left", padx=(4, 0))
        value.bind("<Double-Button-1>", lambda e: var.set(0))
        var.trace_add("write", show)
        show()

    def _on_vi_typed(self, event):
        if event.keysym in ("Return", "Shift_L", "Shift_R", "Control_L", "Control_R"):
            return
        if self._compose_job:
            self.root.after_cancel(self._compose_job)
        self._compose_job = self.root.after(600, self.translate_compose)

    def _on_vi_enter(self, event):
        if event.state & 0x0001:  # Shift+Enter: newline
            return None
        self.speak_after_translate = True
        self.translate_compose()
        return "break"

    def translate_compose(self):
        self._compose_job = None
        text = self.vi_input.get("1.0", "end").strip()
        if not text:
            self._set_en_output("")
            self.speak_after_translate = False
            return
        if text == self.compose_src and not self.speak_after_translate:
            return
        if text == self.compose_src and self.speak_after_translate:
            self.speak_after_translate = False
            self.speak_english()
            return
        self.compose_seq += 1
        self.compose_src = text
        self.translator.in_q.put(((COMPOSE_KEY, self.compose_seq), text, "vi", "en"))

    def clear_compose(self):
        if self._compose_job:
            self.root.after_cancel(self._compose_job)
            self._compose_job = None
        self.compose_seq += 1  # drop any translation still in flight
        self.compose_src = ""
        self.speak_after_translate = False
        self.vi_input.delete("1.0", "end")
        self._set_en_output("")
        self.vi_input.focus_set()

    def _set_en_output(self, text):
        self.en_output.delete("1.0", "end")
        self.en_output.insert("1.0", text)

    def on_compose_translation(self, seq, en):
        if seq != self.compose_seq:
            return
        self._set_en_output(en)
        if self.speak_after_translate:
            self.speak_after_translate = False
            self.speak_english()

    def toggle_speak(self):
        if self.speaking:
            self.speech.stop_now.set()
        else:
            self.speak_english()

    def speak_english(self):
        en = self.en_output.get("1.0", "end").strip()
        if not en:
            return
        self.speech.q.put((self.voice_var.get(), en, self.rate_var.get(), self.pitch_var.get()))
        self.add_spoken(self.vi_input.get("1.0", "end").strip(), en)

    def add_spoken(self, vi, en):
        speaker = "Bạn (máy đọc)"
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        follow = self.at_bottom()
        self.text.configure(state="normal")
        self.text.insert("end", f"{ts}  ", "time")
        self.text.insert("end", f"[{speaker}] ", f"spk{list(SPEAKER_COLORS).index(speaker)}")
        self.text.insert("end", vi + "\n", "en")
        self.text.insert("end", en + "\n", "vi")
        self.text.configure(state="disabled")
        if follow:
            self.text.see("end")
        if self.log_file:
            who = f"[{speaker}] "
            self.log_file.write(f"[{ts}] {who}VI: {vi}\n           {' ' * len(who)}EN: {en}\n\n")
            self.log_file.flush()

    def on_tts(self, active):
        self.speaking = active
        self.speak_btn.configure(text="⏹ Dừng đọc" if active else "🔊 Đọc")
        if active:
            self._set_loopback_muted(True)
        else:
            # Loopback audio lags playback slightly; keep muted a moment longer.
            self.root.after(400, lambda: self.speaking or self._set_loopback_muted(False))

    def _set_loopback_muted(self, muted):
        for r in self.recognizers:
            if r.source[0] == "loop":
                r.muted = muted

    def apply_fonts(self):
        self.text.tag_configure("time", foreground=FG_TIME, font=("Consolas", self.en_size - 2))
        for i, color in enumerate(SPEAKER_COLORS.values()):
            self.text.tag_configure(f"spk{i}", foreground=color,
                                    font=(FONT, self.en_size - 1, "bold"))
        self.text.tag_configure("en", foreground=FG_EN, font=(FONT, self.en_size),
                                elide=not self.show_en_var.get())
        self.text.tag_configure("vi", foreground=FG_VI, font=(FONT, self.vi_size), spacing3=12)
        self.live_en.configure(font=(FONT, self.en_size + 3))
        self.live_vi.configure(font=(FONT, self.vi_size + 2, "bold"))

    def zoom(self, d):
        self.vi_size = max(10, min(48, self.vi_size + d))
        self.en_size = max(9, min(30, self.en_size + d // 2))
        self.apply_fonts()

    def running(self):
        return any(r.is_alive() for r in self.recognizers)

    def toggle(self):
        if self.running():
            self.stop()
        else:
            self.start()

    def start(self):
        sel = self.dev_combo.current()
        mic_label = self.mic_var.get()
        mic = next((src for src, label in self.devices if label == mic_label), None)
        if sel < 0:
            messagebox.showwarning("Thiếu nguồn", "Hãy chọn nguồn âm thanh.")
            return
        src, src_label = self.devices[sel]
        if mic == src:
            mic = None

        if self.log_file:
            self.log_file.close()
        os.makedirs(LOG_DIR, exist_ok=True)
        self.log_path = os.path.join(
            LOG_DIR, datetime.datetime.now().strftime("meeting_%Y%m%d_%H%M%S.txt"))
        self.log_file = open(self.log_path, "a", encoding="utf-8")
        self.log_file.write(f"# Live Translate EN->VI  {datetime.datetime.now():%Y-%m-%d %H:%M:%S}\n"
                            f"# Nguồn: {src_label}\n"
                            + (f"# Micro: {mic_label}\n" if mic else "") + "\n")
        self.log_file.flush()

        live = self.partial_var.get()
        model = self.model_var.get()
        if mic:
            self.recognizers = [Recognizer(src, model, self.q, OTHERS, live),
                                Recognizer(mic, model, self.q, ME, live)]
        else:
            self.recognizers = [Recognizer(src, model, self.q, None, live)]
        for r in self.recognizers:
            r.start()
        self.start_btn.configure(text="■ Dừng")
        self.dev_combo.configure(state="disabled")
        self.mic_combo.configure(state="disabled")

    def _watch_settings(self):
        # Save only when the user changes something in the app, so edits made to
        # settings.json by hand are not overwritten on Start or on close.
        for var in (self.dev_var, self.mic_var, self.model_var, self.engine_var,
                    self.voice_var, self.rate_var, self.pitch_var):
            var.trace_add("write", lambda *a: self._schedule_save())

    def _schedule_save(self):
        if self._save_job:
            self.root.after_cancel(self._save_job)
        self._save_job = self.root.after(500, self._save_now)

    def _save_now(self):
        self._save_job = None
        self.save_settings()

    def save_settings(self):
        try:
            with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump({"source": self.dev_var.get(), "mic": self.mic_var.get(),
                           "model": self.model_var.get(), "engine": self.engine_var.get(),
                           "voice": self.voice_var.get(), "rate": self.rate_var.get(),
                           "pitch": self.pitch_var.get()}, f, ensure_ascii=False, indent=1)
        except OSError:
            pass

    def stop(self):
        for r in self.recognizers:
            r.stop_evt.set()
        self.start_btn.configure(text="▶ Bắt đầu")
        self.dev_combo.configure(state="readonly")
        self.mic_combo.configure(state="readonly")
        self.level["value"] = 0

    def at_bottom(self):
        return self.text.yview()[1] >= 0.98

    def add_final(self, speaker, en):
        idx = self.next_idx
        self.next_idx += 1
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        self.entries[idx] = (ts, speaker, en)
        follow = self.at_bottom()
        self.text.configure(state="normal")
        self.text.insert("end", f"{ts}  ", "time")
        if speaker:
            # Tk splits tag names on spaces, so tags are indexed rather than named by speaker.
            self.text.insert("end", f"[{speaker}] ", f"spk{list(SPEAKER_COLORS).index(speaker)}")
        self.text.insert("end", en + "\n", "en")
        self.text.insert("end", "…", ("vi", f"v{idx}"))
        self.text.insert("end", "\n")
        self.text.configure(state="disabled")
        if follow:
            self.text.see("end")
        self.translator.in_q.put((idx, en, "en", "vi"))
        return idx

    def set_translation(self, idx, vi):
        ts, speaker, en = self.entries.pop(idx, ("", None, ""))
        rng = self.text.tag_ranges(f"v{idx}")
        if rng:
            follow = self.at_bottom()
            self.text.configure(state="normal")
            self.text.delete(rng[0], rng[1])
            self.text.insert(rng[0], vi, ("vi", f"v{idx}"))
            self.text.configure(state="disabled")
            if follow:
                self.text.see("end")
        if self.log_file:
            who = f"[{speaker}] " if speaker else ""
            self.log_file.write(f"[{ts}] {who}EN: {en}\n           {' ' * len(who)}VI: {vi}\n\n")
            self.log_file.flush()

    def _set_live_speaker(self, speaker):
        self.live_speaker = speaker
        self.live_header.configure(text=f"● LIVE  ·  {speaker}" if speaker else "● LIVE")

    def on_partial(self, speaker, seg, text):
        if (speaker, seg) != self.live_seg:
            self.tw_en.clear()
            self.tw_vi.clear()
            self.live_seg = (speaker, seg)
            self.live_done = False
            self._set_live_speaker(speaker)
        if not self.live_done:
            self.tw_en.set(text)
            self.translator.live_text = text

    def on_final(self, speaker, seg, text):
        idx = self.add_final(speaker, text)
        # Whisper's result replaces the live line only if that sentence is still the one
        # shown; it stays there until the next sentence starts.
        if (speaker, seg) == self.live_seg:
            self.tw_en.set(text)
            self.translator.live_text = None
            self.live_done = True
            self.live_final_idx = idx

    def poll(self):
        try:
            while True:
                msg = self.q.get_nowait()
                kind = msg[0]
                if kind == "final":
                    self.on_final(msg[1], msg[2], msg[3])
                elif kind == "partial":
                    self.on_partial(msg[1], msg[2], msg[3])
                elif kind == "live_vi":
                    if not self.live_done:
                        self.tw_vi.set(msg[1])
                elif kind == "translation" and isinstance(msg[1], tuple):
                    self.on_compose_translation(msg[1][1], msg[2])
                elif kind == "tts":
                    self.on_tts(msg[1])
                elif kind == "translation":
                    if self.live_done and msg[1] == self.live_final_idx:
                        self.tw_vi.set(msg[2])
                    self.set_translation(msg[1], msg[2])
                elif kind == "level":
                    self.levels[msg[1]] = msg[2]
                    self.level["value"] = max(self.levels.values())
                elif kind == "status":
                    extra = f"   |   Log: {self.log_path}" if self.log_file else ""
                    self.status.configure(text=msg[1] + extra)
                elif kind == "error":
                    self.stop()
                    messagebox.showerror("Lỗi", msg[1])
                    self.status.configure(text=msg[1])
        except queue.Empty:
            pass
        self.root.after(30, self.poll)

    def clear(self):
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        self.text.configure(state="disabled")
        self.tw_en.clear()
        self.tw_vi.clear()

    def open_logs(self):
        os.makedirs(LOG_DIR, exist_ok=True)
        os.startfile(LOG_DIR)

    def on_close(self):
        self.stop()
        for r in self.recognizers:
            r.join(timeout=10)
        deadline = time.time() + 5
        while self.entries or not self.q.empty():
            if time.time() > deadline:
                break
            try:
                msg = self.q.get(timeout=0.2)
                if msg[0] == "translation" and isinstance(msg[1], int):
                    self.set_translation(msg[1], msg[2])
                elif msg[0] == "final":
                    self.add_final(msg[1], msg[3])
            except queue.Empty:
                pass
        self.translator.in_q.put(None)
        self.speech.stop_now.set()
        self.speech.q.put(None)
        if self._save_job:
            self.root.after_cancel(self._save_job)
            self.save_settings()
        if self.log_file:
            self.log_file.close()
        self.root.destroy()


if __name__ == "__main__":
    try:
        root = tk.Tk()
        App(root)
        root.mainloop()
    except Exception as e:
        traceback.print_exc()
        messagebox.showerror("Live Translate",
                             f"App bị lỗi khi khởi động:\n{e}\n\nChi tiết: {os.path.join(LOG_DIR, 'error.txt')}")
        raise
