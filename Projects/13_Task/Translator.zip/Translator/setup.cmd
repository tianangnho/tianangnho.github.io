@echo off
setlocal
cd /d "%~dp0"
title Live Translate - Cai dat
rem Full paths: some machines/shells have a PATH without System32.
set "SYS=%SystemRoot%\System32"
set "CHOICE=%SYS%\choice.exe"
set "WHERE=%SYS%\where.exe"
set "POWERSHELL=%SYS%\WindowsPowerShell\v1.0\powershell.exe"
echo ==================================================
echo   Live Translate EN ^<-^> VI  -  Cai dat
echo   (chay lai bao nhieu lan cung duoc)
echo ==================================================

rem ---------- 1. Python 3.11 - 3.13 ----------
echo.
echo [1/4] Tim Python 3.11 - 3.13...
set "PY="
set "PYDIR=%LOCALAPPDATA%\Programs\Python"
for %%P in ("%PYDIR%\Python312\python.exe" "%PYDIR%\Python313\python.exe" "%PYDIR%\Python311\python.exe") do (
    if not defined PY if exist "%%~P" call :check_py "%%~P"
)
if not defined PY for /f "delims=" %%P in ('"%WHERE%" python 2^>nul') do (
    if not defined PY call :check_py "%%P"
)
if not defined PY (
    echo   Khong tim thay Python phu hop.
    "%WHERE%" winget >nul 2>nul || goto :no_python
    "%CHOICE%" /c YN /m "  Cai Python 3.12 bang winget (khong can quyen admin)"
    if errorlevel 2 goto :no_python
    winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
    call :check_py "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)
if not defined PY goto :no_python
for %%D in ("%PY%") do set "PYW=%%~dpDpythonw.exe"
echo   Python: %PY%

rem ---------- 2. Thu vien ----------
echo.
echo [2/4] Cai thu vien Python (lan dau mat vai phut)...
"%PY%" -m pip install --upgrade pip --disable-pip-version-check -q
"%PY%" -m pip install -r requirements.txt --disable-pip-version-check
if errorlevel 1 (
    echo.
    echo   LOI khi cai thu vien. Kiem tra mang / proxy cong ty roi chay lai setup.cmd
    goto :fail
)

rem ---------- 3. Model ----------
echo.
echo [3/4] Kiem tra model (Whisper, Vosk, Piper, Argos)...
"%PY%" setup_models.py %*
if errorlevel 1 goto :fail

rem ---------- 4. Loi tat ----------
echo.
echo [4/4] Tao run_translate.bat va loi tat tren Desktop...
> run_translate.bat (
    echo @echo off
    echo cd /d "%%~dp0"
    echo start "" "%PYW%" live_translate.py
)
"%POWERSHELL%" -NoProfile -Command ^
  "$s = (New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop') + '\Live Translate.lnk');" ^
  "$s.TargetPath = '%PYW%'; $s.Arguments = '\"%~dp0live_translate.py\"'; $s.WorkingDirectory = '%~dp0';" ^
  "$s.Description = 'Live Translate EN-VI'; $s.Save()"
if errorlevel 1 (echo   Khong tao duoc loi tat - van chay bang run_translate.bat duoc.) else (echo   Da tao "Live Translate" tren Desktop.)

echo.
echo ==================================================
echo   XONG. Mo app bang loi tat "Live Translate" tren Desktop
echo   hoac run_translate.bat trong thu muc nay.
echo ==================================================
"%CHOICE%" /c YN /m "Mo app ngay bay gio"
if errorlevel 2 goto :end
start "" "%PYW%" live_translate.py
goto :end

:check_py
"%~1" -c "import sys; sys.exit(0 if (3,11) <= sys.version_info[:2] <= (3,13) else 1)" >nul 2>nul && set "PY=%~1"
exit /b 0

:no_python
echo.
echo   Can Python 3.11 - 3.13. Tai tai https://www.python.org/downloads/
echo   (khi cai, tick "Add python.exe to PATH"), roi chay lai setup.cmd
:fail
echo.
echo   Cai dat CHUA hoan tat.
pause
exit /b 1

:end
endlocal
